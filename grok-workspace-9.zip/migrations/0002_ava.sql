create table if not exists drivers (
  id serial primary key,
  name text not null,
  pin text not null,
  active boolean not null default true
);

create table if not exists buses (
  id serial primary key,
  bus text not null unique
);

create table if not exists trips (
  id text primary key,
  trip_date date not null,
  start_time text not null default '',
  end_time text not null default '',
  customer text not null,
  driver text not null,
  bus text not null default '',
  start_location text not null default '',
  end_location text not null default '',
  status text not null default 'Scheduled',
  distance_km text not null default ''
);

create table if not exists checkins (
  rid text primary key,
  driver text not null,
  entry_date date not null,
  entry_time text not null default '',
  bus text not null default '',
  odometer numeric,
  odo_photo text,
  photo_warn text not null default '',
  photo_failed boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists expenses (
  rid text primary key,
  driver text not null,
  entry_date date not null,
  entry_time text not null default '',
  bus text not null default '',
  category text not null default '',
  amount numeric,
  odometer numeric,
  liters numeric,
  price numeric,
  notes text not null default '',
  receipt text,
  photo_warn text not null default '',
  photo_failed boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists extra_trips (
  rid text primary key,
  driver text not null,
  entry_date date not null,
  entry_time text not null default '',
  bus text not null default '',
  description text not null default '',
  from_place text not null default '',
  to_place text not null default '',
  details text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists issues (
  rid text primary key,
  driver text not null,
  entry_date date not null,
  entry_time text not null default '',
  bus text not null default '',
  issue text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists feedback (
  rid text primary key,
  driver text not null,
  entry_date date not null,
  entry_time text not null default '',
  message text not null default '',
  screen text not null default '',
  device text not null default '',
  version text not null default '',
  errors text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists trips_driver_idx on trips (driver);
create index if not exists checkins_date_idx on checkins (entry_date);
create index if not exists expenses_date_idx on expenses (entry_date);

insert into drivers (name, pin, active)
select 'Rashid Khan', '1234', true
where not exists (select 1 from drivers where name = 'Rashid Khan');

insert into drivers (name, pin, active)
select 'Faisal Noor', '2468', true
where not exists (select 1 from drivers where name = 'Faisal Noor');

insert into drivers (name, pin, active)
select 'Omar Saeed', '1357', true
where not exists (select 1 from drivers where name = 'Omar Saeed');

insert into drivers (name, pin, active)
select 'Hamad Ali', '9753', false
where not exists (select 1 from drivers where name = 'Hamad Ali');

insert into buses (bus) values ('101') on conflict (bus) do nothing;
insert into buses (bus) values ('214') on conflict (bus) do nothing;
insert into buses (bus) values ('318') on conflict (bus) do nothing;
insert into buses (bus) values ('DXB-07') on conflict (bus) do nothing;

insert into trips (id, trip_date, start_time, end_time, customer, driver, bus, start_location, end_location, status, distance_km)
select 'T-morning-school', current_date, '06:15', '08:40', 'Al Noor School run', 'Rashid Khan', '101', 'Al Nahda depot', 'Al Noor School', 'Completed', '42'
where not exists (select 1 from trips where id = 'T-morning-school');

insert into trips (id, trip_date, start_time, end_time, customer, driver, bus, start_location, end_location, status, distance_km)
select 'T-jebel', current_date, '09:10', '', 'Port staff shuttle', 'Faisal Noor', '214', 'Dubai Mall', 'Jebel Ali', 'In Progress', ''
where not exists (select 1 from trips where id = 'T-jebel');

insert into trips (id, trip_date, start_time, end_time, customer, driver, bus, start_location, end_location, status, distance_km)
select 'T-airport', current_date, '14:00', '', 'Airport crew', 'Omar Saeed', '318', 'Sharjah Industrial', 'DXB Terminal 3', 'Scheduled', ''
where not exists (select 1 from trips where id = 'T-airport');

insert into trips (id, trip_date, start_time, end_time, customer, driver, bus, start_location, end_location, status, distance_km)
select 'T-evening', current_date, '16:30', '', 'Evening school return', 'Rashid Khan', '101', 'Al Noor School', 'Al Nahda depot', 'Scheduled', ''
where not exists (select 1 from trips where id = 'T-evening');

insert into checkins (rid, driver, entry_date, entry_time, bus, odometer)
select 'seed-ci-rashid', 'Rashid Khan', current_date, '05:42', '101', 184320
where not exists (select 1 from checkins where rid = 'seed-ci-rashid');

insert into checkins (rid, driver, entry_date, entry_time, bus, odometer)
select 'seed-ci-faisal', 'Faisal Noor', current_date, '06:05', '214', 96210
where not exists (select 1 from checkins where rid = 'seed-ci-faisal');

insert into expenses (rid, driver, entry_date, entry_time, bus, category, odometer, liters, price, notes)
select 'seed-ex-fuel', 'Faisal Noor', current_date, '07:18', '214', 'Fuel', 96280, 86.4, 2.89, 'ENOC Al Quoz'
where not exists (select 1 from expenses where rid = 'seed-ex-fuel');

insert into expenses (rid, driver, entry_date, entry_time, bus, category, amount, notes)
select 'seed-ex-tyre', 'Rashid Khan', current_date, '08:55', '101', 'Tyre', 180, 'Front right pressure'
where not exists (select 1 from expenses where rid = 'seed-ex-tyre');

insert into extra_trips (rid, driver, entry_date, entry_time, bus, description, from_place, to_place, details)
select 'seed-xt-rashid', 'Rashid Khan', current_date, '09:05', '101', 'Parent pickup after assembly', 'Al Noor School', 'Mirdif villa gate', 'Two students, office approved'
where not exists (select 1 from extra_trips where rid = 'seed-xt-rashid');

insert into issues (rid, driver, entry_date, entry_time, bus, issue)
select 'seed-is-omar', 'Omar Saeed', current_date, '05:10', '318', 'Air conditioning is weak on the rear rows.'
where not exists (select 1 from issues where rid = 'seed-is-omar');

insert into feedback (rid, driver, entry_date, entry_time, message, screen, device, version)
select 'seed-fb', 'Faisal Noor', current_date, '07:40', 'Fuel screen is clear. The odometer hint helped.', 'Report expense', 'seed', 'v2.0'
where not exists (select 1 from feedback where rid = 'seed-fb');
