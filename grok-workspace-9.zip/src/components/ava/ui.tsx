import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";
import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/cn";

export function Mark({ light = false, large = false }: { light?: boolean; large?: boolean }) {
  return (
    <span className={cn("inline-flex flex-col leading-none", light ? "text-paper" : "text-pine")}>
      <span className={cn("font-display font-bold tracking-widest", large ? "text-5xl" : "text-3xl")}>AVA</span>
      <span className="mt-1 h-1 w-full rounded-full bg-gold" />
    </span>
  );
}

const tones = {
  gold: "bg-gold text-ink hover:brightness-95",
  pine: "bg-pine text-paper hover:brightness-110",
  ghost: "border border-line bg-card text-ink hover:bg-paper",
  danger: "border border-danger/30 bg-card text-danger hover:bg-danger-soft",
  navy: "border border-paper/20 bg-transparent text-paper hover:bg-paper/10",
} as const;

export function Button({
  tone = "gold",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { tone?: keyof typeof tones }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl px-4 text-base font-semibold transition duration-200 disabled:opacity-50",
        tones[tone],
        className,
      )}
      {...props}
    />
  );
}

const control =
  "w-full min-h-12 rounded-xl border border-line bg-paper px-3 text-base text-ink outline-none focus:border-pine";

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="mb-3 block">
      <span className="mb-1 block text-sm font-semibold text-muted">{label}</span>
      {children}
    </label>
  );
}

export function TextInput(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn(control, props.className)} />;
}

export function SelectInput(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={cn(control, props.className)} />;
}

export function AreaInput(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn(control, "min-h-28 py-3", props.className)} />;
}

export function Tag({
  tone,
  children,
}: {
  tone: "ok" | "warn" | "bad" | "idle" | "go";
  children: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold",
        tone === "ok" && "bg-pine-soft text-pine",
        tone === "go" && "bg-pine-soft text-pine",
        tone === "warn" && "bg-warn-soft text-warn",
        tone === "bad" && "bg-danger-soft text-danger",
        tone === "idle" && "bg-line text-ink",
      )}
    >
      {children}
    </span>
  );
}

export function Toast({ text, className }: { text: string; className?: string }) {
  if (!text) return null;
  return (
    <div
      role="status"
      className={cn(
        "fixed bottom-24 left-1/2 z-50 max-w-[90vw] -translate-x-1/2 rounded-xl bg-navy px-4 py-3 text-center text-sm font-semibold text-paper",
        className,
      )}
    >
      {text}
    </div>
  );
}

export function useToast() {
  const [text, setText] = useState("");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);
  const toast = (m: string) => {
    setText(m);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setText(""), 3200);
  };
  return { text, toast };
}

export function TopBar({ title, sub, actions }: { title: string; sub?: string; actions?: ReactNode }) {
  return (
    <header className="sticky top-0 z-20 flex items-center gap-3 border-b-4 border-gold bg-navy px-4 py-3 pt-[max(0.75rem,env(safe-area-inset-top))] text-paper">
      <div className="min-w-0 flex-1">
        <p className="font-display text-2xl leading-none tracking-wide">{title}</p>
        {sub ? <p className="mt-1 truncate text-sm text-paper/70">{sub}</p> : null}
      </div>
      {actions}
    </header>
  );
}
