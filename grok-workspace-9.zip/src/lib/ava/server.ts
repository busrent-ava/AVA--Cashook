import { createServerFn } from "@tanstack/react-start";
import { keyOf, num, round2 } from "@/lib/ava/format";
import type {
  Api,
  DriverPayload,
  DriverToday,
  EntriesResult,
  EntryKind,
  EntryRow,
  Lists,
  Overview,
  Pulse,
  Trip,
  TripDraft,
} from "@/lib/ava/types";

const ADMIN_PINS = new Set(["Avauae@123", "2829"]);

function message(e: unknown) {
  const m = e instanceof Error ? e.message : String(e);
  return m.replace(/^Error:\s*/, "");
}

async function pack<T>(fn: () => Promise<T>): Promise<Api<T>> {
  try {
    return { ok: true, data: await fn() };
  } catch (e) {
    return { ok: false, error: message(e) };
  }
}

async function db() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

function assertAdmin(pin: string) {
  if (!ADMIN_PINS.has(String(pin || "").trim())) throw new Error("Wrong office PIN");
}

async function authDriver(name: string, pin: string) {
  const sql = await db();
  const rows = await sql<{ name: string; pin: string; active: boolean }>`
    select name, pin, active from drivers where name <> ''
  `;
  const d = rows.find((x) => keyOf(x.name) === keyOf(name) && x.active);
  if (!d || String(d.pin).trim() !== String(pin).trim()) throw new Error("Wrong name or PIN");
  return String(d.name);
}

function blankEntry(): EntryRow {
  return {
    rid: "",
    driver: "",
    date: "",
    time: "",
    bus: "",
    category: "",
    amount: 0,
    odometer: 0,
    liters: 0,
    price: 0,
    notes: "",
    receipt: "",
    total: 0,
    photoWarn: "",
    photoFailed: false,
    odoPhoto: "",
    description: "",
    from: "",
    to: "",
    details: "",
    issue: "",
    message: "",
    screen: "",
    device: "",
    version: "",
    errors: "",
  };
}

type Dated = { driver: string; entry_date: string; entry_time: string };

function inRange(r: Dated, driver: string, from: string | null, to: string | null) {
  if (driver && keyOf(r.driver) !== keyOf(driver)) return false;
  const d = String(r.entry_date);
  if (from && d < from) return false;
  if (to && d > to) return false;
  return true;
}

function expenseTotal(category: string, liters: unknown, price: unknown, amount: unknown) {
  if (category === "Fuel") return round2(num(liters) * num(price));
  return round2(num(amount));
}

async function serverToday() {
  const sql = await db();
  const rows = await sql<{ d: string }>`select current_date::text as d`;
  return String(rows[0]?.d ?? "");
}

function mapTrip(t: {
  id: string;
  trip_date: string;
  start_time: string;
  end_time: string;
  customer: string;
  driver: string;
  bus: string;
  start_location: string;
  end_location: string;
  status: string;
  distance_km: string;
}): Trip {
  return {
    id: String(t.id),
    date: String(t.trip_date),
    startTime: String(t.start_time || ""),
    endTime: String(t.end_time || ""),
    customer: String(t.customer || ""),
    driver: String(t.driver || ""),
    bus: String(t.bus || ""),
    startLocation: String(t.start_location || ""),
    endLocation: String(t.end_location || ""),
    status: String(t.status || "Scheduled"),
    distanceKm: String(t.distance_km || ""),
  };
}

async function allTrips() {
  const sql = await db();
  const rows = await sql<{
    id: string;
    trip_date: string;
    start_time: string;
    end_time: string;
    customer: string;
    driver: string;
    bus: string;
    start_location: string;
    end_location: string;
    status: string;
    distance_km: string;
  }>`
    select id, trip_date::text as trip_date, start_time, end_time, customer, driver, bus,
           start_location, end_location, status, distance_km
    from trips
  `;
  return rows.map(mapTrip);
}

async function busNames() {
  const sql = await db();
  const rows = await sql<{ bus: string }>`select bus from buses order by id`;
  return rows.map((b) => String(b.bus)).filter(Boolean);
}

async function loadDriver(name: string, pin: string): Promise<DriverPayload> {
  const me = await authDriver(name, pin);
  const today = await serverToday();
  const trips = (await allTrips())
    .filter((t) => keyOf(t.driver) === keyOf(me) && (t.status !== "Completed" || t.date === today))
    .sort((a, b) => (a.date + a.startTime).localeCompare(b.date + b.startTime));

  const sql = await db();
  const checks = await sql<{ bus: string; odometer: string | null; driver: string; entry_date: string }>`
    select bus, odometer, driver, entry_date::text as entry_date from checkins
  `;
  const exps = await sql<{ bus: string; odometer: string | null }>`
    select bus, odometer from expenses
  `;
  const lastOdo: Record<string, number> = {};
  let lastCheckIn: DriverPayload["lastCheckIn"] = null;
  for (const r of checks) {
    const odo = num(r.odometer);
    const bus = String(r.bus);
    if (odo > (lastOdo[bus] || 0)) lastOdo[bus] = odo;
    if (keyOf(r.driver) === keyOf(me)) {
      const d = String(r.entry_date);
      if (!lastCheckIn || d >= lastCheckIn.date) lastCheckIn = { bus, date: d, odometer: odo };
    }
  }
  for (const r of exps) {
    const odo = num(r.odometer);
    const bus = String(r.bus);
    if (odo > (lastOdo[bus] || 0)) lastOdo[bus] = odo;
  }
  return { name: me, pin: String(pin).trim(), trips, buses: await busNames(), lastOdo, lastCheckIn };
}

async function snapshot(): Promise<Overview> {
  const today = await serverToday();
  const sql = await db();
  const drivers = await sql<{ name: string; active: boolean }>`
    select name, active from drivers where name <> '' order by id
  `;
  const checks = await sql<{
    driver: string;
    entry_date: string;
    entry_time: string;
    bus: string;
    odometer: string | null;
  }>`
    select driver, entry_date::text as entry_date, entry_time, bus, odometer from checkins
  `;
  const exps = await sql<{
    driver: string;
    entry_date: string;
    entry_time: string;
    category: string;
    amount: string | null;
    liters: string | null;
    price: string | null;
  }>`
    select driver, entry_date::text as entry_date, entry_time, category, amount, liters, price from expenses
  `;
  const extras = await sql<{ driver: string; entry_date: string; entry_time: string }>`
    select driver, entry_date::text as entry_date, entry_time from extra_trips
  `;
  const issues = await sql<{ driver: string; entry_date: string; entry_time: string }>`
    select driver, entry_date::text as entry_date, entry_time from issues
  `;
  const trips = await allTrips();

  let spend = 0;
  let issueCount = 0;
  let checked = 0;
  let active = 0;
  let inprog = 0;
  for (const r of issues) if (String(r.entry_date) === today) issueCount += 1;

  const cards: DriverToday[] = drivers.map((d) => {
    const n = keyOf(d.name);
    const isActive = Boolean(d.active);
    const mine = (r: { driver: string }) => keyOf(r.driver) === n;
    let todayCheck: DriverToday["checkIn"] = null;
    let lastAct = "";
    for (const r of checks.filter(mine)) {
      const dd = String(r.entry_date);
      const tt = String(r.entry_time || "");
      if (dd === today && (!todayCheck || tt >= todayCheck.time)) {
        todayCheck = { bus: String(r.bus), time: tt, odometer: num(r.odometer) };
      }
      const st = dd + " " + tt;
      if (st > lastAct) lastAct = st;
    }
    for (const list of [exps, extras, issues]) {
      for (const r of list.filter(mine)) {
        const st = String(r.entry_date) + " " + String(r.entry_time || "");
        if (st > lastAct) lastAct = st;
      }
    }
    const tr = { scheduled: 0, inProgress: 0, completed: 0 };
    for (const t of trips.filter((t) => keyOf(t.driver) === n)) {
      if (t.status === "In Progress") tr.inProgress += 1;
      else if (t.status === "Scheduled" && t.date <= today) tr.scheduled += 1;
      else if (t.status === "Completed" && t.date === today) tr.completed += 1;
    }
    let sp = 0;
    for (const r of exps.filter(mine)) {
      if (String(r.entry_date) === today) sp += expenseTotal(r.category, r.liters, r.price, r.amount);
    }
    sp = round2(sp);
    if (isActive) {
      active += 1;
      if (todayCheck) checked += 1;
    }
    inprog += tr.inProgress;
    spend += sp;
    return {
      name: String(d.name),
      active: isActive,
      checkIn: todayCheck,
      trips: tr,
      spendToday: sp,
      lastActivity: lastAct.trim(),
    };
  });

  return {
    today,
    summary: {
      active,
      checkedIn: checked,
      tripsInProgress: inprog,
      spendToday: round2(spend),
      issuesToday: issueCount,
    },
    drivers: cards,
  };
}

function clip(v: unknown, n: number) {
  return String(v ?? "").slice(0, n);
}

function requireDate(v: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) throw new Error("Invalid date");
  return v;
}

function requireTime(v: string) {
  if (!/^\d{2}:\d{2}$/.test(v)) throw new Error("Invalid time");
  return v;
}

function photoOrNull(v: string) {
  if (!v) return null;
  if (!/^data:image\/(jpeg|jpg|png|webp);base64,/i.test(v)) throw new Error("Photo upload failed: bad image");
  if (v.length > 1_800_000) throw new Error("Photo upload failed: too large");
  return v;
}

async function addEntry(name: string, pin: string, kind: EntryKind, obj: Record<string, string>, rid: string) {
  const me = await authDriver(name, pin);
  if (!/^[a-z0-9-]{6,48}$/i.test(rid)) throw new Error("Unknown entry");
  const allowed: EntryKind[] = ["CheckIn", "Expense", "ExtraTrip", "Issues", "Feedback"];
  if (!allowed.includes(kind)) throw new Error("Unknown entry type");
  const sql = await db();

  if (kind === "CheckIn") {
    const hit = await sql`select rid from checkins where rid = ${rid} limit 1`;
    if (hit.length) return true;
    const bus = clip(obj.bus, 40);
    if (!bus) throw new Error("Bus is required");
    await sql`
      insert into checkins (rid, driver, entry_date, entry_time, bus, odometer, odo_photo, photo_warn, photo_failed)
      values (
        ${rid}, ${me}, ${requireDate(clip(obj.date, 10))}, ${requireTime(clip(obj.time, 8))}, ${bus},
        ${obj.odometer ? num(obj.odometer) : null}, ${photoOrNull(obj.odoPhoto || "")},
        ${clip(obj.photoWarn, 80)}, ${obj.photoFailed === "1"}
      )
    `;
    return true;
  }
  if (kind === "Expense") {
    const hit = await sql`select rid from expenses where rid = ${rid} limit 1`;
    if (hit.length) return true;
    const bus = clip(obj.bus, 40);
    if (!bus) throw new Error("Bus is required");
    const category = clip(obj.category, 40);
    if (!category) throw new Error("Category is required");
    await sql`
      insert into expenses (
        rid, driver, entry_date, entry_time, bus, category, amount, odometer, liters, price, notes, receipt, photo_warn, photo_failed
      ) values (
        ${rid}, ${me}, ${requireDate(clip(obj.date, 10))}, ${requireTime(clip(obj.time, 8))}, ${bus}, ${category},
        ${obj.amount ? num(obj.amount) : null},
        ${obj.odometer ? num(obj.odometer) : null},
        ${obj.liters ? num(obj.liters) : null},
        ${obj.price ? num(obj.price) : null},
        ${clip(obj.notes, 200)},
        ${photoOrNull(obj.receipt || "")},
        ${clip(obj.photoWarn, 80)},
        ${obj.photoFailed === "1"}
      )
    `;
    return true;
  }
  if (kind === "ExtraTrip") {
    const hit = await sql`select rid from extra_trips where rid = ${rid} limit 1`;
    if (hit.length) return true;
    const bus = clip(obj.bus, 40);
    if (!bus) throw new Error("Bus is required");
    const description = clip(obj.description, 200);
    if (!description) throw new Error("Description is required");
    await sql`
      insert into extra_trips (rid, driver, entry_date, entry_time, bus, description, from_place, to_place, details)
      values (
        ${rid}, ${me}, ${requireDate(clip(obj.date, 10))}, ${requireTime(clip(obj.time, 8))}, ${bus},
        ${description}, ${clip(obj.from, 80)}, ${clip(obj.to, 80)}, ${clip(obj.details, 200)}
      )
    `;
    return true;
  }
  if (kind === "Issues") {
    const hit = await sql`select rid from issues where rid = ${rid} limit 1`;
    if (hit.length) return true;
    const issue = clip(obj.issue, 500);
    if (!issue) throw new Error("Issue is required");
    await sql`
      insert into issues (rid, driver, entry_date, entry_time, bus, issue)
      values (
        ${rid}, ${me}, ${requireDate(clip(obj.date, 10))}, ${requireTime(clip(obj.time, 8))},
        ${clip(obj.bus, 40)}, ${issue}
      )
    `;
    return true;
  }
  const hit = await sql`select rid from feedback where rid = ${rid} limit 1`;
  if (hit.length) return true;
  const messageText = clip(obj.message, 800);
  if (!messageText) throw new Error("Message is required");
  await sql`
    insert into feedback (rid, driver, entry_date, entry_time, message, screen, device, version, errors)
    values (
      ${rid}, ${me}, ${requireDate(clip(obj.date, 10))}, ${requireTime(clip(obj.time, 8))},
      ${messageText}, ${clip(obj.screen, 80)}, ${clip(obj.device, 150)}, ${clip(obj.version, 20)}, ${clip(obj.errors, 400)}
    )
  `;
  return true;
}

async function loadEntries(kind: EntryKind, driver: string, from: string, to: string): Promise<EntriesResult> {
  const sql = await db();
  const fromD = from || null;
  const toD = to || null;
  if (kind === "Expense") {
    const rows = await sql<{
      rid: string;
      driver: string;
      entry_date: string;
      entry_time: string;
      bus: string;
      category: string;
      amount: string | null;
      odometer: string | null;
      liters: string | null;
      price: string | null;
      notes: string;
      receipt: string | null;
      photo_warn: string;
      photo_failed: boolean;
    }>`
      select rid, driver, entry_date::text as entry_date, entry_time, bus, category, amount, odometer,
             liters, price, notes, receipt, photo_warn, photo_failed
      from expenses
      where (${fromD}::date is null or entry_date >= ${fromD}::date)
        and (${toD}::date is null or entry_date <= ${toD}::date)
      order by entry_date desc, entry_time desc, created_at desc
    `;
    const list = rows.filter((r) => inRange(r, driver, fromD, toD)).map((r) => {
      const o = blankEntry();
      o.rid = r.rid;
      o.driver = r.driver;
      o.date = String(r.entry_date);
      o.time = r.entry_time;
      o.bus = r.bus;
      o.category = r.category;
      o.amount = num(r.amount);
      o.odometer = num(r.odometer);
      o.liters = num(r.liters);
      o.price = num(r.price);
      o.notes = r.notes;
      o.receipt = r.receipt || "";
      o.photoWarn = r.photo_warn;
      o.photoFailed = Boolean(r.photo_failed);
      o.total = expenseTotal(r.category, r.liters, r.price, r.amount);
      return o;
    });
    const total = round2(list.reduce((s, r) => s + r.total, 0));
    return { total, count: list.length, rows: list.slice(0, 200) };
  }
  if (kind === "CheckIn") {
    const rows = await sql<{
      rid: string;
      driver: string;
      entry_date: string;
      entry_time: string;
      bus: string;
      odometer: string | null;
      odo_photo: string | null;
      photo_warn: string;
      photo_failed: boolean;
    }>`
      select rid, driver, entry_date::text as entry_date, entry_time, bus, odometer, odo_photo, photo_warn, photo_failed
      from checkins
      where (${fromD}::date is null or entry_date >= ${fromD}::date)
        and (${toD}::date is null or entry_date <= ${toD}::date)
      order by entry_date desc, entry_time desc, created_at desc
    `;
    const list = rows.filter((r) => inRange(r, driver, fromD, toD)).map((r) => {
      const o = blankEntry();
      o.rid = r.rid;
      o.driver = r.driver;
      o.date = String(r.entry_date);
      o.time = r.entry_time;
      o.bus = r.bus;
      o.odometer = num(r.odometer);
      o.odoPhoto = r.odo_photo || "";
      o.photoWarn = r.photo_warn;
      o.photoFailed = Boolean(r.photo_failed);
      return o;
    });
    return { total: 0, count: list.length, rows: list.slice(0, 200) };
  }
  if (kind === "ExtraTrip") {
    const rows = await sql<{
      rid: string;
      driver: string;
      entry_date: string;
      entry_time: string;
      bus: string;
      description: string;
      from_place: string;
      to_place: string;
      details: string;
    }>`
      select rid, driver, entry_date::text as entry_date, entry_time, bus, description, from_place, to_place, details
      from extra_trips
      where (${fromD}::date is null or entry_date >= ${fromD}::date)
        and (${toD}::date is null or entry_date <= ${toD}::date)
      order by entry_date desc, entry_time desc, created_at desc
    `;
    const list = rows.filter((r) => inRange(r, driver, fromD, toD)).map((r) => {
      const o = blankEntry();
      o.rid = r.rid;
      o.driver = r.driver;
      o.date = String(r.entry_date);
      o.time = r.entry_time;
      o.bus = r.bus;
      o.description = r.description;
      o.from = r.from_place;
      o.to = r.to_place;
      o.details = r.details;
      return o;
    });
    return { total: 0, count: list.length, rows: list.slice(0, 200) };
  }
  if (kind === "Issues") {
    const rows = await sql<{
      rid: string;
      driver: string;
      entry_date: string;
      entry_time: string;
      bus: string;
      issue: string;
    }>`
      select rid, driver, entry_date::text as entry_date, entry_time, bus, issue from issues
      where (${fromD}::date is null or entry_date >= ${fromD}::date)
        and (${toD}::date is null or entry_date <= ${toD}::date)
      order by entry_date desc, entry_time desc, created_at desc
    `;
    const list = rows.filter((r) => inRange(r, driver, fromD, toD)).map((r) => {
      const o = blankEntry();
      o.rid = r.rid;
      o.driver = r.driver;
      o.date = String(r.entry_date);
      o.time = r.entry_time;
      o.bus = r.bus;
      o.issue = r.issue;
      return o;
    });
    return { total: 0, count: list.length, rows: list.slice(0, 200) };
  }
  const rows = await sql<{
    rid: string;
    driver: string;
    entry_date: string;
    entry_time: string;
    message: string;
    screen: string;
    device: string;
    version: string;
    errors: string;
  }>`
    select rid, driver, entry_date::text as entry_date, entry_time, message, screen, device, version, errors
    from feedback
    where (${fromD}::date is null or entry_date >= ${fromD}::date)
      and (${toD}::date is null or entry_date <= ${toD}::date)
    order by entry_date desc, entry_time desc, created_at desc
  `;
  const list = rows.filter((r) => inRange(r, driver, fromD, toD)).map((r) => {
    const o = blankEntry();
    o.rid = r.rid;
    o.driver = r.driver;
    o.date = String(r.entry_date);
    o.time = r.entry_time;
    o.message = r.message;
    o.screen = r.screen;
    o.device = r.device;
    o.version = r.version;
    o.errors = r.errors;
    return o;
  });
  return { total: 0, count: list.length, rows: list.slice(0, 200) };
}

export const boardPulse = createServerFn({ method: "GET" }).handler(async () =>
  pack(async (): Promise<Pulse> => {
    const snap = await snapshot();
    return {
      active: snap.summary.active,
      checkedIn: snap.summary.checkedIn,
      onRoad: snap.summary.tripsInProgress,
      buses: (await busNames()).length,
    };
  }),
);

export const driverNames = createServerFn({ method: "GET" }).handler(async () =>
  pack(async () => {
    const sql = await db();
    const rows = await sql<{ name: string; pin: string; active: boolean }>`
      select name, pin, active from drivers where name <> '' order by id
    `;
    return rows.filter((d) => d.active && String(d.pin) !== "").map((d) => String(d.name));
  }),
);

export const driverData = createServerFn({ method: "POST" })
  .validator((input: { name: string; pin: string }) => input)
  .handler(async ({ data }) => pack(() => loadDriver(data.name, data.pin)));

export const driverTrip = createServerFn({ method: "POST" })
  .validator((input: { name: string; pin: string; id: string; action: "start" | "finish"; km: string; at: string }) => input)
  .handler(async ({ data }) =>
    pack(async () => {
      const me = await authDriver(data.name, data.pin);
      const sql = await db();
      const rows = await sql<{ id: string; driver: string; start_time: string }>`
        select id, driver, start_time from trips where id = ${data.id}
      `;
      const t = rows.find((x) => keyOf(x.driver) === keyOf(me));
      if (!t) throw new Error("Trip not found");
      if (data.action === "start") {
        await sql`update trips set status = 'In Progress' where id = ${data.id}`;
        if (!t.start_time) await sql`update trips set start_time = ${clip(data.at, 8)} where id = ${data.id}`;
      } else {
        await sql`
          update trips set status = 'Completed', end_time = ${clip(data.at, 8)},
            distance_km = case when ${clip(data.km, 12)} = '' then distance_km else ${clip(data.km, 12)} end
          where id = ${data.id}
        `;
      }
      return true;
    }),
  );

export const driverAdd = createServerFn({ method: "POST" })
  .validator((input: { name: string; pin: string; kind: EntryKind; rid: string; obj: Record<string, string> }) => input)
  .handler(async ({ data }) => pack(() => addEntry(data.name, data.pin, data.kind, data.obj || {}, data.rid)));

export const adminLogin = createServerFn({ method: "POST" })
  .validator((input: { pin: string }) => input)
  .handler(async ({ data }) => pack(async () => {
    assertAdmin(data.pin);
    return true;
  }));

export const adminOverview = createServerFn({ method: "POST" })
  .validator((input: { pin: string }) => input)
  .handler(async ({ data }) => pack(async () => {
    assertAdmin(data.pin);
    return snapshot();
  }));

export const adminEntries = createServerFn({ method: "POST" })
  .validator((input: { pin: string; kind: EntryKind; driver: string; from: string; to: string }) => input)
  .handler(async ({ data }) =>
    pack(async () => {
      assertAdmin(data.pin);
      const kinds: EntryKind[] = ["CheckIn", "Expense", "ExtraTrip", "Issues", "Feedback"];
      if (!kinds.includes(data.kind)) throw new Error("Unknown entry type");
      return loadEntries(data.kind, data.driver || "", data.from || "", data.to || "");
    }),
  );

export const adminTrips = createServerFn({ method: "POST" })
  .validator((input: { pin: string }) => input)
  .handler(async ({ data }) =>
    pack(async () => {
      assertAdmin(data.pin);
      const sql = await db();
      const lim = await sql<{ d: string }>`select (current_date - 14)::text as d`;
      const limit = String(lim[0]?.d ?? "");
      const list = (await allTrips())
        .filter((t) => t.status !== "Completed" || t.date >= limit)
        .sort((a, b) => (b.date + b.startTime).localeCompare(a.date + a.startTime));
      return list.slice(0, 200);
    }),
  );

export const adminTripAdd = createServerFn({ method: "POST" })
  .validator((input: { pin: string; trip: TripDraft }) => input)
  .handler(async ({ data }) =>
    pack(async () => {
      assertAdmin(data.pin);
      const t = data.trip;
      if (!t.date || !t.customer || !t.driver) throw new Error("Date, customer and driver are required");
      const id = "T" + Date.now().toString(36);
      const sql = await db();
      await sql`
        insert into trips (id, trip_date, start_time, end_time, customer, driver, bus, start_location, end_location, status, distance_km)
        values (
          ${id}, ${requireDate(t.date)}, ${clip(t.startTime, 8)}, '', ${clip(t.customer, 120)},
          ${clip(t.driver, 80)}, ${clip(t.bus, 40)}, ${clip(t.startLocation, 120)}, ${clip(t.endLocation, 120)},
          'Scheduled', ''
        )
      `;
      return id;
    }),
  );

export const adminTripDelete = createServerFn({ method: "POST" })
  .validator((input: { pin: string; id: string }) => input)
  .handler(async ({ data }) =>
    pack(async () => {
      assertAdmin(data.pin);
      const sql = await db();
      const rows = await sql<{ id: string }>`select id from trips where id = ${data.id}`;
      if (!rows.length) throw new Error("Trip not found");
      await sql`delete from trips where id = ${data.id}`;
      return true;
    }),
  );

export const adminLists = createServerFn({ method: "POST" })
  .validator((input: { pin: string }) => input)
  .handler(async ({ data }) =>
    pack(async (): Promise<Lists> => {
      assertAdmin(data.pin);
      const sql = await db();
      const drivers = await sql<{ name: string; pin: string; active: boolean }>`
        select name, pin, active from drivers where name <> '' order by id
      `;
      return {
        drivers: drivers.map((d) => ({ name: String(d.name), pin: String(d.pin), active: Boolean(d.active) })),
        buses: await busNames(),
      };
    }),
  );

export const adminDriverSave = createServerFn({ method: "POST" })
  .validator((input: { pin: string; oldName: string; name: string; newPin: string; active: boolean }) => input)
  .handler(async ({ data }) =>
    pack(async () => {
      assertAdmin(data.pin);
      const name = clip(data.name, 80).trim();
      const newPin = clip(data.newPin, 8).trim();
      if (!name) throw new Error("Enter the driver name");
      if (!/^\d{4,8}$/.test(newPin)) throw new Error("PIN must be 4 to 8 digits");
      const sql = await db();
      const all = await sql<{ id: number; name: string }>`select id, name from drivers`;
      const clash = all.find((d) => keyOf(d.name) === keyOf(name) && keyOf(d.name) !== keyOf(data.oldName));
      if (clash) throw new Error("A driver with that name already exists");
      const row = data.oldName ? all.find((d) => keyOf(d.name) === keyOf(data.oldName)) : undefined;
      if (row) {
        await sql`update drivers set name = ${name}, pin = ${newPin}, active = ${data.active !== false} where id = ${row.id}`;
      } else {
        await sql`insert into drivers (name, pin, active) values (${name}, ${newPin}, ${data.active !== false})`;
      }
      return true;
    }),
  );

export const adminDriverRemove = createServerFn({ method: "POST" })
  .validator((input: { pin: string; name: string }) => input)
  .handler(async ({ data }) =>
    pack(async () => {
      assertAdmin(data.pin);
      const sql = await db();
      const rows = await sql<{ id: number; name: string }>`select id, name from drivers`;
      const d = rows.find((x) => keyOf(x.name) === keyOf(data.name));
      if (!d) throw new Error("Driver not found");
      await sql`delete from drivers where id = ${d.id}`;
      return true;
    }),
  );

export const adminBusAdd = createServerFn({ method: "POST" })
  .validator((input: { pin: string; bus: string }) => input)
  .handler(async ({ data }) =>
    pack(async () => {
      assertAdmin(data.pin);
      const bus = clip(data.bus, 40).trim();
      if (!bus) throw new Error("Enter the bus number");
      const names = await busNames();
      if (names.some((b) => keyOf(b) === keyOf(bus))) throw new Error("Bus already in the list");
      const sql = await db();
      await sql`insert into buses (bus) values (${bus})`;
      return true;
    }),
  );

export const adminBusRemove = createServerFn({ method: "POST" })
  .validator((input: { pin: string; bus: string }) => input)
  .handler(async ({ data }) =>
    pack(async () => {
      assertAdmin(data.pin);
      const sql = await db();
      const rows = await sql<{ id: number; bus: string }>`select id, bus from buses`;
      const b = rows.find((x) => keyOf(x.bus) === keyOf(data.bus));
      if (!b) throw new Error("Bus not found");
      await sql`delete from buses where id = ${b.id}`;
      return true;
    }),
  );
