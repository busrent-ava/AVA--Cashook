export function keyOf(s: unknown) {
  return String(s ?? "")
    .toLowerCase()
    .replace(/\s+/g, "");
}

export function num(v: unknown) {
  if (v == null || v === "") return 0;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

export function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export function money(n: number) {
  return (
    "AED " +
    (Number.isFinite(n) ? n : 0).toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  );
}

export function todayISO() {
  const d = new Date(Date.now() - new Date().getTimezoneOffset() * 60000);
  return d.toISOString().slice(0, 10);
}

export function daysAgo(n: number) {
  const d = new Date(Date.now() - n * 864e5 - new Date().getTimezoneOffset() * 60000);
  return d.toISOString().slice(0, 10);
}

export function nowHM() {
  return new Date().toTimeString().slice(0, 5);
}

export function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export function whenLabel(dt: string) {
  if (dt === todayISO()) return "today";
  if (dt === daysAgo(1)) return "yesterday";
  return "on " + dt;
}
