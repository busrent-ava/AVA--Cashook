export type PhotoWarn = { short: string; text: string };

export type Stamped = {
  url: string;
  label: string;
  warn: PhotoWarn | null;
  ok: boolean;
};

function analyzeGray(g: Uint8Array, w: number, h: number): PhotoWarn | null {
  const hist = new Array<number>(256).fill(0);
  for (let i = 0; i < g.length; i++) hist[g[i]]++;
  const pct = (p: number) => {
    let t = g.length * p;
    let s = 0;
    for (let v = 0; v < 256; v++) {
      s += hist[v];
      if (s >= t) return v;
    }
    return 255;
  };
  const p99 = pct(0.99);
  const range = p99 - pct(0.01);
  const gh = new Array<number>(512).fill(0);
  let n = 0;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const gx = g[i + 1] - g[i - 1];
      const gy = g[i + w] - g[i - w];
      gh[Math.min(511, Math.round(Math.sqrt(gx * gx + gy * gy)))]++;
      n++;
    }
  }
  let s = 0;
  let g995 = 0;
  for (let v = 0; v < 512; v++) {
    s += gh[v];
    if (s >= n * 0.995) {
      g995 = v;
      break;
    }
  }
  if (p99 < 100) return { short: "too dark", text: "too dark. Turn on a light or move to a brighter spot." };
  if (range < 40) return { short: "washed out", text: "washed out. Tilt the phone to avoid glare." };
  if (range > 0 && g995 / range < 0.5) return { short: "blurry", text: "blurry. Hold the phone steady and tap the screen to focus." };
  return null;
}

function checkQuality(canvas: HTMLCanvasElement): PhotoWarn | null {
  try {
    const w = Math.min(640, canvas.width);
    const h = Math.max(1, Math.round((canvas.height * w) / canvas.width));
    const t = document.createElement("canvas");
    t.width = w;
    t.height = h;
    const x = t.getContext("2d");
    if (!x) return null;
    x.drawImage(canvas, 0, 0, w, h);
    const px = x.getImageData(0, 0, w, h).data;
    const g = new Uint8Array(w * h);
    for (let i = 0; i < g.length; i++) {
      g[i] = 0.299 * px[i * 4] + 0.587 * px[i * 4 + 1] + 0.114 * px[i * 4 + 2];
    }
    return analyzeGray(g, w, h);
  } catch {
    return null;
  }
}

export function stampPhoto(file: File): Promise<Stamped> {
  return new Promise((ok, no) => {
    const img = new Image();
    const u = URL.createObjectURL(file);
    img.onload = () => {
      const sc = Math.min(1, 900 / Math.max(img.width, img.height));
      const w = Math.max(1, Math.round(img.width * sc));
      const h = Math.max(1, Math.round(img.height * sc));
      const c = document.createElement("canvas");
      c.width = w;
      c.height = h;
      const x = c.getContext("2d");
      if (!x) {
        URL.revokeObjectURL(u);
        no(new Error("photo"));
        return;
      }
      x.drawImage(img, 0, 0, w, h);
      const warn = checkQuality(c);
      const t = new Date();
      const label = t.toLocaleDateString("en-GB") + " " + t.toTimeString().slice(0, 8);
      const fs = Math.max(14, Math.round(w / 26));
      const pad = Math.round(fs / 2);
      x.font = "bold " + fs + "px sans-serif";
      x.textBaseline = "middle";
      const width = x.measureText(label).width + pad * 2;
      x.fillStyle = "rgba(0,0,0,0.65)";
      x.fillRect(0, h - fs - pad * 2, width, fs + pad * 2);
      x.fillStyle = "#ffd23f";
      x.fillText(label, pad, h - fs / 2 - pad);
      URL.revokeObjectURL(u);
      ok({ url: c.toDataURL("image/jpeg", 0.6), label, warn, ok: false });
    };
    img.onerror = () => {
      URL.revokeObjectURL(u);
      no(new Error("photo"));
    };
    img.src = u;
  });
}
