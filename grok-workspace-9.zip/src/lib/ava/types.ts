export const APP_VERSION = "v2.0";
export const DEMO_DRIVER = "Rashid Khan";
export const DEMO_DRIVER_PIN = "1234";
export const DEMO_DESK_PIN = "2829";

export type Api<T> = { ok: true; data: T } | { ok: false; error: string };

export type EntryKind = "CheckIn" | "Expense" | "ExtraTrip" | "Issues" | "Feedback";

export type Trip = {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  customer: string;
  driver: string;
  bus: string;
  startLocation: string;
  endLocation: string;
  status: string;
  distanceKm: string;
};

export type CheckInSnap = { bus: string; date: string; odometer: number };

export type DriverPayload = {
  name: string;
  pin: string;
  trips: Trip[];
  buses: string[];
  lastOdo: Record<string, number>;
  lastCheckIn: CheckInSnap | null;
};

export type Pulse = {
  active: number;
  checkedIn: number;
  onRoad: number;
  buses: number;
};

export type DriverToday = {
  name: string;
  active: boolean;
  checkIn: { bus: string; time: string; odometer: number } | null;
  trips: { scheduled: number; inProgress: number; completed: number };
  spendToday: number;
  lastActivity: string;
};

export type Overview = {
  today: string;
  summary: {
    active: number;
    checkedIn: number;
    tripsInProgress: number;
    spendToday: number;
    issuesToday: number;
  };
  drivers: DriverToday[];
};

export type EntryRow = {
  rid: string;
  driver: string;
  date: string;
  time: string;
  bus: string;
  category: string;
  amount: number;
  odometer: number;
  liters: number;
  price: number;
  notes: string;
  receipt: string;
  total: number;
  photoWarn: string;
  photoFailed: boolean;
  odoPhoto: string;
  description: string;
  from: string;
  to: string;
  details: string;
  issue: string;
  message: string;
  screen: string;
  device: string;
  version: string;
  errors: string;
};

export type EntriesResult = { total: number; count: number; rows: EntryRow[] };

export type DriverAccount = { name: string; pin: string; active: boolean };
export type Lists = { drivers: DriverAccount[]; buses: string[] };

export type TripDraft = {
  customer: string;
  date: string;
  startTime: string;
  driver: string;
  bus: string;
  startLocation: string;
  endLocation: string;
};

export type QueueItem =
  | { t: "trip"; id: string; a: "start" | "finish"; km: string; at: string; rid: string }
  | { t: "add"; k: EntryKind; obj: Record<string, string>; rid: string; tries?: number };

export type LogItem = { rid: string; label: string; at: string; day: string };
