import type { DriverPayload, LogItem, QueueItem } from "@/lib/ava/types";

const QK = "ava_q";
const LOG = "ava_log";
const CACHE = "ava_cache";
const ERRS = "ava_errs";
const BUS = "ava_bus";
const ADMIN = "ava_admin_pin";

function read(key: string) {
  if (typeof window === "undefined") return null;
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function write(key: string, value: string) {
  try {
    localStorage.setItem(key, value);
    return true;
  } catch {
    return false;
  }
}

export function readQueue(): QueueItem[] {
  try {
    return JSON.parse(read(QK) || "[]") as QueueItem[];
  } catch {
    return [];
  }
}

export function writeQueue(q: QueueItem[]) {
  return write(QK, JSON.stringify(q));
}

export function readLog(): LogItem[] {
  try {
    return JSON.parse(read(LOG) || "[]") as LogItem[];
  } catch {
    return [];
  }
}

export function pushLog(item: LogItem) {
  write(LOG, JSON.stringify([item, ...readLog()].slice(0, 15)));
}

export function readCache(): DriverPayload | null {
  try {
    return JSON.parse(read(CACHE) || "null") as DriverPayload | null;
  } catch {
    return null;
  }
}

export function writeCache(s: DriverPayload) {
  write(CACHE, JSON.stringify(s));
}

export function clearCache() {
  try {
    localStorage.removeItem(CACHE);
  } catch {
    /* ignore */
  }
}

export function noteErr(m: string) {
  try {
    const a = JSON.parse(read(ERRS) || "[]") as string[];
    a.unshift(new Date().toTimeString().slice(0, 5) + " " + String(m).slice(0, 80));
    write(ERRS, JSON.stringify(a.slice(0, 6)));
  } catch {
    /* ignore */
  }
}

export function readErrs() {
  try {
    return (JSON.parse(read(ERRS) || "[]") as string[]).join(" | ");
  } catch {
    return "";
  }
}

export function readBus() {
  return read(BUS) || "";
}

export function writeBus(bus: string) {
  write(BUS, bus);
}

export function readAdminPin() {
  return read(ADMIN) || "";
}

export function writeAdminPin(pin: string) {
  write(ADMIN, pin);
}

export function clearAdminPin() {
  try {
    localStorage.removeItem(ADMIN);
  } catch {
    /* ignore */
  }
}
