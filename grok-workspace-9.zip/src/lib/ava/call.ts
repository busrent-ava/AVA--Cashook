import type { Api } from "@/lib/ava/types";

export async function call<T>(p: Promise<Api<T>>): Promise<T> {
  let r: Api<T>;
  try {
    r = await p;
  } catch {
    throw new Error("Network error");
  }
  if (!r.ok) throw new Error(r.error);
  return r.data;
}

export function errText(e: unknown) {
  const m = e instanceof Error ? e.message : String(e);
  return m.replace(/^Error:\s*/, "");
}
