import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  Camera,
  CircleAlert,
  ClipboardCheck,
  Fuel,
  LogOut,
  Plus,
  RefreshCw,
  TriangleAlert,
} from "lucide-react";
import { AreaInput, Button, Field, SelectInput, Tag, TextInput, Toast, TopBar, useToast } from "@/components/ava/ui";
import { call, errText } from "@/lib/ava/call";
import { keyOf, nowHM, todayISO, uid, whenLabel } from "@/lib/ava/format";
import { stampPhoto, type Stamped } from "@/lib/ava/photo";
import { driverAdd, driverData, driverNames, driverTrip } from "@/lib/ava/server";
import {
  clearCache,
  noteErr,
  pushLog,
  readBus,
  readCache,
  readErrs,
  readLog,
  readQueue,
  writeBus,
  writeCache,
  writeQueue,
} from "@/lib/ava/store";
import {
  APP_VERSION,
  DEMO_DRIVER,
  DEMO_DRIVER_PIN,
  type DriverPayload,
  type EntryKind,
  type QueueItem,
  type Trip,
} from "@/lib/ava/types";

export const Route = createFileRoute("/drive")({ component: DrivePage });

const CATS = ["Fuel", "Maintenance", "Tyre", "Other"] as const;
const TITLES: Record<EntryKind, string> = {
  CheckIn: "Daily check-in",
  Expense: "Report expense",
  ExtraTrip: "Extra trip",
  Issues: "Report a problem",
  Feedback: "Tell us what is confusing",
};

type Draft = {
  kind: EntryKind;
  cat: (typeof CATS)[number];
  bus: string;
  other: boolean;
  otherText: string;
  picker: boolean;
  why: string;
  chip: boolean;
  odo: string;
  notes: string;
  liters: string;
  price: string;
  amount: string;
  desc: string;
  date: string;
  time: string;
  from: string;
  to: string;
  details: string;
  issue: string;
  message: string;
  photos: Record<string, Stamped>;
};

function applyOverlay(trips: Trip[]): Trip[] {
  const next = trips.map((t) => ({ ...t }));
  for (const i of readQueue()) {
    if (i.t !== "trip") continue;
    const t = next.find((x) => x.id === i.id);
    if (!t) continue;
    if (i.a === "start") {
      t.status = "In Progress";
      if (!t.startTime) t.startTime = i.at;
    } else {
      t.status = "Completed";
      t.endTime = i.at;
      if (i.km) t.distanceKm = i.km;
    }
  }
  return next;
}

function mergeOdo(base: Record<string, number>) {
  const last = { ...base };
  for (const i of readQueue()) {
    if (i.t !== "add" || !i.obj.odometer) continue;
    const o = Number(i.obj.odometer);
    if (o > (last[i.obj.bus] || 0)) last[i.obj.bus] = o;
  }
  return last;
}

function busSuggestion(kind: EntryKind, s: DriverPayload) {
  const ok = (b: string) => Boolean(b) && s.buses.includes(b);
  if (kind === "CheckIn" && s.lastCheckIn && ok(s.lastCheckIn.bus)) {
    return [s.lastCheckIn.bus, "Same bus as your check-in " + whenLabel(s.lastCheckIn.date), true] as const;
  }
  const run = s.trips.find((x) => x.status === "In Progress" && ok(x.bus));
  if (run) return [run.bus, "Auto-selected: your trip in progress", false] as const;
  const next = s.trips.find((x) => x.status === "Scheduled" && ok(x.bus));
  if (next) return [next.bus, "Auto-selected: your next scheduled trip", false] as const;
  const last = readBus();
  if (ok(last)) return [last, "Auto-selected: the bus you used last", false] as const;
  return [s.buses[0] || "", "", false] as const;
}

function emptyDraft(kind: EntryKind, s: DriverPayload): Draft {
  const [bus, why, chip] = busSuggestion(kind, s);
  return {
    kind,
    cat: "Fuel",
    bus,
    other: false,
    otherText: "",
    picker: !chip,
    why,
    chip,
    odo: "",
    notes: "",
    liters: "",
    price: "",
    amount: "",
    desc: "",
    date: todayISO(),
    time: nowHM(),
    from: "",
    to: "",
    details: "",
    issue: "",
    message: "",
    photos: {},
  };
}

function chosenBus(d: Draft, buses: string[]) {
  const raw = d.other ? d.otherText.trim() : d.bus;
  return buses.find((b) => keyOf(b) === keyOf(raw)) || raw;
}

function DrivePage() {
  const { text, toast } = useToast();
  const [ready, setReady] = useState(false);
  const [names, setNames] = useState<string[]>([]);
  const [loginName, setLoginName] = useState("");
  const [loginPin, setLoginPin] = useState("");
  const [loginErr, setLoginErr] = useState("");
  const [session, setSession] = useState<DriverPayload | null>(null);
  const [online, setOnline] = useState(true);
  const [tick, setTick] = useState(0);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [finId, setFinId] = useState<string | null>(null);
  const [km, setKm] = useState("");
  const [busy, setBusy] = useState(false);
  const sessionRef = useRef<DriverPayload | null>(null);
  const syncing = useRef(false);
  const screenRef = useRef("Home");

  const commit = (next: DriverPayload) => {
    sessionRef.current = next;
    setSession(next);
    writeCache(next);
  };

  const bump = () => setTick((n) => n + 1);

  const refresh = async (silent: boolean) => {
    const s = sessionRef.current;
    if (!s) return;
    if (typeof navigator !== "undefined" && !navigator.onLine) {
      if (!silent) toast("You are offline");
      return;
    }
    try {
      const d = await call(driverData({ data: { name: s.name, pin: s.pin } }));
      const lastOdo = mergeOdo({ ...s.lastOdo, ...d.lastOdo });
      let lastCheckIn = s.lastCheckIn;
      if (!lastCheckIn || (d.lastCheckIn && d.lastCheckIn.date >= lastCheckIn.date)) {
        lastCheckIn = d.lastCheckIn || lastCheckIn;
      }
      commit({
        ...s,
        trips: applyOverlay(d.trips),
        buses: d.buses,
        lastOdo,
        lastCheckIn,
      });
    } catch (e) {
      if (/Wrong name or PIN/.test(errText(e))) {
        clearCache();
        sessionRef.current = null;
        setSession(null);
        toast("Your PIN was changed. Ask the office.");
      } else if (!silent) toast(errText(e));
    }
  };

  const sync = async () => {
    const s = sessionRef.current;
    if (syncing.current || !s || (typeof navigator !== "undefined" && !navigator.onLine)) {
      bump();
      return;
    }
    syncing.current = true;
    bump();
    try {
      let q = readQueue();
      while (q.length) {
        const item = q[0];
        let drop = true;
        try {
          if (item.t === "trip") {
            await call(
              driverTrip({
                data: { name: s.name, pin: s.pin, id: item.id, action: item.a, km: item.km, at: item.at },
              }),
            );
          } else {
            await call(driverAdd({ data: { name: s.name, pin: s.pin, kind: item.k, rid: item.rid, obj: item.obj } }));
          }
        } catch (e) {
          const m = errText(e);
          if (!/Network error/.test(m)) noteErr("sync: " + m);
          if (/Wrong name or PIN/.test(m)) {
            toast("Your PIN was changed. Ask the office.");
            drop = false;
            break;
          }
          if (/Photo upload/.test(m) && item.t === "add") {
            item.tries = (item.tries || 0) + 1;
            if (item.tries >= 6) {
              delete item.obj.odoPhoto;
              delete item.obj.receipt;
              item.obj.photoFailed = "1";
              item.tries = 0;
            }
            q[0] = item;
            writeQueue(q);
            drop = false;
            break;
          }
          if (!/not found|Invalid|Unknown|required/i.test(m)) {
            drop = false;
            break;
          }
        }
        if (!drop) break;
        q = readQueue().slice(1);
        writeQueue(q);
        bump();
      }
    } finally {
      syncing.current = false;
      bump();
    }
    if (!readQueue().length) await refresh(true);
  };

  useEffect(() => {
    const onErr = (e: ErrorEvent) => noteErr(e.message);
    const onRej = (e: PromiseRejectionEvent) => noteErr(String((e.reason as Error)?.message || e.reason || ""));
    window.addEventListener("error", onErr);
    window.addEventListener("unhandledrejection", onRej);
    const onNet = () => {
      setOnline(navigator.onLine);
      if (navigator.onLine) void sync();
    };
    window.addEventListener("online", onNet);
    window.addEventListener("offline", onNet);
    setOnline(navigator.onLine);
    const cached = readCache();
    if (cached) {
      cached.trips = applyOverlay(cached.trips);
      commit(cached);
      setReady(true);
      void refresh(true).then(() => sync());
    } else {
      call(driverNames())
        .then((list) => {
          setNames(list);
          setLoginName(list.includes(DEMO_DRIVER) ? DEMO_DRIVER : list[0] || "");
        })
        .catch(() => setLoginErr("Connect to the internet to log in the first time. After that the app works offline too."))
        .finally(() => setReady(true));
    }
    const timer = setInterval(() => {
      setOnline(navigator.onLine);
      if (readQueue().length) void sync();
      bump();
    }, 20000);
    return () => {
      window.removeEventListener("error", onErr);
      window.removeEventListener("unhandledrejection", onRej);
      window.removeEventListener("online", onNet);
      window.removeEventListener("offline", onNet);
      clearInterval(timer);
    };
    // Boot once: later syncs read the latest session from a ref.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const doLogin = async (name: string, pin: string) => {
    if (!navigator.onLine) return toast("Connect to the internet to log in");
    setBusy(true);
    setLoginErr("");
    try {
      const d = await call(driverData({ data: { name, pin } }));
      commit(d);
      screenRef.current = "Home";
    } catch (e) {
      setLoginErr(errText(e));
    } finally {
      setBusy(false);
    }
  };

  const logout = () => {
    if (readQueue().length) return toast("Please wait until everything is synced");
    clearCache();
    sessionRef.current = null;
    setSession(null);
    setDraft(null);
    window.location.reload();
  };

  const openForm = (kind: EntryKind) => {
    if (!session) return;
    if (kind !== "Feedback") screenRef.current = TITLES[kind];
    setDraft(emptyDraft(kind, session));
  };

  const tripAct = (id: string, action: "start" | "finish") => {
    const s = sessionRef.current;
    if (!s) return;
    const distance = action === "finish" ? km : "";
    const rid = uid();
    const item: QueueItem = { t: "trip", id, a: action, km: distance, at: nowHM(), rid };
    const q = readQueue().concat(item);
    if (!writeQueue(q)) return toast("Phone storage is full. Connect and sync first.");
    const trip = s.trips.find((x) => x.id === id);
    pushLog({
      rid,
      label: (action === "start" ? "Trip started · " : "Trip finished · ") + (trip?.customer || ""),
      at: nowHM(),
      day: todayISO(),
    });
    commit({ ...s, trips: applyOverlay(s.trips) });
    setFinId(null);
    setKm("");
    toast(navigator.onLine ? (action === "start" ? "Trip started" : "Trip finished") : "Saved on this phone. It will sync when you are online.");
    bump();
    void sync();
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const s = sessionRef.current;
    const d = draft;
    if (!s || !d) return;
    if (d.kind === "Feedback") {
      const rid = uid();
      const obj = {
        date: todayISO(),
        time: nowHM(),
        message: d.message.trim(),
        screen: screenRef.current,
        device: navigator.userAgent.slice(0, 150),
        version: APP_VERSION,
        errors: readErrs(),
      };
      if (!obj.message) return toast("Tell us what happened");
      if (!writeQueue(readQueue().concat({ t: "add", k: "Feedback", obj, rid }))) {
        return toast("Phone storage is full. Connect and sync first.");
      }
      pushLog({ rid, label: "Feedback sent", at: nowHM(), day: todayISO() });
      toast("Thank you. The office will see it.");
      setDraft(null);
      screenRef.current = "Home";
      bump();
      void sync();
      return;
    }
    const bus = chosenBus(d, s.buses);
    const obj: Record<string, string> = { bus, date: todayISO(), time: nowHM() };
    if (d.kind === "CheckIn") {
      if (!d.photos.odo) return toast("Please take the odometer photo");
      obj.odometer = d.odo;
      obj.odoPhoto = d.photos.odo.url;
    } else if (d.kind === "Expense") {
      obj.category = d.cat;
      obj.notes = d.notes;
      if (d.photos.rec) obj.receipt = d.photos.rec.url;
      if (d.cat === "Fuel") {
        obj.odometer = d.odo;
        obj.liters = d.liters;
        obj.price = d.price;
      } else obj.amount = d.amount;
    } else if (d.kind === "ExtraTrip") {
      Object.assign(obj, {
        date: d.date,
        time: d.time,
        description: d.desc.trim(),
        from: d.from.trim(),
        to: d.to.trim(),
        details: d.details.trim(),
      });
    } else {
      obj.issue = d.issue.trim();
    }
    const used: string[] = [];
    for (const key of ["odo", "rec"]) {
      const p = d.photos[key];
      if (!p?.warn) continue;
      if (!p.ok) return toast("The photo looks " + p.warn.short + ". Retake it or tap Use anyway.");
      used.push(p.warn.short);
    }
    if (used.length) obj.photoWarn = used.join(", ");
    if (!bus) return toast("Enter the bus number");
    const fuel = d.kind === "Expense" && d.cat === "Fuel";
    const odo = d.kind === "CheckIn" || fuel ? Number(obj.odometer) : null;
    if (odo !== null) {
      if (!(odo > 0)) return toast("Enter the odometer reading");
      const last = (s.lastOdo || {})[bus] || 0;
      if (odo < last) return toast("Odometer is lower than the last reading (" + last.toLocaleString() + " km). Please check.");
      if (last && odo - last > 1500 && !window.confirm("This is " + (odo - last).toLocaleString() + " km more than the last reading. Is it correct?")) return;
    }
    let label = "Problem reported";
    if (d.kind === "CheckIn") label = "Check-in · " + bus + " · " + Number(odo).toLocaleString() + " km";
    if (d.kind === "ExtraTrip") label = "Extra trip · " + obj.from + " → " + obj.to;
    if (d.kind === "Expense" && !fuel) label = d.cat + " · AED " + Number(obj.amount).toFixed(2);
    if (fuel) {
      const liters = Number(obj.liters);
      const price = Number(obj.price);
      if (!(liters > 0 && liters <= 300)) return toast("Liters must be between 1 and 300");
      if ((price < 1 || price > 10) && !window.confirm("Price per liter AED " + price + " looks unusual. Is it correct?")) return;
      label = "Fuel · " + bus + " · " + liters + " L · AED " + (Math.round(liters * price * 100) / 100).toFixed(2);
    }
    if (d.kind === "ExtraTrip" && (!obj.description || !obj.from || !obj.to)) return toast("Description, from and to are required");
    if (d.kind === "Issues" && !obj.issue) return toast("Describe the problem");
    const rid = uid();
    if (!writeQueue(readQueue().concat({ t: "add", k: d.kind, obj, rid }))) {
      return toast("Phone storage is full. Connect and sync first.");
    }
    pushLog({ rid, label, at: nowHM(), day: todayISO() });
    const lastOdo = { ...s.lastOdo };
    if (odo) lastOdo[bus] = odo;
    const next: DriverPayload = {
      ...s,
      lastOdo,
      lastCheckIn: d.kind === "CheckIn" ? { bus, date: obj.date, odometer: odo || 0 } : s.lastCheckIn,
    };
    commit(next);
    writeBus(bus);
    toast(navigator.onLine ? "Saved" : "Saved on this phone. It will sync when you are online.");
    setDraft(null);
    screenRef.current = "Home";
    bump();
    void sync();
  };

  if (!ready) {
    return (
      <div className="min-h-screen bg-paper">
        <TopBar title="AVA Driver" sub="Opening your board" />
        <p className="px-4 py-8 text-muted">Loading…</p>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-paper">
        <TopBar
          title="AVA Driver"
          actions={
            <Link to="/" className="inline-flex min-h-11 items-center rounded-lg border border-paper/25 px-3 text-sm font-semibold">
              Home
            </Link>
          }
        />
        <main className="mx-auto max-w-md px-4 py-6">
          <section className="rounded-2xl border border-line bg-card p-4">
            <h1 className="font-display text-3xl tracking-wide">Log in</h1>
            <p className="mt-1 text-sm text-muted">Pick your name. The office sets the PIN.</p>
            {names.length ? (
              <form
                className="mt-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  void doLogin(loginName, loginPin);
                }}
              >
                <Field label="Your name">
                  <SelectInput value={loginName} onChange={(e) => setLoginName(e.target.value)}>
                    {names.map((n) => (
                      <option key={n}>{n}</option>
                    ))}
                  </SelectInput>
                </Field>
                <Field label="PIN">
                  <TextInput
                    value={loginPin}
                    onChange={(e) => setLoginPin(e.target.value)}
                    type="password"
                    inputMode="numeric"
                    autoComplete="off"
                    maxLength={8}
                  />
                </Field>
                <Button type="submit" disabled={busy}>
                  {busy ? "Checking…" : "Log in"}
                </Button>
                {names.includes(DEMO_DRIVER) ? (
                  <Button
                    tone="ghost"
                    className="mt-2"
                    disabled={busy}
                    onClick={() => {
                      setLoginName(DEMO_DRIVER);
                      setLoginPin(DEMO_DRIVER_PIN);
                      void doLogin(DEMO_DRIVER, DEMO_DRIVER_PIN);
                    }}
                  >
                    Continue as {DEMO_DRIVER}
                  </Button>
                ) : null}
                {loginErr ? <p className="mt-3 text-sm font-semibold text-danger">{loginErr}</p> : null}
              </form>
            ) : (
              <p className="mt-4 text-sm text-muted">
                {loginErr || "No drivers have a PIN yet. Ask the office to add one."}
              </p>
            )}
          </section>
        </main>
      </div>
    );
  }

  const q = readQueue();
  const pending = new Set(q.map((i) => i.rid));
  const log = readLog().filter((x) => x.day === todayISO()).slice(0, 8);
  void tick;

  const statusText = !online
    ? q.length
      ? "Offline · " + q.length + " saved on this phone, will sync later"
      : "Offline · you can keep working"
    : q.length
      ? "Online · syncing " + q.length + (q.length > 1 ? " items…" : " item…")
      : "Online · all saved";

  return (
    <div className="min-h-screen bg-paper pb-10">
      <TopBar
        title={session.name}
        sub="AVA Driver"
        actions={
          <button
            type="button"
            onClick={logout}
            className="inline-flex min-h-11 items-center gap-1 rounded-lg border border-paper/25 px-3 text-sm font-semibold"
          >
            <LogOut className="size-4" aria-hidden="true" />
            Log out
          </button>
        }
      />
      <div
        className={
          "px-4 py-2 text-center text-sm font-semibold " +
          (!online ? "bg-danger-soft text-danger" : q.length ? "bg-warn-soft text-warn" : "bg-pine-soft text-pine")
        }
      >
        {statusText}
      </div>
      <main className="mx-auto max-w-xl px-4 py-4">
        <div className="grid grid-cols-2 gap-3">
          <Tile icon={<ClipboardCheck className="size-7" />} label="Daily check-in" onClick={() => openForm("CheckIn")} />
          <Tile icon={<Fuel className="size-7" />} label="Report expense" onClick={() => openForm("Expense")} />
          <Tile icon={<Plus className="size-7" />} label="Extra trip" onClick={() => openForm("ExtraTrip")} />
          <Tile icon={<TriangleAlert className="size-7" />} label="Report problem" onClick={() => openForm("Issues")} />
        </div>

        {log.length ? (
          <>
            <h2 className="mt-6 mb-2 font-display text-xl tracking-wide text-muted">Today's entries</h2>
            <ul className="divide-y divide-line rounded-2xl border border-line bg-card">
              {log.map((x) => (
                <li key={x.rid} className="flex gap-3 px-4 py-3">
                  <span className={pending.has(x.rid) ? "text-warn" : "text-pine"} aria-hidden="true">
                    {pending.has(x.rid) ? "…" : "✓"}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-semibold">{x.label}</span>
                    <span className="text-sm text-muted">
                      {x.at} · {pending.has(x.rid) ? "waiting for signal" : "saved"}
                    </span>
                  </span>
                </li>
              ))}
            </ul>
          </>
        ) : null}

        <h2 className="mt-6 mb-2 font-display text-xl tracking-wide text-muted">My trips</h2>
        {session.trips.length ? (
          session.trips.map((t) => {
            const tone = t.status === "In Progress" ? "go" : t.status === "Completed" ? "ok" : "warn";
            return (
              <article key={t.id} className="mb-3 rounded-2xl border border-line bg-card p-4">
                <Tag tone={tone}>{t.status}</Tag>
                <h3 className="mt-2 font-display text-2xl leading-none tracking-wide">{t.customer}</h3>
                <p className="mt-1 text-sm text-muted">
                  {t.date} {t.startTime} · Bus {t.bus}
                </p>
                <p className="mt-2 text-lg">
                  {t.startLocation} → {t.endLocation}
                </p>
                {t.endTime ? (
                  <p className="text-sm text-muted">
                    Finished {t.endTime}
                    {t.distanceKm ? " · " + t.distanceKm + " km" : ""}
                  </p>
                ) : null}
                {t.status === "Scheduled" ? (
                  <Button className="mt-3" onClick={() => tripAct(t.id, "start")}>
                    Start trip
                  </Button>
                ) : null}
                {t.status === "In Progress" && finId !== t.id ? (
                  <Button tone="pine" className="mt-3" onClick={() => { setFinId(t.id); setKm(""); }}>
                    Finish trip
                  </Button>
                ) : null}
                {t.status === "In Progress" && finId === t.id ? (
                  <div className="mt-3">
                    <Field label="Distance driven (km)">
                      <TextInput value={km} onChange={(e) => setKm(e.target.value)} type="number" inputMode="decimal" />
                    </Field>
                    <Button tone="pine" onClick={() => tripAct(t.id, "finish")}>
                      Confirm finish
                    </Button>
                  </div>
                ) : null}
              </article>
            );
          })
        ) : (
          <p className="rounded-2xl border border-dashed border-line px-4 py-8 text-center text-muted">
            No trips assigned to you right now.
          </p>
        )}

        <Button tone="ghost" className="mt-2" onClick={() => void refresh(false)}>
          <RefreshCw className="size-4" aria-hidden="true" />
          Refresh trips
        </Button>
        <Button tone="ghost" className="mt-2 border-dashed" onClick={() => openForm("Feedback")}>
          Something confusing or not working? Tell us
        </Button>
      </main>

      {draft ? (
        <div className="fixed inset-0 z-30 overflow-y-auto bg-paper">
          <div className="sticky top-0 flex items-center gap-3 border-b-4 border-gold bg-navy px-4 py-3 pt-[max(0.75rem,env(safe-area-inset-top))] text-paper">
            <b className="flex-1 font-display text-2xl font-semibold tracking-wide">{TITLES[draft.kind]}</b>
            <button
              type="button"
              className="min-h-11 rounded-lg border border-paper/25 px-3 text-sm font-semibold"
              onClick={() => {
                setDraft(null);
                screenRef.current = "Home";
              }}
            >
              Close
            </button>
          </div>
          <form onSubmit={submit} className="mx-auto max-w-xl px-4 py-4">
            {draft.kind !== "Feedback" ? (
              <BusField draft={draft} buses={session.buses} onChange={setDraft} />
            ) : null}
            {draft.kind === "CheckIn" ? (
              <>
                <Field label="Odometer reading (km)">
                  <TextInput
                    type="number"
                    inputMode="numeric"
                    required
                    value={draft.odo}
                    onChange={(e) => setDraft({ ...draft, odo: e.target.value })}
                  />
                </Field>
                <OdoHint n={(session.lastOdo || {})[chosenBus(draft, session.buses)] || 0} />
                <PhotoField
                  label="Odometer photo"
                  photo={draft.photos.odo}
                  onPick={async (file) => {
                    try {
                      const stamped = await stampPhoto(file);
                      setDraft({ ...draft, photos: { ...draft.photos, odo: stamped } });
                    } catch {
                      toast("Could not read the photo, try again");
                    }
                  }}
                  onUse={() => {
                    const cur = draft.photos.odo;
                    if (!cur) return;
                    setDraft({ ...draft, photos: { ...draft.photos, odo: { ...cur, ok: true } } });
                  }}
                />
                <Button type="submit">Submit check-in</Button>
              </>
            ) : null}
            {draft.kind === "Expense" ? (
              <>
                <p className="mb-1 text-sm font-semibold text-muted">Expense type</p>
                <div className="mb-3 grid grid-cols-2 gap-2">
                  {CATS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setDraft({ ...draft, cat: c })}
                      className={
                        "min-h-12 rounded-xl border-2 text-base font-bold " +
                        (draft.cat === c ? "border-gold bg-gold text-ink" : "border-line bg-card text-ink")
                      }
                    >
                      {c}
                    </button>
                  ))}
                </div>
                {draft.cat === "Fuel" ? (
                  <>
                    <Field label="Odometer at fueling (km)">
                      <TextInput type="number" inputMode="numeric" required value={draft.odo} onChange={(e) => setDraft({ ...draft, odo: e.target.value })} />
                    </Field>
                    <OdoHint n={(session.lastOdo || {})[chosenBus(draft, session.buses)] || 0} />
                    <Field label="Fuel pumped (liters)">
                      <TextInput type="number" inputMode="decimal" step="any" required value={draft.liters} onChange={(e) => setDraft({ ...draft, liters: e.target.value })} />
                    </Field>
                    <Field label="Price per liter (AED)">
                      <TextInput type="number" inputMode="decimal" step="any" required value={draft.price} onChange={(e) => setDraft({ ...draft, price: e.target.value })} />
                    </Field>
                    <Field label="Total amount (AED)">
                      <TextInput
                        readOnly
                        value={Number(draft.liters) && Number(draft.price) ? (Number(draft.liters) * Number(draft.price)).toFixed(2) : ""}
                        placeholder="Calculated automatically"
                      />
                    </Field>
                  </>
                ) : (
                  <Field label="Amount (AED)">
                    <TextInput type="number" inputMode="decimal" step="any" required value={draft.amount} onChange={(e) => setDraft({ ...draft, amount: e.target.value })} />
                  </Field>
                )}
                <Field label="Details">
                  <TextInput maxLength={200} placeholder="Station name, route, what was done…" value={draft.notes} onChange={(e) => setDraft({ ...draft, notes: e.target.value })} />
                </Field>
                <PhotoField
                  label="Receipt photo (optional)"
                  photo={draft.photos.rec}
                  onPick={async (file) => {
                    try {
                      const stamped = await stampPhoto(file);
                      setDraft({ ...draft, photos: { ...draft.photos, rec: stamped } });
                    } catch {
                      toast("Could not read the photo, try again");
                    }
                  }}
                  onUse={() => {
                    const cur = draft.photos.rec;
                    if (!cur) return;
                    setDraft({ ...draft, photos: { ...draft.photos, rec: { ...cur, ok: true } } });
                  }}
                />
                <Button type="submit">Save expense</Button>
              </>
            ) : null}
            {draft.kind === "ExtraTrip" ? (
              <>
                <Field label="Description note">
                  <TextInput required maxLength={200} placeholder="Special run, pickup, diversion…" value={draft.desc} onChange={(e) => setDraft({ ...draft, desc: e.target.value })} />
                </Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Date">
                    <TextInput type="date" required value={draft.date} onChange={(e) => setDraft({ ...draft, date: e.target.value })} />
                  </Field>
                  <Field label="Time">
                    <TextInput type="time" required value={draft.time} onChange={(e) => setDraft({ ...draft, time: e.target.value })} />
                  </Field>
                </div>
                <Field label="From">
                  <TextInput required maxLength={80} placeholder="Sharjah Industrial" value={draft.from} onChange={(e) => setDraft({ ...draft, from: e.target.value })} />
                </Field>
                <Field label="To">
                  <TextInput required maxLength={80} placeholder="Jebel Ali" value={draft.to} onChange={(e) => setDraft({ ...draft, to: e.target.value })} />
                </Field>
                <Field label="Details (optional)">
                  <TextInput maxLength={200} value={draft.details} onChange={(e) => setDraft({ ...draft, details: e.target.value })} />
                </Field>
                <Button type="submit">Save trip</Button>
              </>
            ) : null}
            {draft.kind === "Issues" ? (
              <>
                <Field label="What is the problem?">
                  <AreaInput required value={draft.issue} onChange={(e) => setDraft({ ...draft, issue: e.target.value })} />
                </Field>
                <Button type="submit">Send report</Button>
              </>
            ) : null}
            {draft.kind === "Feedback" ? (
              <>
                <Field label="What was confusing, slow or not working?">
                  <AreaInput
                    required
                    placeholder="Tell us in your own words. The screen you were on is added automatically."
                    value={draft.message}
                    onChange={(e) => setDraft({ ...draft, message: e.target.value })}
                  />
                </Field>
                <Button type="submit">Send</Button>
              </>
            ) : null}
          </form>
        </div>
      ) : null}
      <Toast text={text} className="bottom-6" />
    </div>
  );
}

function Tile({ icon, label, onClick }: { icon: ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex min-h-28 flex-col items-center justify-center gap-2 rounded-2xl border border-line bg-card px-2 text-center text-base font-bold text-ink active:bg-gold"
    >
      <span className="text-pine">{icon}</span>
      {label}
    </button>
  );
}

function OdoHint({ n }: { n: number }) {
  if (!n) return null;
  return <p className="-mt-2 mb-3 text-sm text-muted">Last reading: {n.toLocaleString()} km</p>;
}

function BusField({
  draft,
  buses,
  onChange,
}: {
  draft: Draft;
  buses: string[];
  onChange: (d: Draft) => void;
}) {
  const picker = (
    <>
      <SelectInput
        value={draft.other ? "__other__" : draft.bus}
        onChange={(e) => {
          const other = e.target.value === "__other__";
          onChange({ ...draft, other, bus: other ? draft.bus : e.target.value, picker: true, chip: false });
        }}
      >
        {buses.map((b) => (
          <option key={b}>{b}</option>
        ))}
        <option value="__other__">Other bus (type number)…</option>
      </SelectInput>
      {draft.other ? (
        <TextInput
          className="mt-2"
          maxLength={30}
          placeholder="Type bus number, e.g. DXB 12345"
          value={draft.otherText}
          onChange={(e) => onChange({ ...draft, otherText: e.target.value })}
        />
      ) : draft.why ? (
        <p className="mt-1 text-sm text-muted">{draft.why}</p>
      ) : null}
    </>
  );
  return (
    <div className="mb-3">
      <span className="mb-1 block text-sm font-semibold text-muted">Bus number</span>
      {draft.chip && !draft.picker ? (
        <div className="flex items-center gap-3 rounded-xl border-2 border-pine bg-card px-3 py-3">
          <b className="font-display text-2xl tracking-wide">{draft.bus}</b>
          <span className="flex-1 text-sm text-muted">{draft.why}</span>
          <button type="button" className="min-h-11 rounded-lg border border-line px-3 text-sm font-semibold" onClick={() => onChange({ ...draft, picker: true })}>
            Change
          </button>
        </div>
      ) : (
        picker
      )}
    </div>
  );
}

function PhotoField({
  label,
  photo,
  onPick,
  onUse,
}: {
  label: string;
  photo?: Stamped;
  onPick: (file: File) => void;
  onUse: () => void;
}) {
  const id = "pf-" + label.replace(/\s+/g, "");
  return (
    <div className="mb-3">
      <span className="mb-1 block text-sm font-semibold text-muted">{label}</span>
      <input
        id={id}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onPick(f);
          e.target.value = "";
        }}
      />
      <Button tone="ghost" onClick={() => document.getElementById(id)?.click()}>
        <Camera className="size-5" aria-hidden="true" />
        {photo ? "Retake photo" : "Take photo"}
      </Button>
      {photo ? (
        <div className="mt-3">
          <img src={photo.url} alt="Stamped odometer or receipt" className="w-full rounded-xl" />
          <p className="mt-1 text-sm text-muted">Stamped {photo.label}</p>
          {!photo.warn ? <p className="text-sm font-semibold text-pine">Photo looks clear</p> : null}
          {photo.warn && photo.ok ? <p className="text-sm text-muted">Using this photo anyway</p> : null}
          {photo.warn && !photo.ok ? (
            <div className="mt-2 rounded-xl border border-gold bg-warn-soft p-3 text-sm text-warn">
              <p className="flex items-start gap-2 font-semibold">
                <CircleAlert className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
                This photo looks {photo.warn.text}
              </p>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <Button tone="ghost" onClick={() => document.getElementById(id)?.click()}>
                  Retake
                </Button>
                <Button tone="ghost" onClick={onUse}>
                  Use anyway
                </Button>
              </div>
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
