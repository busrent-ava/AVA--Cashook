import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import {
  Bus,
  ClipboardList,
  LayoutDashboard,
  LogOut,
  Plus,
  RefreshCw,
  TriangleAlert,
  Users,
} from "lucide-react";
import { Button, Field, Mark, SelectInput, Tag, TextInput, Toast, useToast } from "@/components/ava/ui";
import { call, errText } from "@/lib/ava/call";
import { daysAgo, money, todayISO } from "@/lib/ava/format";
import {
  adminBusAdd,
  adminBusRemove,
  adminDriverRemove,
  adminDriverSave,
  adminEntries,
  adminLists,
  adminLogin,
  adminOverview,
  adminTripAdd,
  adminTripDelete,
  adminTrips,
} from "@/lib/ava/server";
import { clearAdminPin, readAdminPin, writeAdminPin } from "@/lib/ava/store";
import {
  DEMO_DESK_PIN,
  type DriverAccount,
  type EntriesResult,
  type EntryKind,
  type EntryRow,
  type Lists,
  type Overview,
  type Trip,
} from "@/lib/ava/types";

export const Route = createFileRoute("/office")({ component: OfficePage });

const KINDS: { id: EntryKind; label: string }[] = [
  { id: "Expense", label: "Expenses" },
  { id: "CheckIn", label: "Check-ins" },
  { id: "ExtraTrip", label: "Extra trips" },
  { id: "Issues", label: "Problems" },
  { id: "Feedback", label: "Feedback" },
];

type Tab = "today" | "entries" | "trips" | "fleet";

type Filters = { kind: EntryKind; driver: string; from: string; to: string };

function OfficePage() {
  const { text, toast } = useToast();
  const [ready, setReady] = useState(false);
  const [pin, setPin] = useState("");
  const [draftPin, setDraftPin] = useState("");
  const [loginErr, setLoginErr] = useState("");
  const [tab, setTab] = useState<Tab>("today");
  const [filters, setFilters] = useState<Filters>({ kind: "Expense", driver: "", from: daysAgo(7), to: todayISO() });
  const [overview, setOverview] = useState<Overview | null>(null);
  const [entries, setEntries] = useState<EntriesResult | null>(null);
  const [trips, setTrips] = useState<Trip[] | null>(null);
  const [lists, setLists] = useState<Lists | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [photo, setPhoto] = useState<string | null>(null);
  const [tripOpen, setTripOpen] = useState(false);
  const [driverOpen, setDriverOpen] = useState<null | { oldName: string; name: string; pin: string; active: boolean }>(null);
  const [saving, setSaving] = useState(false);
  const [busDraft, setBusDraft] = useState("");
  const [tripForm, setTripForm] = useState({
    customer: "",
    date: todayISO(),
    startTime: "",
    driver: "",
    bus: "",
    startLocation: "",
    endLocation: "",
  });

  useEffect(() => {
    const saved = readAdminPin();
    if (!saved) {
      setReady(true);
      return;
    }
    call(adminLogin({ data: { pin: saved } }))
      .then(() => setPin(saved))
      .catch((e) => {
        if (/Wrong office PIN/.test(errText(e))) clearAdminPin();
        else setLoginErr(errText(e));
      })
      .finally(() => setReady(true));
  }, []);

  useEffect(() => {
    if (!pin) return;
    let cancel = false;
    setLoading(true);
    setError("");
    (async () => {
      try {
        if (tab === "today") {
          const d = await call(adminOverview({ data: { pin } }));
          if (!cancel) setOverview(d);
        } else if (tab === "entries") {
          const [rows, list] = await Promise.all([
            call(adminEntries({ data: { pin, kind: filters.kind, driver: filters.driver, from: filters.from, to: filters.to } })),
            call(adminLists({ data: { pin } })),
          ]);
          if (!cancel) {
            setEntries(rows);
            setLists(list);
          }
        } else if (tab === "trips") {
          const [rows, list] = await Promise.all([
            call(adminTrips({ data: { pin } })),
            call(adminLists({ data: { pin } })),
          ]);
          if (!cancel) {
            setTrips(rows);
            setLists(list);
          }
        } else {
          const list = await call(adminLists({ data: { pin } }));
          if (!cancel) setLists(list);
        }
      } catch (e) {
        if (cancel) return;
        if (/Wrong office PIN/.test(errText(e))) {
          clearAdminPin();
          setPin("");
          setLoginErr("Session ended. Log in again.");
        } else setError(errText(e));
      } finally {
        if (!cancel) setLoading(false);
      }
    })();
    return () => {
      cancel = true;
    };
  }, [pin, tab, filters, reloadKey]);

  const enter = async (p: string) => {
    setSaving(true);
    setLoginErr("");
    try {
      await call(adminLogin({ data: { pin: p } }));
      writeAdminPin(p);
      setPin(p);
    } catch (e) {
      setLoginErr(errText(e));
    } finally {
      setSaving(false);
    }
  };

  const logout = () => {
    clearAdminPin();
    setPin("");
    setOverview(null);
  };

  const reload = () => setReloadKey((n) => n + 1);

  const openDriverEntries = (name: string) => {
    setFilters({ kind: "Expense", driver: name, from: daysAgo(7), to: todayISO() });
    setTab("entries");
  };

  if (!ready) {
    return (
      <div className="min-h-screen bg-paper">
        <header className="border-b-4 border-gold bg-navy px-4 py-4 text-paper">
          <p className="font-display text-2xl tracking-wide">AVA Desk</p>
        </header>
        <p className="px-4 py-8 text-muted">Loading the desk…</p>
      </div>
    );
  }

  if (!pin) {
    return (
      <div className="min-h-screen bg-paper">
        <header className="flex items-center justify-between border-b-4 border-gold bg-navy px-4 py-4 text-paper">
          <p className="font-display text-2xl tracking-wide">AVA Desk</p>
          <Link to="/" className="inline-flex min-h-11 items-center rounded-lg border border-paper/25 px-3 text-sm font-semibold">
            Home
          </Link>
        </header>
        <main className="mx-auto max-w-sm px-4 py-10">
          <Mark />
          <h1 className="mt-6 font-display text-4xl tracking-wide">Office login</h1>
          <p className="mt-1 text-sm text-muted">The desk PIN opens every driver, receipt, and trip.</p>
          <form
            className="mt-5"
            onSubmit={(e) => {
              e.preventDefault();
              void enter(draftPin.trim());
            }}
          >
            <Field label="Office PIN">
              <TextInput
                type="password"
                autoComplete="off"
                value={draftPin}
                onChange={(e) => setDraftPin(e.target.value)}
              />
            </Field>
            <Button type="submit" disabled={saving}>
              {saving ? "Checking…" : "Log in"}
            </Button>
            <Button tone="ghost" className="mt-2" disabled={saving} onClick={() => void enter(DEMO_DESK_PIN)}>
              Use demo desk
            </Button>
            {loginErr ? <p className="mt-3 text-sm font-semibold text-danger">{loginErr}</p> : null}
          </form>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-paper md:grid md:grid-cols-[15rem_1fr]">
      <aside className="hidden border-r border-line bg-navy text-paper md:flex md:min-h-screen md:flex-col md:p-4">
        <Mark light />
        <p className="mt-2 text-sm text-paper/70">Fleet desk</p>
        <nav className="mt-6 flex flex-1 flex-col gap-1">
          <SideLink tab="today" current={tab} setTab={setTab} icon={<LayoutDashboard className="size-4" />} label="Today" />
          <SideLink tab="entries" current={tab} setTab={setTab} icon={<ClipboardList className="size-4" />} label="Entries" />
          <SideLink tab="trips" current={tab} setTab={setTab} icon={<Bus className="size-4" />} label="Trips" />
          <SideLink tab="fleet" current={tab} setTab={setTab} icon={<Users className="size-4" />} label="Drivers" />
        </nav>
        <button type="button" onClick={logout} className="inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-paper/80">
          <LogOut className="size-4" aria-hidden="true" />
          Log out
        </button>
      </aside>

      <div className="min-w-0">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b-4 border-gold bg-navy px-4 py-3 pt-[max(0.75rem,env(safe-area-inset-top))] text-paper md:static">
          <div className="min-w-0 flex-1">
            <p className="font-display text-2xl leading-none tracking-wide">AVA Desk</p>
            <p className="mt-1 text-sm text-paper/70">{overview?.today || "Office board"}</p>
          </div>
          <button type="button" onClick={reload} className="inline-flex min-h-11 items-center gap-1 rounded-lg border border-paper/25 px-3 text-sm font-semibold">
            <RefreshCw className="size-4" aria-hidden="true" />
            Refresh
          </button>
          <button type="button" onClick={logout} className="inline-flex min-h-11 items-center rounded-lg border border-paper/25 px-3 text-sm font-semibold md:hidden">
            Log out
          </button>
        </header>

        <main className="mx-auto max-w-3xl px-4 py-4 pb-28 md:pb-10">
          {loading && !overview && tab === "today" ? <p className="text-muted">Loading…</p> : null}
          {error ? (
            <div className="mb-3 rounded-2xl border border-line bg-card p-4">
              <h2 className="font-display text-2xl tracking-wide">Could not load</h2>
              <p className="mt-1 text-sm text-muted">{error}</p>
              <Button className="mt-3" onClick={reload}>
                Try again
              </Button>
            </div>
          ) : null}

          {tab === "today" && overview ? (
            <TodayView
              data={overview}
              onOpen={openDriverEntries}
            />
          ) : null}

          {tab === "entries" ? (
            <EntriesView
              filters={filters}
              setFilters={setFilters}
              data={entries}
              lists={lists}
              loading={loading}
              onPhoto={setPhoto}
            />
          ) : null}

          {tab === "trips" ? (
            <TripsView
              trips={trips}
              loading={loading}
              onAdd={() => {
                setTripForm({
                  customer: "",
                  date: todayISO(),
                  startTime: "",
                  driver: lists?.drivers.find((d) => d.active)?.name || "",
                  bus: lists?.buses[0] || "",
                  startLocation: "",
                  endLocation: "",
                });
                setTripOpen(true);
              }}
              onDelete={async (id) => {
                if (!window.confirm("Delete this trip?")) return;
                try {
                  await call(adminTripDelete({ data: { pin, id } }));
                  toast("Trip deleted");
                  reload();
                } catch (e) {
                  toast(errText(e));
                }
              }}
            />
          ) : null}

          {tab === "fleet" && lists ? (
            <FleetView
              lists={lists}
              busDraft={busDraft}
              setBusDraft={setBusDraft}
              onEdit={(d) => setDriverOpen(d ? { oldName: d.name, name: d.name, pin: d.pin, active: d.active } : { oldName: "", name: "", pin: "", active: true })}
              onEntries={openDriverEntries}
              onRemove={async (name) => {
                if (!window.confirm("Remove " + name + "? They will no longer be able to log in. Their past entries stay on record.")) return;
                try {
                  await call(adminDriverRemove({ data: { pin, name } }));
                  toast("Driver removed");
                  reload();
                } catch (e) {
                  toast(errText(e));
                }
              }}
              onAddBus={async () => {
                try {
                  await call(adminBusAdd({ data: { pin, bus: busDraft } }));
                  setBusDraft("");
                  toast("Bus added");
                  reload();
                } catch (e) {
                  toast(errText(e));
                }
              }}
              onRemoveBus={async (bus) => {
                if (!window.confirm("Remove bus " + bus + " from the list?")) return;
                try {
                  await call(adminBusRemove({ data: { pin, bus } }));
                  toast("Bus removed");
                  reload();
                } catch (e) {
                  toast(errText(e));
                }
              }}
            />
          ) : null}
          {tab === "fleet" && loading && !lists ? <p className="text-muted">Loading…</p> : null}
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-4 border-t border-line bg-card pb-[env(safe-area-inset-bottom)] md:hidden">
        <NavBtn tab="today" current={tab} setTab={setTab} icon={<LayoutDashboard className="size-5" />} label="Today" />
        <NavBtn tab="entries" current={tab} setTab={setTab} icon={<ClipboardList className="size-5" />} label="Entries" />
        <NavBtn tab="trips" current={tab} setTab={setTab} icon={<Bus className="size-5" />} label="Trips" />
        <NavBtn tab="fleet" current={tab} setTab={setTab} icon={<Users className="size-5" />} label="Drivers" />
      </nav>

      {tripOpen && lists ? (
        <Overlay title="Assign trip" onClose={() => setTripOpen(false)}>
          <Field label="Customer / trip name">
            <TextInput value={tripForm.customer} onChange={(e) => setTripForm({ ...tripForm, customer: e.target.value })} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Date">
              <TextInput type="date" value={tripForm.date} onChange={(e) => setTripForm({ ...tripForm, date: e.target.value })} />
            </Field>
            <Field label="Start time">
              <TextInput type="time" value={tripForm.startTime} onChange={(e) => setTripForm({ ...tripForm, startTime: e.target.value })} />
            </Field>
          </div>
          <Field label="Driver">
            <SelectInput value={tripForm.driver} onChange={(e) => setTripForm({ ...tripForm, driver: e.target.value })}>
              {lists.drivers.filter((d) => d.active).map((d) => (
                <option key={d.name}>{d.name}</option>
              ))}
            </SelectInput>
          </Field>
          <Field label="Bus">
            <SelectInput value={tripForm.bus} onChange={(e) => setTripForm({ ...tripForm, bus: e.target.value })}>
              {lists.buses.map((b) => (
                <option key={b}>{b}</option>
              ))}
            </SelectInput>
          </Field>
          <Field label="From">
            <TextInput value={tripForm.startLocation} onChange={(e) => setTripForm({ ...tripForm, startLocation: e.target.value })} />
          </Field>
          <Field label="To">
            <TextInput value={tripForm.endLocation} onChange={(e) => setTripForm({ ...tripForm, endLocation: e.target.value })} />
          </Field>
          <Button
            disabled={saving}
            onClick={() => {
              void (async () => {
                setSaving(true);
                try {
                  await call(adminTripAdd({ data: { pin, trip: tripForm } }));
                  setTripOpen(false);
                  toast("Trip assigned");
                  reload();
                } catch (e) {
                  toast(errText(e));
                } finally {
                  setSaving(false);
                }
              })();
            }}
          >
            Save trip
          </Button>
        </Overlay>
      ) : null}

      {driverOpen ? (
        <Overlay title={driverOpen.oldName ? "Edit driver" : "Add driver"} onClose={() => setDriverOpen(null)}>
          <Field label="Driver name">
            <TextInput value={driverOpen.name} onChange={(e) => setDriverOpen({ ...driverOpen, name: e.target.value })} />
          </Field>
          <Field label="PIN (4 to 8 digits)">
            <TextInput
              inputMode="numeric"
              maxLength={8}
              value={driverOpen.pin}
              onChange={(e) => setDriverOpen({ ...driverOpen, pin: e.target.value })}
            />
          </Field>
          <Field label="Status">
            <SelectInput
              value={driverOpen.active ? "1" : "0"}
              onChange={(e) => setDriverOpen({ ...driverOpen, active: e.target.value === "1" })}
            >
              <option value="1">Active</option>
              <option value="0">Inactive (cannot log in)</option>
            </SelectInput>
          </Field>
          <Button
            disabled={saving}
            onClick={() => {
              void (async () => {
                setSaving(true);
                try {
                  await call(
                    adminDriverSave({
                      data: {
                        pin,
                        oldName: driverOpen.oldName,
                        name: driverOpen.name,
                        newPin: driverOpen.pin,
                        active: driverOpen.active,
                      },
                    }),
                  );
                  setDriverOpen(null);
                  toast("Saved");
                  reload();
                } catch (e) {
                  toast(errText(e));
                } finally {
                  setSaving(false);
                }
              })();
            }}
          >
            Save
          </Button>
        </Overlay>
      ) : null}

      {photo ? (
        <div className="fixed inset-0 z-40 flex flex-col items-center justify-center bg-navy/90 p-4" onClick={() => setPhoto(null)}>
          <img src={photo} alt="Receipt or odometer" className="max-h-[80vh] max-w-full rounded-xl" />
          <button type="button" className="mt-4 min-h-11 rounded-xl border border-paper px-4 font-semibold text-paper" onClick={() => setPhoto(null)}>
            Close
          </button>
        </div>
      ) : null}
      <Toast text={text} className="md:bottom-8" />
    </div>
  );
}

function SideLink({
  tab,
  current,
  setTab,
  icon,
  label,
}: {
  tab: Tab;
  current: Tab;
  setTab: (t: Tab) => void;
  icon: ReactNode;
  label: string;
}) {
  const on = tab === current;
  return (
    <button
      type="button"
      onClick={() => setTab(tab)}
      className={
        "flex min-h-11 items-center gap-2 rounded-xl px-3 text-left text-sm font-semibold " +
        (on ? "bg-gold text-ink" : "text-paper/80 hover:bg-paper/10")
      }
    >
      {icon}
      {label}
    </button>
  );
}

function NavBtn({
  tab,
  current,
  setTab,
  icon,
  label,
}: {
  tab: Tab;
  current: Tab;
  setTab: (t: Tab) => void;
  icon: ReactNode;
  label: string;
}) {
  const on = tab === current;
  return (
    <button
      type="button"
      onClick={() => setTab(tab)}
      className={"flex min-h-16 flex-col items-center justify-center gap-0.5 text-xs font-bold " + (on ? "text-ink" : "text-muted")}
    >
      <span className={on ? "text-pine" : ""}>{icon}</span>
      {label}
      {on ? <span className="h-0.5 w-6 rounded-full bg-gold" /> : <span className="h-0.5 w-6" />}
    </button>
  );
}

function TodayView({ data, onOpen }: { data: Overview; onOpen: (name: string) => void }) {
  const s = data.summary;
  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        <Tile
          n={s.checkedIn + " / " + s.active}
          label="Drivers checked in"
          tone={s.checkedIn < s.active ? "warn" : "ok"}
        />
        <Tile n={String(s.tripsInProgress)} label="Trips in progress" />
        <Tile n={money(s.spendToday).replace("AED ", "")} label="Spent today (AED)" />
        <Tile n={String(s.issuesToday)} label="Problems reported" tone={s.issuesToday ? "bad" : "idle"} />
      </div>
      <h2 className="mt-5 mb-2 font-display text-xl tracking-wide text-muted">Drivers · {data.today}</h2>
      {data.drivers.length ? (
        data.drivers.map((x) => {
          const tag = !x.active
            ? { tone: "idle" as const, label: "Inactive" }
            : x.trips.inProgress
              ? { tone: "go" as const, label: "On a trip" }
              : x.checkIn
                ? { tone: "ok" as const, label: "Checked in" }
                : { tone: "warn" as const, label: "Not checked in" };
          return (
            <button
              key={x.name}
              type="button"
              onClick={() => onOpen(x.name)}
              className="mb-3 block w-full rounded-2xl border border-line bg-card p-4 text-left"
            >
              <span className="flex items-start justify-between gap-3">
                <span className="font-display text-2xl leading-none tracking-wide">{x.name}</span>
                <Tag tone={tag.tone}>{tag.label}</Tag>
              </span>
              <span className="mt-2 block text-sm text-muted">
                {x.checkIn
                  ? "Bus " + x.checkIn.bus + " · " + x.checkIn.odometer.toLocaleString() + " km · " + x.checkIn.time
                  : "No check-in today"}
              </span>
              <span className="block text-sm text-muted">
                Trips: {x.trips.inProgress} in progress · {x.trips.scheduled} waiting · {x.trips.completed} done today
              </span>
              <span className="block text-sm text-muted">Spent today: {money(x.spendToday)}</span>
              <span className="block text-sm text-muted">Last activity: {x.lastActivity || "none yet"}</span>
            </button>
          );
        })
      ) : (
        <p className="rounded-2xl border border-dashed border-line px-4 py-8 text-center text-muted">No drivers yet. Add one in Drivers.</p>
      )}
    </>
  );
}

function Tile({ n, label, tone }: { n: string; label: string; tone?: "ok" | "warn" | "bad" | "idle" }) {
  return (
    <div className="rounded-2xl border border-line bg-card p-3">
      <b
        className={
          "block font-display text-3xl leading-none tracking-wide " +
          (tone === "warn" ? "text-warn" : tone === "ok" ? "text-pine" : tone === "bad" ? "text-danger" : "text-ink")
        }
      >
        {n}
      </b>
      <span className="mt-1 block text-sm text-muted">{label}</span>
    </div>
  );
}

function EntriesView({
  filters,
  setFilters,
  data,
  lists,
  loading,
  onPhoto,
}: {
  filters: Filters;
  setFilters: (f: Filters) => void;
  data: EntriesResult | null;
  lists: Lists | null;
  loading: boolean;
  onPhoto: (src: string) => void;
}) {
  return (
    <>
      <div className="mb-3 flex gap-2 overflow-x-auto pb-1">
        {KINDS.map((k) => (
          <button
            key={k.id}
            type="button"
            onClick={() => setFilters({ ...filters, kind: k.id })}
            className={
              "min-h-11 shrink-0 rounded-full border px-3 text-sm font-semibold " +
              (filters.kind === k.id ? "border-navy bg-navy text-paper" : "border-line bg-card text-ink")
            }
          >
            {k.label}
          </button>
        ))}
      </div>
      <div className="mb-3 grid grid-cols-2 gap-3 rounded-2xl border border-line bg-card p-3">
        <Field label="Driver">
          <SelectInput value={filters.driver} onChange={(e) => setFilters({ ...filters, driver: e.target.value })}>
            <option value="">All drivers</option>
            {(lists?.drivers || []).map((d) => (
              <option key={d.name} value={d.name}>
                {d.name}
              </option>
            ))}
          </SelectInput>
        </Field>
        <Field label="Quick range">
          <SelectInput
            value=""
            onChange={(e) => {
              if (e.target.value === "") return;
              setFilters({ ...filters, from: daysAgo(Number(e.target.value)), to: todayISO() });
            }}
          >
            <option value="">Custom</option>
            <option value="0">Today</option>
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
          </SelectInput>
        </Field>
        <Field label="From">
          <TextInput type="date" value={filters.from} onChange={(e) => setFilters({ ...filters, from: e.target.value })} />
        </Field>
        <Field label="To">
          <TextInput type="date" value={filters.to} onChange={(e) => setFilters({ ...filters, to: e.target.value })} />
        </Field>
      </div>
      {loading && !data ? <p className="text-muted">Loading…</p> : null}
      {data ? (
        <p className="mb-2 text-sm text-muted">
          {data.count} {data.count === 1 ? "entry" : "entries"}
          {filters.kind === "Expense" ? " · Total " + money(data.total) : ""}
          {data.count > 200 ? " (showing newest 200)" : ""}
        </p>
      ) : null}
      {data && data.rows.length === 0 ? <p className="rounded-2xl border border-dashed border-line px-4 py-8 text-center text-muted">Nothing found for these filters.</p> : null}
      {data?.rows.map((r) => (
        <EntryCard key={r.rid + r.date + r.time} kind={filters.kind} row={r} onPhoto={onPhoto} />
      ))}
    </>
  );
}

function safeImg(url: string) {
  return /^data:image\/(jpeg|jpg|png|webp);base64,/i.test(url) ? url : "";
}

function EntryCard({ kind, row, onPhoto }: { kind: EntryKind; row: EntryRow; onPhoto: (src: string) => void }) {
  const head = row.date + " " + row.time + " · " + row.driver + (row.bus ? " · Bus " + row.bus : "");
  const photo = safeImg(kind === "CheckIn" ? row.odoPhoto : row.receipt);
  return (
    <article className={"mb-3 rounded-2xl border border-line bg-card p-4 " + (kind === "Issues" ? "border-l-4 border-l-danger" : "")}>
      {kind === "Expense" ? (
        <>
          <div className="flex items-start justify-between gap-3">
            <h3 className="font-display text-2xl leading-none tracking-wide">{row.category}</h3>
            <b className="text-lg">{money(row.total)}</b>
          </div>
          {row.category === "Fuel" ? (
            <p className="mt-1 text-sm text-muted">
              {row.liters} L × AED {row.price} · Odometer {row.odometer.toLocaleString()} km
            </p>
          ) : null}
          {row.notes ? <p className="mt-1">{row.notes}</p> : null}
        </>
      ) : null}
      {kind === "CheckIn" ? <h3 className="font-display text-2xl leading-none tracking-wide">Check-in · {row.odometer.toLocaleString()} km</h3> : null}
      {kind === "ExtraTrip" ? (
        <>
          <h3 className="font-display text-2xl leading-none tracking-wide">
            {row.from} → {row.to}
          </h3>
          <p className="mt-1">{row.description}</p>
          {row.details ? <p className="text-sm text-muted">{row.details}</p> : null}
        </>
      ) : null}
      {kind === "Issues" ? (
        <>
          <h3 className="flex items-center gap-2 font-display text-2xl leading-none tracking-wide">
            <TriangleAlert className="size-5 text-danger" aria-hidden="true" />
            Problem reported
          </h3>
          <p className="mt-2">{row.issue}</p>
        </>
      ) : null}
      {kind === "Feedback" ? (
        <>
          <h3 className="font-display text-2xl leading-none tracking-wide">Feedback</h3>
          <p className="mt-1">{row.message}</p>
          <p className="text-sm text-muted">
            Screen: {row.screen} · {row.version}
          </p>
          {row.errors ? <p className="text-sm text-muted">Errors: {row.errors}</p> : null}
        </>
      ) : null}
      <p className="mt-1 text-sm text-muted">{head}</p>
      {row.photoWarn ? (
        <p className="mt-2">
          <Tag tone="warn">Photo: {row.photoWarn}</Tag>
        </p>
      ) : null}
      {row.photoFailed ? (
        <p className="mt-2">
          <Tag tone="bad">Photo failed to upload</Tag>
        </p>
      ) : null}
      {photo ? (
        <button type="button" className="mt-3 block w-full" onClick={() => onPhoto(photo)}>
          <img src={photo} alt={kind === "CheckIn" ? "Odometer" : "Receipt"} className="max-h-64 w-full rounded-xl object-cover" />
        </button>
      ) : null}
      {kind === "Expense" && !row.receipt && !row.photoFailed ? <p className="mt-2 text-sm text-muted">No receipt photo</p> : null}
    </article>
  );
}

function TripsView({
  trips,
  loading,
  onAdd,
  onDelete,
}: {
  trips: Trip[] | null;
  loading: boolean;
  onAdd: () => void;
  onDelete: (id: string) => void;
}) {
  return (
    <>
      <Button onClick={onAdd}>
        <Plus className="size-5" aria-hidden="true" />
        Assign a new trip
      </Button>
      <h2 className="mt-5 mb-2 font-display text-xl tracking-wide text-muted">Trips</h2>
      {loading && !trips ? <p className="text-muted">Loading…</p> : null}
      {trips && trips.length === 0 ? <p className="rounded-2xl border border-dashed border-line px-4 py-8 text-center text-muted">No trips yet.</p> : null}
      {trips?.map((t) => {
        const tone = t.status === "In Progress" ? "go" : t.status === "Completed" ? "ok" : "warn";
        return (
          <article key={t.id} className="mb-3 rounded-2xl border border-line bg-card p-4">
            <div className="flex items-start justify-between gap-3">
              <h3 className="font-display text-2xl leading-none tracking-wide">{t.customer}</h3>
              <Tag tone={tone}>{t.status}</Tag>
            </div>
            <p className="mt-2 text-sm text-muted">
              {t.date} {t.startTime} · {t.driver} · Bus {t.bus}
            </p>
            <p className="mt-1">
              {t.startLocation} → {t.endLocation}
            </p>
            {t.endTime ? (
              <p className="text-sm text-muted">
                Finished {t.endTime}
                {t.distanceKm ? " · " + t.distanceKm + " km" : ""}
              </p>
            ) : null}
            {t.status !== "Completed" ? (
              <button type="button" onClick={() => onDelete(t.id)} className="mt-3 min-h-11 rounded-lg border border-danger/30 px-3 text-sm font-semibold text-danger">
                Delete trip
              </button>
            ) : null}
          </article>
        );
      })}
    </>
  );
}

function FleetView({
  lists,
  busDraft,
  setBusDraft,
  onEdit,
  onEntries,
  onRemove,
  onAddBus,
  onRemoveBus,
}: {
  lists: Lists;
  busDraft: string;
  setBusDraft: (v: string) => void;
  onEdit: (d: DriverAccount | null) => void;
  onEntries: (name: string) => void;
  onRemove: (name: string) => void;
  onAddBus: () => void;
  onRemoveBus: (bus: string) => void;
}) {
  return (
    <>
      <Button onClick={() => onEdit(null)}>
        <Plus className="size-5" aria-hidden="true" />
        Add driver
      </Button>
      <h2 className="mt-5 mb-2 font-display text-xl tracking-wide text-muted">Drivers ({lists.drivers.length})</h2>
      {lists.drivers.length === 0 ? <p className="text-muted">No drivers yet.</p> : null}
      {lists.drivers.map((d) => (
        <article key={d.name} className="mb-3 rounded-2xl border border-line bg-card p-4">
          <div className="flex items-start justify-between gap-3">
            <h3 className="font-display text-2xl leading-none tracking-wide">{d.name}</h3>
            <Tag tone={d.active ? "ok" : "idle"}>{d.active ? "Active" : "Inactive"}</Tag>
          </div>
          <p className="mt-1 text-sm text-muted">PIN: {d.pin}</p>
          <div className="mt-3 grid grid-cols-3 gap-2">
            <Button tone="ghost" onClick={() => onEdit(d)}>
              Edit
            </Button>
            <Button tone="ghost" onClick={() => onEntries(d.name)}>
              Entries
            </Button>
            <Button tone="danger" onClick={() => onRemove(d.name)}>
              Remove
            </Button>
          </div>
        </article>
      ))}
      <h2 className="mt-5 mb-2 font-display text-xl tracking-wide text-muted">Buses ({lists.buses.length})</h2>
      <div className="rounded-2xl border border-line bg-card p-3">
        {lists.buses.length === 0 ? <p className="text-sm text-muted">No buses yet.</p> : null}
        {lists.buses.map((b) => (
          <div key={b} className="flex items-center justify-between gap-3 border-b border-line py-2 last:border-0">
            <span className="flex items-center gap-2 font-semibold">
              <Bus className="size-4 text-pine" aria-hidden="true" />
              {b}
            </span>
            <button type="button" onClick={() => onRemoveBus(b)} className="min-h-11 rounded-lg border border-danger/30 px-3 text-sm font-semibold text-danger">
              Remove
            </button>
          </div>
        ))}
        <div className="mt-3 flex gap-2">
          <TextInput placeholder="New bus number" value={busDraft} onChange={(e) => setBusDraft(e.target.value)} />
          <button type="button" onClick={onAddBus} className="min-h-12 shrink-0 rounded-xl border border-line bg-card px-4 text-sm font-bold">
            Add
          </button>
        </div>
      </div>
    </>
  );
}

function Overlay({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-30 flex items-end justify-center bg-navy/55 sm:items-center" onClick={onClose}>
      <div
        className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-2xl bg-card p-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="font-display text-3xl tracking-wide">{title}</h2>
          <button type="button" onClick={onClose} className="min-h-11 rounded-lg border border-line px-3 text-sm font-semibold">
            Close
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
