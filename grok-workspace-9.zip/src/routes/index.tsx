import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Bus, LayoutDashboard } from "lucide-react";
import { Mark } from "@/components/ava/ui";
import { call } from "@/lib/ava/call";
import { boardPulse } from "@/lib/ava/server";
import { DEMO_DESK_PIN, DEMO_DRIVER, DEMO_DRIVER_PIN, type Pulse } from "@/lib/ava/types";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [pulse, setPulse] = useState<Pulse | null>(null);

  useEffect(() => {
    call(boardPulse())
      .then(setPulse)
      .catch(() => setPulse(null));
  }, []);

  return (
    <main className="mx-auto min-h-screen max-w-3xl px-4 py-8 sm:py-14">
      <Mark large />
      <p className="mt-6 font-display text-5xl leading-none tracking-wide text-ink sm:text-6xl">
        The road and the desk, one board.
      </p>
      <p className="mt-4 max-w-xl text-lg text-muted">
        Drivers check in, log fuel, and run the trips you assign. The office sees who is out, what was spent, and what is still open.
      </p>

      <div className="mt-8 grid gap-3 sm:grid-cols-2">
        <Link
          to="/drive"
          className="group flex min-h-36 flex-col justify-between rounded-2xl border border-line bg-card p-4 transition duration-200 hover:border-pine"
        >
          <span className="flex size-11 items-center justify-center rounded-xl bg-pine-soft text-pine">
            <Bus className="size-6" aria-hidden="true" />
          </span>
          <span>
            <span className="mt-4 block font-display text-3xl tracking-wide text-ink">I'm driving</span>
            <span className="mt-1 block text-sm text-muted">Check-in, fuel, expenses, and your assigned runs.</span>
          </span>
        </Link>
        <Link
          to="/office"
          className="flex min-h-36 flex-col justify-between rounded-2xl border border-line bg-navy p-4 text-paper transition duration-200 hover:brightness-110"
        >
          <span className="flex size-11 items-center justify-center rounded-xl bg-gold text-ink">
            <LayoutDashboard className="size-6" aria-hidden="true" />
          </span>
          <span>
            <span className="mt-4 block font-display text-3xl tracking-wide">Open the desk</span>
            <span className="mt-1 block text-sm text-paper/70">Today's drivers, receipts, trips, and the fleet list.</span>
          </span>
        </Link>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat n={pulse ? String(pulse.checkedIn) : "–"} label="Checked in" />
        <Stat n={pulse ? String(pulse.active) : "–"} label="Active drivers" />
        <Stat n={pulse ? String(pulse.onRoad) : "–"} label="Trips on the road" />
        <Stat n={pulse ? String(pulse.buses) : "–"} label="Buses" />
      </div>

      <section className="mt-6 rounded-2xl border border-line bg-card p-4">
        <h2 className="font-display text-2xl tracking-wide text-ink">Try the demo fleet</h2>
        <p className="mt-1 text-sm text-muted">
          A morning is already on the board: school run done, a shuttle in progress, one driver not checked in.
        </p>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          <p className="rounded-xl bg-paper px-3 py-3 text-sm">
            <span className="block font-semibold text-ink">Driver</span>
            <span className="text-muted">
              {DEMO_DRIVER} · PIN {DEMO_DRIVER_PIN}
            </span>
          </p>
          <p className="rounded-xl bg-paper px-3 py-3 text-sm">
            <span className="block font-semibold text-ink">Desk</span>
            <span className="text-muted">PIN {DEMO_DESK_PIN}</span>
          </p>
        </div>
      </section>
    </main>
  );
}

function Stat({ n, label }: { n: string; label: string }) {
  return (
    <div className="rounded-2xl border border-line bg-card px-3 py-3">
      <b className="block font-display text-3xl leading-none tracking-wide text-ink">{n}</b>
      <span className="mt-1 block text-sm text-muted">{label}</span>
    </div>
  );
}
