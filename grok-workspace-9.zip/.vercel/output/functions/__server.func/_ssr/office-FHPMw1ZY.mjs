import { o as __toESM } from "../_runtime.mjs";
import { r as money, s as todayISO, t as daysAgo } from "./format-DwvAESL7.mjs";
import { J as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as adminTripDelete, E as call, M as useToast, S as adminTripAdd, _ as adminDriverSave, b as adminLogin, c as Mark, d as TextInput, f as Toast, g as adminDriverRemove, h as adminBusRemove, i as DEMO_DESK_PIN, j as errText, l as SelectInput, m as adminBusAdd, r as Button, s as Field, u as Tag, v as adminEntries, w as adminTrips, x as adminOverview, y as adminLists } from "./types-D0s6KlEK.mjs";
import { a as readAdminPin, d as writeAdminPin, t as clearAdminPin } from "./store-CHNOk2tC.mjs";
import { a as LogOut, c as ClipboardList, f as Bus, i as Plus, n as TriangleAlert, o as LayoutDashboard, r as RefreshCw, t as Users } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/office-FHPMw1ZY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KINDS = [
	{
		id: "Expense",
		label: "Expenses"
	},
	{
		id: "CheckIn",
		label: "Check-ins"
	},
	{
		id: "ExtraTrip",
		label: "Extra trips"
	},
	{
		id: "Issues",
		label: "Problems"
	},
	{
		id: "Feedback",
		label: "Feedback"
	}
];
function OfficePage() {
	const { text, toast } = useToast();
	const [ready, setReady] = (0, import_react.useState)(false);
	const [pin, setPin] = (0, import_react.useState)("");
	const [draftPin, setDraftPin] = (0, import_react.useState)("");
	const [loginErr, setLoginErr] = (0, import_react.useState)("");
	const [tab, setTab] = (0, import_react.useState)("today");
	const [filters, setFilters] = (0, import_react.useState)({
		kind: "Expense",
		driver: "",
		from: daysAgo(7),
		to: todayISO()
	});
	const [overview, setOverview] = (0, import_react.useState)(null);
	const [entries, setEntries] = (0, import_react.useState)(null);
	const [trips, setTrips] = (0, import_react.useState)(null);
	const [lists, setLists] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [reloadKey, setReloadKey] = (0, import_react.useState)(0);
	const [photo, setPhoto] = (0, import_react.useState)(null);
	const [tripOpen, setTripOpen] = (0, import_react.useState)(false);
	const [driverOpen, setDriverOpen] = (0, import_react.useState)(null);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [busDraft, setBusDraft] = (0, import_react.useState)("");
	const [tripForm, setTripForm] = (0, import_react.useState)({
		customer: "",
		date: todayISO(),
		startTime: "",
		driver: "",
		bus: "",
		startLocation: "",
		endLocation: ""
	});
	(0, import_react.useEffect)(() => {
		const saved = readAdminPin();
		if (!saved) {
			setReady(true);
			return;
		}
		call(adminLogin({ data: { pin: saved } })).then(() => setPin(saved)).catch((e) => {
			if (/Wrong office PIN/.test(errText(e))) clearAdminPin();
			else setLoginErr(errText(e));
		}).finally(() => setReady(true));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!pin) return;
		let cancel = false;
		setLoading(true);
		setError("");
		(async () => {
			try {
				if (tab === "today") {
					const d = await call(adminOverview({ data: { pin } }));
					if (!cancel) setOverview(d);
				} else if (tab === "entries") {
					const [rows, list] = await Promise.all([call(adminEntries({ data: {
						pin,
						kind: filters.kind,
						driver: filters.driver,
						from: filters.from,
						to: filters.to
					} })), call(adminLists({ data: { pin } }))]);
					if (!cancel) {
						setEntries(rows);
						setLists(list);
					}
				} else if (tab === "trips") {
					const [rows, list] = await Promise.all([call(adminTrips({ data: { pin } })), call(adminLists({ data: { pin } }))]);
					if (!cancel) {
						setTrips(rows);
						setLists(list);
					}
				} else {
					const list = await call(adminLists({ data: { pin } }));
					if (!cancel) setLists(list);
				}
			} catch (e) {
				if (cancel) return;
				if (/Wrong office PIN/.test(errText(e))) {
					clearAdminPin();
					setPin("");
					setLoginErr("Session ended. Log in again.");
				} else setError(errText(e));
			} finally {
				if (!cancel) setLoading(false);
			}
		})();
		return () => {
			cancel = true;
		};
	}, [
		pin,
		tab,
		filters,
		reloadKey
	]);
	const enter = async (p) => {
		setSaving(true);
		setLoginErr("");
		try {
			await call(adminLogin({ data: { pin: p } }));
			writeAdminPin(p);
			setPin(p);
		} catch (e) {
			setLoginErr(errText(e));
		} finally {
			setSaving(false);
		}
	};
	const logout = () => {
		clearAdminPin();
		setPin("");
		setOverview(null);
	};
	const reload = () => setReloadKey((n) => n + 1);
	const openDriverEntries = (name) => {
		setFilters({
			kind: "Expense",
			driver: name,
			from: daysAgo(7),
			to: todayISO()
		});
		setTab("entries");
	};
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b-4 border-gold bg-navy px-4 py-4 text-paper",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl tracking-wide",
				children: "AVA Desk"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-4 py-8 text-muted",
			children: "Loading the desk…"
		})]
	});
	if (!pin) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between border-b-4 border-gold bg-navy px-4 py-4 text-paper",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl tracking-wide",
				children: "AVA Desk"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "inline-flex min-h-11 items-center rounded-lg border border-paper/25 px-3 text-sm font-semibold",
				children: "Home"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-sm px-4 py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 font-display text-4xl tracking-wide",
					children: "Office login"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "The desk PIN opens every driver, receipt, and trip."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-5",
					onSubmit: (e) => {
						e.preventDefault();
						enter(draftPin.trim());
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Office PIN",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								type: "password",
								autoComplete: "off",
								value: draftPin,
								onChange: (e) => setDraftPin(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: saving,
							children: saving ? "Checking…" : "Log in"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							tone: "ghost",
							className: "mt-2",
							disabled: saving,
							onClick: () => void enter(DEMO_DESK_PIN),
							children: "Use demo desk"
						}),
						loginErr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm font-semibold text-danger",
							children: loginErr
						}) : null
					]
				})
			]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper md:grid md:grid-cols-[15rem_1fr]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden border-r border-line bg-navy text-paper md:flex md:min-h-screen md:flex-col md:p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { light: true }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-paper/70",
						children: "Fleet desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "mt-6 flex flex-1 flex-col gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
								tab: "today",
								current: tab,
								setTab,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-4" }),
								label: "Today"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
								tab: "entries",
								current: tab,
								setTab,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-4" }),
								label: "Entries"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
								tab: "trips",
								current: tab,
								setTab,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bus, { className: "size-4" }),
								label: "Trips"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLink, {
								tab: "fleet",
								current: tab,
								setTab,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }),
								label: "Drivers"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: logout,
						className: "inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-paper/80",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Log out"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-20 flex items-center gap-3 border-b-4 border-gold bg-navy px-4 py-3 pt-[max(0.75rem,env(safe-area-inset-top))] text-paper md:static",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl leading-none tracking-wide",
								children: "AVA Desk"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-paper/70",
								children: overview?.today || "Office board"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: reload,
							className: "inline-flex min-h-11 items-center gap-1 rounded-lg border border-paper/25 px-3 text-sm font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Refresh"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: logout,
							className: "inline-flex min-h-11 items-center rounded-lg border border-paper/25 px-3 text-sm font-semibold md:hidden",
							children: "Log out"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "mx-auto max-w-3xl px-4 py-4 pb-28 md:pb-10",
					children: [
						loading && !overview && tab === "today" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: "Loading…"
						}) : null,
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 rounded-2xl border border-line bg-card p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl tracking-wide",
									children: "Could not load"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: error
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "mt-3",
									onClick: reload,
									children: "Try again"
								})
							]
						}) : null,
						tab === "today" && overview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayView, {
							data: overview,
							onOpen: openDriverEntries
						}) : null,
						tab === "entries" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntriesView, {
							filters,
							setFilters,
							data: entries,
							lists,
							loading,
							onPhoto: setPhoto
						}) : null,
						tab === "trips" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TripsView, {
							trips,
							loading,
							onAdd: () => {
								setTripForm({
									customer: "",
									date: todayISO(),
									startTime: "",
									driver: lists?.drivers.find((d) => d.active)?.name || "",
									bus: lists?.buses[0] || "",
									startLocation: "",
									endLocation: ""
								});
								setTripOpen(true);
							},
							onDelete: async (id) => {
								if (!window.confirm("Delete this trip?")) return;
								try {
									await call(adminTripDelete({ data: {
										pin,
										id
									} }));
									toast("Trip deleted");
									reload();
								} catch (e) {
									toast(errText(e));
								}
							}
						}) : null,
						tab === "fleet" && lists ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FleetView, {
							lists,
							busDraft,
							setBusDraft,
							onEdit: (d) => setDriverOpen(d ? {
								oldName: d.name,
								name: d.name,
								pin: d.pin,
								active: d.active
							} : {
								oldName: "",
								name: "",
								pin: "",
								active: true
							}),
							onEntries: openDriverEntries,
							onRemove: async (name) => {
								if (!window.confirm("Remove " + name + "? They will no longer be able to log in. Their past entries stay on record.")) return;
								try {
									await call(adminDriverRemove({ data: {
										pin,
										name
									} }));
									toast("Driver removed");
									reload();
								} catch (e) {
									toast(errText(e));
								}
							},
							onAddBus: async () => {
								try {
									await call(adminBusAdd({ data: {
										pin,
										bus: busDraft
									} }));
									setBusDraft("");
									toast("Bus added");
									reload();
								} catch (e) {
									toast(errText(e));
								}
							},
							onRemoveBus: async (bus) => {
								if (!window.confirm("Remove bus " + bus + " from the list?")) return;
								try {
									await call(adminBusRemove({ data: {
										pin,
										bus
									} }));
									toast("Bus removed");
									reload();
								} catch (e) {
									toast(errText(e));
								}
							}
						}) : null,
						tab === "fleet" && loading && !lists ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: "Loading…"
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 grid grid-cols-4 border-t border-line bg-card pb-[env(safe-area-inset-bottom)] md:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
						tab: "today",
						current: tab,
						setTab,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-5" }),
						label: "Today"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
						tab: "entries",
						current: tab,
						setTab,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-5" }),
						label: "Entries"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
						tab: "trips",
						current: tab,
						setTab,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bus, { className: "size-5" }),
						label: "Trips"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
						tab: "fleet",
						current: tab,
						setTab,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" }),
						label: "Drivers"
					})
				]
			}),
			tripOpen && lists ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
				title: "Assign trip",
				onClose: () => setTripOpen(false),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Customer / trip name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: tripForm.customer,
							onChange: (e) => setTripForm({
								...tripForm,
								customer: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Date",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								type: "date",
								value: tripForm.date,
								onChange: (e) => setTripForm({
									...tripForm,
									date: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Start time",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								type: "time",
								value: tripForm.startTime,
								onChange: (e) => setTripForm({
									...tripForm,
									startTime: e.target.value
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Driver",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
							value: tripForm.driver,
							onChange: (e) => setTripForm({
								...tripForm,
								driver: e.target.value
							}),
							children: lists.drivers.filter((d) => d.active).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: d.name }, d.name))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bus",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
							value: tripForm.bus,
							onChange: (e) => setTripForm({
								...tripForm,
								bus: e.target.value
							}),
							children: lists.buses.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: b }, b))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "From",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: tripForm.startLocation,
							onChange: (e) => setTripForm({
								...tripForm,
								startLocation: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "To",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: tripForm.endLocation,
							onChange: (e) => setTripForm({
								...tripForm,
								endLocation: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: saving,
						onClick: () => {
							(async () => {
								setSaving(true);
								try {
									await call(adminTripAdd({ data: {
										pin,
										trip: tripForm
									} }));
									setTripOpen(false);
									toast("Trip assigned");
									reload();
								} catch (e) {
									toast(errText(e));
								} finally {
									setSaving(false);
								}
							})();
						},
						children: "Save trip"
					})
				]
			}) : null,
			driverOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
				title: driverOpen.oldName ? "Edit driver" : "Add driver",
				onClose: () => setDriverOpen(null),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Driver name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: driverOpen.name,
							onChange: (e) => setDriverOpen({
								...driverOpen,
								name: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "PIN (4 to 8 digits)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							inputMode: "numeric",
							maxLength: 8,
							value: driverOpen.pin,
							onChange: (e) => setDriverOpen({
								...driverOpen,
								pin: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Status",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
							value: driverOpen.active ? "1" : "0",
							onChange: (e) => setDriverOpen({
								...driverOpen,
								active: e.target.value === "1"
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "1",
								children: "Active"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "0",
								children: "Inactive (cannot log in)"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: saving,
						onClick: () => {
							(async () => {
								setSaving(true);
								try {
									await call(adminDriverSave({ data: {
										pin,
										oldName: driverOpen.oldName,
										name: driverOpen.name,
										newPin: driverOpen.pin,
										active: driverOpen.active
									} }));
									setDriverOpen(null);
									toast("Saved");
									reload();
								} catch (e) {
									toast(errText(e));
								} finally {
									setSaving(false);
								}
							})();
						},
						children: "Save"
					})
				]
			}) : null,
			photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 flex flex-col items-center justify-center bg-navy/90 p-4",
				onClick: () => setPhoto(null),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: photo,
					alt: "Receipt or odometer",
					className: "max-h-[80vh] max-w-full rounded-xl"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-4 min-h-11 rounded-xl border border-paper px-4 font-semibold text-paper",
					onClick: () => setPhoto(null),
					children: "Close"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toast, {
				text,
				className: "md:bottom-8"
			})
		]
	});
}
function SideLink({ tab, current, setTab, icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setTab(tab),
		className: "flex min-h-11 items-center gap-2 rounded-xl px-3 text-left text-sm font-semibold " + (tab === current ? "bg-gold text-ink" : "text-paper/80 hover:bg-paper/10"),
		children: [icon, label]
	});
}
function NavBtn({ tab, current, setTab, icon, label }) {
	const on = tab === current;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setTab(tab),
		className: "flex min-h-16 flex-col items-center justify-center gap-0.5 text-xs font-bold " + (on ? "text-ink" : "text-muted"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: on ? "text-pine" : "",
				children: icon
			}),
			label,
			on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-0.5 w-6 rounded-full bg-gold" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-0.5 w-6" })
		]
	});
}
function TodayView({ data, onOpen }) {
	const s = data.summary;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					n: s.checkedIn + " / " + s.active,
					label: "Drivers checked in",
					tone: s.checkedIn < s.active ? "warn" : "ok"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					n: String(s.tripsInProgress),
					label: "Trips in progress"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					n: money(s.spendToday).replace("AED ", ""),
					label: "Spent today (AED)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					n: String(s.issuesToday),
					label: "Problems reported",
					tone: s.issuesToday ? "bad" : "idle"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "mt-5 mb-2 font-display text-xl tracking-wide text-muted",
			children: ["Drivers · ", data.today]
		}),
		data.drivers.length ? data.drivers.map((x) => {
			const tag = !x.active ? {
				tone: "idle",
				label: "Inactive"
			} : x.trips.inProgress ? {
				tone: "go",
				label: "On a trip"
			} : x.checkIn ? {
				tone: "ok",
				label: "Checked in"
			} : {
				tone: "warn",
				label: "Not checked in"
			};
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onOpen(x.name),
				className: "mb-3 block w-full rounded-2xl border border-line bg-card p-4 text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-2xl leading-none tracking-wide",
							children: x.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
							tone: tag.tone,
							children: tag.label
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block text-sm text-muted",
						children: x.checkIn ? "Bus " + x.checkIn.bus + " · " + x.checkIn.odometer.toLocaleString() + " km · " + x.checkIn.time : "No check-in today"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block text-sm text-muted",
						children: [
							"Trips: ",
							x.trips.inProgress,
							" in progress · ",
							x.trips.scheduled,
							" waiting · ",
							x.trips.completed,
							" done today"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block text-sm text-muted",
						children: ["Spent today: ", money(x.spendToday)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block text-sm text-muted",
						children: ["Last activity: ", x.lastActivity || "none yet"]
					})
				]
			}, x.name);
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border border-dashed border-line px-4 py-8 text-center text-muted",
			children: "No drivers yet. Add one in Drivers."
		})
	] });
}
function Tile({ n, label, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-card p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "block font-display text-3xl leading-none tracking-wide " + (tone === "warn" ? "text-warn" : tone === "ok" ? "text-pine" : tone === "bad" ? "text-danger" : "text-ink"),
			children: n
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-sm text-muted",
			children: label
		})]
	});
}
function EntriesView({ filters, setFilters, data, lists, loading, onPhoto }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex gap-2 overflow-x-auto pb-1",
			children: KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilters({
					...filters,
					kind: k.id
				}),
				className: "min-h-11 shrink-0 rounded-full border px-3 text-sm font-semibold " + (filters.kind === k.id ? "border-navy bg-navy text-paper" : "border-line bg-card text-ink"),
				children: k.label
			}, k.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 grid grid-cols-2 gap-3 rounded-2xl border border-line bg-card p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Driver",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
						value: filters.driver,
						onChange: (e) => setFilters({
							...filters,
							driver: e.target.value
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "All drivers"
						}), (lists?.drivers || []).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: d.name,
							children: d.name
						}, d.name))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Quick range",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
						value: "",
						onChange: (e) => {
							if (e.target.value === "") return;
							setFilters({
								...filters,
								from: daysAgo(Number(e.target.value)),
								to: todayISO()
							});
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Custom"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "0",
								children: "Today"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "7",
								children: "Last 7 days"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "30",
								children: "Last 30 days"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "From",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "date",
						value: filters.from,
						onChange: (e) => setFilters({
							...filters,
							from: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "To",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "date",
						value: filters.to,
						onChange: (e) => setFilters({
							...filters,
							to: e.target.value
						})
					})
				})
			]
		}),
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Loading…"
		}) : null,
		data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-2 text-sm text-muted",
			children: [
				data.count,
				" ",
				data.count === 1 ? "entry" : "entries",
				filters.kind === "Expense" ? " · Total " + money(data.total) : "",
				data.count > 200 ? " (showing newest 200)" : ""
			]
		}) : null,
		data && data.rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border border-dashed border-line px-4 py-8 text-center text-muted",
			children: "Nothing found for these filters."
		}) : null,
		data?.rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryCard, {
			kind: filters.kind,
			row: r,
			onPhoto
		}, r.rid + r.date + r.time))
	] });
}
function safeImg(url) {
	return /^data:image\/(jpeg|jpg|png|webp);base64,/i.test(url) ? url : "";
}
function EntryCard({ kind, row, onPhoto }) {
	const head = row.date + " " + row.time + " · " + row.driver + (row.bus ? " · Bus " + row.bus : "");
	const photo = safeImg(kind === "CheckIn" ? row.odoPhoto : row.receipt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mb-3 rounded-2xl border border-line bg-card p-4 " + (kind === "Issues" ? "border-l-4 border-l-danger" : ""),
		children: [
			kind === "Expense" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl leading-none tracking-wide",
						children: row.category
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-lg",
						children: money(row.total)
					})]
				}),
				row.category === "Fuel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						row.liters,
						" L × AED ",
						row.price,
						" · Odometer ",
						row.odometer.toLocaleString(),
						" km"
					]
				}) : null,
				row.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1",
					children: row.notes
				}) : null
			] }) : null,
			kind === "CheckIn" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				className: "font-display text-2xl leading-none tracking-wide",
				children: [
					"Check-in · ",
					row.odometer.toLocaleString(),
					" km"
				]
			}) : null,
			kind === "ExtraTrip" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "font-display text-2xl leading-none tracking-wide",
					children: [
						row.from,
						" → ",
						row.to
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1",
					children: row.description
				}),
				row.details ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: row.details
				}) : null
			] }) : null,
			kind === "Issues" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				className: "flex items-center gap-2 font-display text-2xl leading-none tracking-wide",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-5 text-danger",
					"aria-hidden": "true"
				}), "Problem reported"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: row.issue
			})] }) : null,
			kind === "Feedback" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-2xl leading-none tracking-wide",
					children: "Feedback"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1",
					children: row.message
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Screen: ",
						row.screen,
						" · ",
						row.version
					]
				}),
				row.errors ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: ["Errors: ", row.errors]
				}) : null
			] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: head
			}),
			row.photoWarn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, {
					tone: "warn",
					children: ["Photo: ", row.photoWarn]
				})
			}) : null,
			row.photoFailed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
					tone: "bad",
					children: "Photo failed to upload"
				})
			}) : null,
			photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-3 block w-full",
				onClick: () => onPhoto(photo),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: photo,
					alt: kind === "CheckIn" ? "Odometer" : "Receipt",
					className: "max-h-64 w-full rounded-xl object-cover"
				})
			}) : null,
			kind === "Expense" && !row.receipt && !row.photoFailed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "No receipt photo"
			}) : null
		]
	});
}
function TripsView({ trips, loading, onAdd, onDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: onAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
				className: "size-5",
				"aria-hidden": "true"
			}), "Assign a new trip"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-5 mb-2 font-display text-xl tracking-wide text-muted",
			children: "Trips"
		}),
		loading && !trips ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Loading…"
		}) : null,
		trips && trips.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border border-dashed border-line px-4 py-8 text-center text-muted",
			children: "No trips yet."
		}) : null,
		trips?.map((t) => {
			const tone = t.status === "In Progress" ? "go" : t.status === "Completed" ? "ok" : "warn";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mb-3 rounded-2xl border border-line bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-2xl leading-none tracking-wide",
							children: t.customer
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
							tone,
							children: t.status
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							t.date,
							" ",
							t.startTime,
							" · ",
							t.driver,
							" · Bus ",
							t.bus
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1",
						children: [
							t.startLocation,
							" → ",
							t.endLocation
						]
					}),
					t.endTime ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Finished ",
							t.endTime,
							t.distanceKm ? " · " + t.distanceKm + " km" : ""
						]
					}) : null,
					t.status !== "Completed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onDelete(t.id),
						className: "mt-3 min-h-11 rounded-lg border border-danger/30 px-3 text-sm font-semibold text-danger",
						children: "Delete trip"
					}) : null
				]
			}, t.id);
		})
	] });
}
function FleetView({ lists, busDraft, setBusDraft, onEdit, onEntries, onRemove, onAddBus, onRemoveBus }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: () => onEdit(null),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
				className: "size-5",
				"aria-hidden": "true"
			}), "Add driver"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "mt-5 mb-2 font-display text-xl tracking-wide text-muted",
			children: [
				"Drivers (",
				lists.drivers.length,
				")"
			]
		}),
		lists.drivers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "No drivers yet."
		}) : null,
		lists.drivers.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mb-3 rounded-2xl border border-line bg-card p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl leading-none tracking-wide",
						children: d.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
						tone: d.active ? "ok" : "idle",
						children: d.active ? "Active" : "Inactive"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: ["PIN: ", d.pin]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							tone: "ghost",
							onClick: () => onEdit(d),
							children: "Edit"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							tone: "ghost",
							onClick: () => onEntries(d.name),
							children: "Entries"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							tone: "danger",
							onClick: () => onRemove(d.name),
							children: "Remove"
						})
					]
				})
			]
		}, d.name)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "mt-5 mb-2 font-display text-xl tracking-wide text-muted",
			children: [
				"Buses (",
				lists.buses.length,
				")"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border border-line bg-card p-3",
			children: [
				lists.buses.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "No buses yet."
				}) : null,
				lists.buses.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 border-b border-line py-2 last:border-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bus, {
							className: "size-4 text-pine",
							"aria-hidden": "true"
						}), b]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onRemoveBus(b),
						className: "min-h-11 rounded-lg border border-danger/30 px-3 text-sm font-semibold text-danger",
						children: "Remove"
					})]
				}, b)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						placeholder: "New bus number",
						value: busDraft,
						onChange: (e) => setBusDraft(e.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onAddBus,
						className: "min-h-12 shrink-0 rounded-xl border border-line bg-card px-4 text-sm font-bold",
						children: "Add"
					})]
				})
			]
		})
	] });
}
function Overlay({ title, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-30 flex items-end justify-center bg-navy/55 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-2xl bg-card p-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:rounded-2xl",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl tracking-wide",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "min-h-11 rounded-lg border border-line px-3 text-sm font-semibold",
					children: "Close"
				})]
			}), children]
		})
	});
}
//#endregion
export { OfficePage as component };
