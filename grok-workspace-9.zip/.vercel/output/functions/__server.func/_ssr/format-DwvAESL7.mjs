//#region node_modules/.nitro/vite/services/ssr/assets/format-DwvAESL7.js
function keyOf(s) {
	return String(s ?? "").toLowerCase().replace(/\s+/g, "");
}
function num(v) {
	if (v == null || v === "") return 0;
	const n = typeof v === "number" ? v : Number(v);
	return Number.isFinite(n) ? n : 0;
}
function round2(n) {
	return Math.round(n * 100) / 100;
}
function money(n) {
	return "AED " + (Number.isFinite(n) ? n : 0).toLocaleString(void 0, {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	});
}
function todayISO() {
	return (/* @__PURE__ */ new Date(Date.now() - (/* @__PURE__ */ new Date()).getTimezoneOffset() * 6e4)).toISOString().slice(0, 10);
}
function daysAgo(n) {
	return (/* @__PURE__ */ new Date(Date.now() - n * 864e5 - (/* @__PURE__ */ new Date()).getTimezoneOffset() * 6e4)).toISOString().slice(0, 10);
}
function nowHM() {
	return (/* @__PURE__ */ new Date()).toTimeString().slice(0, 5);
}
function uid() {
	return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
function whenLabel(dt) {
	if (dt === todayISO()) return "today";
	if (dt === daysAgo(1)) return "yesterday";
	return "on " + dt;
}
//#endregion
export { num as a, uid as c, nowHM as i, whenLabel as l, keyOf as n, round2 as o, money as r, todayISO as s, daysAgo as t };
