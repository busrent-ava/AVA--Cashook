import { a as num, n as keyOf, o as round2 } from "./format-DwvAESL7.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-h1_TY2yj.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var ADMIN_PINS = /* @__PURE__ */ new Set(["Avauae@123", "2829"]);
function message(e) {
	return (e instanceof Error ? e.message : String(e)).replace(/^Error:\s*/, "");
}
async function pack(fn) {
	try {
		return {
			ok: true,
			data: await fn()
		};
	} catch (e) {
		return {
			ok: false,
			error: message(e)
		};
	}
}
async function db() {
	const { getSql } = await import("./db-oNKZ1Jb4.mjs");
	return getSql();
}
function assertAdmin(pin) {
	if (!ADMIN_PINS.has(String(pin || "").trim())) throw new Error("Wrong office PIN");
}
async function authDriver(name, pin) {
	const d = (await (await db())`
    select name, pin, active from drivers where name <> ''
  `).find((x) => keyOf(x.name) === keyOf(name) && x.active);
	if (!d || String(d.pin).trim() !== String(pin).trim()) throw new Error("Wrong name or PIN");
	return String(d.name);
}
function blankEntry() {
	return {
		rid: "",
		driver: "",
		date: "",
		time: "",
		bus: "",
		category: "",
		amount: 0,
		odometer: 0,
		liters: 0,
		price: 0,
		notes: "",
		receipt: "",
		total: 0,
		photoWarn: "",
		photoFailed: false,
		odoPhoto: "",
		description: "",
		from: "",
		to: "",
		details: "",
		issue: "",
		message: "",
		screen: "",
		device: "",
		version: "",
		errors: ""
	};
}
function inRange(r, driver, from, to) {
	if (driver && keyOf(r.driver) !== keyOf(driver)) return false;
	const d = String(r.entry_date);
	if (from && d < from) return false;
	if (to && d > to) return false;
	return true;
}
function expenseTotal(category, liters, price, amount) {
	if (category === "Fuel") return round2(num(liters) * num(price));
	return round2(num(amount));
}
async function serverToday() {
	const rows = await (await db())`select current_date::text as d`;
	return String(rows[0]?.d ?? "");
}
function mapTrip(t) {
	return {
		id: String(t.id),
		date: String(t.trip_date),
		startTime: String(t.start_time || ""),
		endTime: String(t.end_time || ""),
		customer: String(t.customer || ""),
		driver: String(t.driver || ""),
		bus: String(t.bus || ""),
		startLocation: String(t.start_location || ""),
		endLocation: String(t.end_location || ""),
		status: String(t.status || "Scheduled"),
		distanceKm: String(t.distance_km || "")
	};
}
async function allTrips() {
	return (await (await db())`
    select id, trip_date::text as trip_date, start_time, end_time, customer, driver, bus,
           start_location, end_location, status, distance_km
    from trips
  `).map(mapTrip);
}
async function busNames() {
	return (await (await db())`select bus from buses order by id`).map((b) => String(b.bus)).filter(Boolean);
}
async function loadDriver(name, pin) {
	const me = await authDriver(name, pin);
	const today = await serverToday();
	const trips = (await allTrips()).filter((t) => keyOf(t.driver) === keyOf(me) && (t.status !== "Completed" || t.date === today)).sort((a, b) => (a.date + a.startTime).localeCompare(b.date + b.startTime));
	const sql = await db();
	const checks = await sql`
    select bus, odometer, driver, entry_date::text as entry_date from checkins
  `;
	const exps = await sql`
    select bus, odometer from expenses
  `;
	const lastOdo = {};
	let lastCheckIn = null;
	for (const r of checks) {
		const odo = num(r.odometer);
		const bus = String(r.bus);
		if (odo > (lastOdo[bus] || 0)) lastOdo[bus] = odo;
		if (keyOf(r.driver) === keyOf(me)) {
			const d = String(r.entry_date);
			if (!lastCheckIn || d >= lastCheckIn.date) lastCheckIn = {
				bus,
				date: d,
				odometer: odo
			};
		}
	}
	for (const r of exps) {
		const odo = num(r.odometer);
		const bus = String(r.bus);
		if (odo > (lastOdo[bus] || 0)) lastOdo[bus] = odo;
	}
	return {
		name: me,
		pin: String(pin).trim(),
		trips,
		buses: await busNames(),
		lastOdo,
		lastCheckIn
	};
}
async function snapshot() {
	const today = await serverToday();
	const sql = await db();
	const drivers = await sql`
    select name, active from drivers where name <> '' order by id
  `;
	const checks = await sql`
    select driver, entry_date::text as entry_date, entry_time, bus, odometer from checkins
  `;
	const exps = await sql`
    select driver, entry_date::text as entry_date, entry_time, category, amount, liters, price from expenses
  `;
	const extras = await sql`
    select driver, entry_date::text as entry_date, entry_time from extra_trips
  `;
	const issues = await sql`
    select driver, entry_date::text as entry_date, entry_time from issues
  `;
	const trips = await allTrips();
	let spend = 0;
	let issueCount = 0;
	let checked = 0;
	let active = 0;
	let inprog = 0;
	for (const r of issues) if (String(r.entry_date) === today) issueCount += 1;
	const cards = drivers.map((d) => {
		const n = keyOf(d.name);
		const isActive = Boolean(d.active);
		const mine = (r) => keyOf(r.driver) === n;
		let todayCheck = null;
		let lastAct = "";
		for (const r of checks.filter(mine)) {
			const dd = String(r.entry_date);
			const tt = String(r.entry_time || "");
			if (dd === today && (!todayCheck || tt >= todayCheck.time)) todayCheck = {
				bus: String(r.bus),
				time: tt,
				odometer: num(r.odometer)
			};
			const st = dd + " " + tt;
			if (st > lastAct) lastAct = st;
		}
		for (const list of [
			exps,
			extras,
			issues
		]) for (const r of list.filter(mine)) {
			const st = String(r.entry_date) + " " + String(r.entry_time || "");
			if (st > lastAct) lastAct = st;
		}
		const tr = {
			scheduled: 0,
			inProgress: 0,
			completed: 0
		};
		for (const t of trips.filter((t) => keyOf(t.driver) === n)) if (t.status === "In Progress") tr.inProgress += 1;
		else if (t.status === "Scheduled" && t.date <= today) tr.scheduled += 1;
		else if (t.status === "Completed" && t.date === today) tr.completed += 1;
		let sp = 0;
		for (const r of exps.filter(mine)) if (String(r.entry_date) === today) sp += expenseTotal(r.category, r.liters, r.price, r.amount);
		sp = round2(sp);
		if (isActive) {
			active += 1;
			if (todayCheck) checked += 1;
		}
		inprog += tr.inProgress;
		spend += sp;
		return {
			name: String(d.name),
			active: isActive,
			checkIn: todayCheck,
			trips: tr,
			spendToday: sp,
			lastActivity: lastAct.trim()
		};
	});
	return {
		today,
		summary: {
			active,
			checkedIn: checked,
			tripsInProgress: inprog,
			spendToday: round2(spend),
			issuesToday: issueCount
		},
		drivers: cards
	};
}
function clip(v, n) {
	return String(v ?? "").slice(0, n);
}
function requireDate(v) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) throw new Error("Invalid date");
	return v;
}
function requireTime(v) {
	if (!/^\d{2}:\d{2}$/.test(v)) throw new Error("Invalid time");
	return v;
}
function photoOrNull(v) {
	if (!v) return null;
	if (!/^data:image\/(jpeg|jpg|png|webp);base64,/i.test(v)) throw new Error("Photo upload failed: bad image");
	if (v.length > 18e5) throw new Error("Photo upload failed: too large");
	return v;
}
async function addEntry(name, pin, kind, obj, rid) {
	const me = await authDriver(name, pin);
	if (!/^[a-z0-9-]{6,48}$/i.test(rid)) throw new Error("Unknown entry");
	if (![
		"CheckIn",
		"Expense",
		"ExtraTrip",
		"Issues",
		"Feedback"
	].includes(kind)) throw new Error("Unknown entry type");
	const sql = await db();
	if (kind === "CheckIn") {
		if ((await sql`select rid from checkins where rid = ${rid} limit 1`).length) return true;
		const bus = clip(obj.bus, 40);
		if (!bus) throw new Error("Bus is required");
		await sql`
      insert into checkins (rid, driver, entry_date, entry_time, bus, odometer, odo_photo, photo_warn, photo_failed)
      values (
        ${rid}, ${me}, ${requireDate(clip(obj.date, 10))}, ${requireTime(clip(obj.time, 8))}, ${bus},
        ${obj.odometer ? num(obj.odometer) : null}, ${photoOrNull(obj.odoPhoto || "")},
        ${clip(obj.photoWarn, 80)}, ${obj.photoFailed === "1"}
      )
    `;
		return true;
	}
	if (kind === "Expense") {
		if ((await sql`select rid from expenses where rid = ${rid} limit 1`).length) return true;
		const bus = clip(obj.bus, 40);
		if (!bus) throw new Error("Bus is required");
		const category = clip(obj.category, 40);
		if (!category) throw new Error("Category is required");
		await sql`
      insert into expenses (
        rid, driver, entry_date, entry_time, bus, category, amount, odometer, liters, price, notes, receipt, photo_warn, photo_failed
      ) values (
        ${rid}, ${me}, ${requireDate(clip(obj.date, 10))}, ${requireTime(clip(obj.time, 8))}, ${bus}, ${category},
        ${obj.amount ? num(obj.amount) : null},
        ${obj.odometer ? num(obj.odometer) : null},
        ${obj.liters ? num(obj.liters) : null},
        ${obj.price ? num(obj.price) : null},
        ${clip(obj.notes, 200)},
        ${photoOrNull(obj.receipt || "")},
        ${clip(obj.photoWarn, 80)},
        ${obj.photoFailed === "1"}
      )
    `;
		return true;
	}
	if (kind === "ExtraTrip") {
		if ((await sql`select rid from extra_trips where rid = ${rid} limit 1`).length) return true;
		const bus = clip(obj.bus, 40);
		if (!bus) throw new Error("Bus is required");
		const description = clip(obj.description, 200);
		if (!description) throw new Error("Description is required");
		await sql`
      insert into extra_trips (rid, driver, entry_date, entry_time, bus, description, from_place, to_place, details)
      values (
        ${rid}, ${me}, ${requireDate(clip(obj.date, 10))}, ${requireTime(clip(obj.time, 8))}, ${bus},
        ${description}, ${clip(obj.from, 80)}, ${clip(obj.to, 80)}, ${clip(obj.details, 200)}
      )
    `;
		return true;
	}
	if (kind === "Issues") {
		if ((await sql`select rid from issues where rid = ${rid} limit 1`).length) return true;
		const issue = clip(obj.issue, 500);
		if (!issue) throw new Error("Issue is required");
		await sql`
      insert into issues (rid, driver, entry_date, entry_time, bus, issue)
      values (
        ${rid}, ${me}, ${requireDate(clip(obj.date, 10))}, ${requireTime(clip(obj.time, 8))},
        ${clip(obj.bus, 40)}, ${issue}
      )
    `;
		return true;
	}
	if ((await sql`select rid from feedback where rid = ${rid} limit 1`).length) return true;
	const messageText = clip(obj.message, 800);
	if (!messageText) throw new Error("Message is required");
	await sql`
    insert into feedback (rid, driver, entry_date, entry_time, message, screen, device, version, errors)
    values (
      ${rid}, ${me}, ${requireDate(clip(obj.date, 10))}, ${requireTime(clip(obj.time, 8))},
      ${messageText}, ${clip(obj.screen, 80)}, ${clip(obj.device, 150)}, ${clip(obj.version, 20)}, ${clip(obj.errors, 400)}
    )
  `;
	return true;
}
async function loadEntries(kind, driver, from, to) {
	const sql = await db();
	const fromD = from || null;
	const toD = to || null;
	if (kind === "Expense") {
		const list = (await sql`
      select rid, driver, entry_date::text as entry_date, entry_time, bus, category, amount, odometer,
             liters, price, notes, receipt, photo_warn, photo_failed
      from expenses
      where (${fromD}::date is null or entry_date >= ${fromD}::date)
        and (${toD}::date is null or entry_date <= ${toD}::date)
      order by entry_date desc, entry_time desc, created_at desc
    `).filter((r) => inRange(r, driver, fromD, toD)).map((r) => {
			const o = blankEntry();
			o.rid = r.rid;
			o.driver = r.driver;
			o.date = String(r.entry_date);
			o.time = r.entry_time;
			o.bus = r.bus;
			o.category = r.category;
			o.amount = num(r.amount);
			o.odometer = num(r.odometer);
			o.liters = num(r.liters);
			o.price = num(r.price);
			o.notes = r.notes;
			o.receipt = r.receipt || "";
			o.photoWarn = r.photo_warn;
			o.photoFailed = Boolean(r.photo_failed);
			o.total = expenseTotal(r.category, r.liters, r.price, r.amount);
			return o;
		});
		return {
			total: round2(list.reduce((s, r) => s + r.total, 0)),
			count: list.length,
			rows: list.slice(0, 200)
		};
	}
	if (kind === "CheckIn") {
		const list = (await sql`
      select rid, driver, entry_date::text as entry_date, entry_time, bus, odometer, odo_photo, photo_warn, photo_failed
      from checkins
      where (${fromD}::date is null or entry_date >= ${fromD}::date)
        and (${toD}::date is null or entry_date <= ${toD}::date)
      order by entry_date desc, entry_time desc, created_at desc
    `).filter((r) => inRange(r, driver, fromD, toD)).map((r) => {
			const o = blankEntry();
			o.rid = r.rid;
			o.driver = r.driver;
			o.date = String(r.entry_date);
			o.time = r.entry_time;
			o.bus = r.bus;
			o.odometer = num(r.odometer);
			o.odoPhoto = r.odo_photo || "";
			o.photoWarn = r.photo_warn;
			o.photoFailed = Boolean(r.photo_failed);
			return o;
		});
		return {
			total: 0,
			count: list.length,
			rows: list.slice(0, 200)
		};
	}
	if (kind === "ExtraTrip") {
		const list = (await sql`
      select rid, driver, entry_date::text as entry_date, entry_time, bus, description, from_place, to_place, details
      from extra_trips
      where (${fromD}::date is null or entry_date >= ${fromD}::date)
        and (${toD}::date is null or entry_date <= ${toD}::date)
      order by entry_date desc, entry_time desc, created_at desc
    `).filter((r) => inRange(r, driver, fromD, toD)).map((r) => {
			const o = blankEntry();
			o.rid = r.rid;
			o.driver = r.driver;
			o.date = String(r.entry_date);
			o.time = r.entry_time;
			o.bus = r.bus;
			o.description = r.description;
			o.from = r.from_place;
			o.to = r.to_place;
			o.details = r.details;
			return o;
		});
		return {
			total: 0,
			count: list.length,
			rows: list.slice(0, 200)
		};
	}
	if (kind === "Issues") {
		const list = (await sql`
      select rid, driver, entry_date::text as entry_date, entry_time, bus, issue from issues
      where (${fromD}::date is null or entry_date >= ${fromD}::date)
        and (${toD}::date is null or entry_date <= ${toD}::date)
      order by entry_date desc, entry_time desc, created_at desc
    `).filter((r) => inRange(r, driver, fromD, toD)).map((r) => {
			const o = blankEntry();
			o.rid = r.rid;
			o.driver = r.driver;
			o.date = String(r.entry_date);
			o.time = r.entry_time;
			o.bus = r.bus;
			o.issue = r.issue;
			return o;
		});
		return {
			total: 0,
			count: list.length,
			rows: list.slice(0, 200)
		};
	}
	const list = (await sql`
    select rid, driver, entry_date::text as entry_date, entry_time, message, screen, device, version, errors
    from feedback
    where (${fromD}::date is null or entry_date >= ${fromD}::date)
      and (${toD}::date is null or entry_date <= ${toD}::date)
    order by entry_date desc, entry_time desc, created_at desc
  `).filter((r) => inRange(r, driver, fromD, toD)).map((r) => {
		const o = blankEntry();
		o.rid = r.rid;
		o.driver = r.driver;
		o.date = String(r.entry_date);
		o.time = r.entry_time;
		o.message = r.message;
		o.screen = r.screen;
		o.device = r.device;
		o.version = r.version;
		o.errors = r.errors;
		return o;
	});
	return {
		total: 0,
		count: list.length,
		rows: list.slice(0, 200)
	};
}
var boardPulse_createServerFn_handler = createServerRpc({
	id: "94805d152c5d23835c2e499d2afc3d6a5ff653c6e2289a971d622f9be32f2e90",
	name: "boardPulse",
	filename: "src/lib/ava/server.ts"
}, (opts) => boardPulse.__executeServer(opts));
var boardPulse = createServerFn({ method: "GET" }).handler(boardPulse_createServerFn_handler, async () => pack(async () => {
	const snap = await snapshot();
	return {
		active: snap.summary.active,
		checkedIn: snap.summary.checkedIn,
		onRoad: snap.summary.tripsInProgress,
		buses: (await busNames()).length
	};
}));
var driverNames_createServerFn_handler = createServerRpc({
	id: "36ca9e44ca5be4e024f99c5239d26894c93a8f5b8b128bc0011eaabd666d81ed",
	name: "driverNames",
	filename: "src/lib/ava/server.ts"
}, (opts) => driverNames.__executeServer(opts));
var driverNames = createServerFn({ method: "GET" }).handler(driverNames_createServerFn_handler, async () => pack(async () => {
	return (await (await db())`
      select name, pin, active from drivers where name <> '' order by id
    `).filter((d) => d.active && String(d.pin) !== "").map((d) => String(d.name));
}));
var driverData_createServerFn_handler = createServerRpc({
	id: "08c58acf2e7d4b932cc3245983436a1c3ee6b19a8d33e1aefe38e18e8709d41b",
	name: "driverData",
	filename: "src/lib/ava/server.ts"
}, (opts) => driverData.__executeServer(opts));
var driverData = createServerFn({ method: "POST" }).validator((input) => input).handler(driverData_createServerFn_handler, async ({ data }) => pack(() => loadDriver(data.name, data.pin)));
var driverTrip_createServerFn_handler = createServerRpc({
	id: "940b8e172e58b18045cf4dfc1a218a3ae6329572f3802283e4b4b318a9c09443",
	name: "driverTrip",
	filename: "src/lib/ava/server.ts"
}, (opts) => driverTrip.__executeServer(opts));
var driverTrip = createServerFn({ method: "POST" }).validator((input) => input).handler(driverTrip_createServerFn_handler, async ({ data }) => pack(async () => {
	const me = await authDriver(data.name, data.pin);
	const sql = await db();
	const t = (await sql`
        select id, driver, start_time from trips where id = ${data.id}
      `).find((x) => keyOf(x.driver) === keyOf(me));
	if (!t) throw new Error("Trip not found");
	if (data.action === "start") {
		await sql`update trips set status = 'In Progress' where id = ${data.id}`;
		if (!t.start_time) await sql`update trips set start_time = ${clip(data.at, 8)} where id = ${data.id}`;
	} else await sql`
          update trips set status = 'Completed', end_time = ${clip(data.at, 8)},
            distance_km = case when ${clip(data.km, 12)} = '' then distance_km else ${clip(data.km, 12)} end
          where id = ${data.id}
        `;
	return true;
}));
var driverAdd_createServerFn_handler = createServerRpc({
	id: "2c0abcd69a3f0fb41f5907e0da85c52511f34443c5808d92da5003c010c0ec68",
	name: "driverAdd",
	filename: "src/lib/ava/server.ts"
}, (opts) => driverAdd.__executeServer(opts));
var driverAdd = createServerFn({ method: "POST" }).validator((input) => input).handler(driverAdd_createServerFn_handler, async ({ data }) => pack(() => addEntry(data.name, data.pin, data.kind, data.obj || {}, data.rid)));
var adminLogin_createServerFn_handler = createServerRpc({
	id: "73b146e2f412142803e63759c91e4c260f029b516df91da005623466477230e5",
	name: "adminLogin",
	filename: "src/lib/ava/server.ts"
}, (opts) => adminLogin.__executeServer(opts));
var adminLogin = createServerFn({ method: "POST" }).validator((input) => input).handler(adminLogin_createServerFn_handler, async ({ data }) => pack(async () => {
	assertAdmin(data.pin);
	return true;
}));
var adminOverview_createServerFn_handler = createServerRpc({
	id: "2bd06c9daa9278b8d94f506f65da4457583132227734773dfdf2a6bc87ba1066",
	name: "adminOverview",
	filename: "src/lib/ava/server.ts"
}, (opts) => adminOverview.__executeServer(opts));
var adminOverview = createServerFn({ method: "POST" }).validator((input) => input).handler(adminOverview_createServerFn_handler, async ({ data }) => pack(async () => {
	assertAdmin(data.pin);
	return snapshot();
}));
var adminEntries_createServerFn_handler = createServerRpc({
	id: "030d66a678fbe2904ce97ad3591785f433fde1852ab07ba587c0bc507570a050",
	name: "adminEntries",
	filename: "src/lib/ava/server.ts"
}, (opts) => adminEntries.__executeServer(opts));
var adminEntries = createServerFn({ method: "POST" }).validator((input) => input).handler(adminEntries_createServerFn_handler, async ({ data }) => pack(async () => {
	assertAdmin(data.pin);
	if (![
		"CheckIn",
		"Expense",
		"ExtraTrip",
		"Issues",
		"Feedback"
	].includes(data.kind)) throw new Error("Unknown entry type");
	return loadEntries(data.kind, data.driver || "", data.from || "", data.to || "");
}));
var adminTrips_createServerFn_handler = createServerRpc({
	id: "3938b003abee0ad84f171ee5558ea8e01fd919edd40d9c1c65cd09bee2a6fed6",
	name: "adminTrips",
	filename: "src/lib/ava/server.ts"
}, (opts) => adminTrips.__executeServer(opts));
var adminTrips = createServerFn({ method: "POST" }).validator((input) => input).handler(adminTrips_createServerFn_handler, async ({ data }) => pack(async () => {
	assertAdmin(data.pin);
	const lim = await (await db())`select (current_date - 14)::text as d`;
	const limit = String(lim[0]?.d ?? "");
	return (await allTrips()).filter((t) => t.status !== "Completed" || t.date >= limit).sort((a, b) => (b.date + b.startTime).localeCompare(a.date + a.startTime)).slice(0, 200);
}));
var adminTripAdd_createServerFn_handler = createServerRpc({
	id: "7682d3aa945c8524e054e673f38d8a379c7f414fd9e70fe6100292a687c9da43",
	name: "adminTripAdd",
	filename: "src/lib/ava/server.ts"
}, (opts) => adminTripAdd.__executeServer(opts));
var adminTripAdd = createServerFn({ method: "POST" }).validator((input) => input).handler(adminTripAdd_createServerFn_handler, async ({ data }) => pack(async () => {
	assertAdmin(data.pin);
	const t = data.trip;
	if (!t.date || !t.customer || !t.driver) throw new Error("Date, customer and driver are required");
	const id = "T" + Date.now().toString(36);
	await (await db())`
        insert into trips (id, trip_date, start_time, end_time, customer, driver, bus, start_location, end_location, status, distance_km)
        values (
          ${id}, ${requireDate(t.date)}, ${clip(t.startTime, 8)}, '', ${clip(t.customer, 120)},
          ${clip(t.driver, 80)}, ${clip(t.bus, 40)}, ${clip(t.startLocation, 120)}, ${clip(t.endLocation, 120)},
          'Scheduled', ''
        )
      `;
	return id;
}));
var adminTripDelete_createServerFn_handler = createServerRpc({
	id: "99c803a3aa2bebf33271f3df1dd26313f7f7564f46842d3010573a1017490884",
	name: "adminTripDelete",
	filename: "src/lib/ava/server.ts"
}, (opts) => adminTripDelete.__executeServer(opts));
var adminTripDelete = createServerFn({ method: "POST" }).validator((input) => input).handler(adminTripDelete_createServerFn_handler, async ({ data }) => pack(async () => {
	assertAdmin(data.pin);
	const sql = await db();
	if (!(await sql`select id from trips where id = ${data.id}`).length) throw new Error("Trip not found");
	await sql`delete from trips where id = ${data.id}`;
	return true;
}));
var adminLists_createServerFn_handler = createServerRpc({
	id: "54356dd0079183007512f9bc7e6573878fb5678ae368fa75fb73606e17f934f0",
	name: "adminLists",
	filename: "src/lib/ava/server.ts"
}, (opts) => adminLists.__executeServer(opts));
var adminLists = createServerFn({ method: "POST" }).validator((input) => input).handler(adminLists_createServerFn_handler, async ({ data }) => pack(async () => {
	assertAdmin(data.pin);
	return {
		drivers: (await (await db())`
        select name, pin, active from drivers where name <> '' order by id
      `).map((d) => ({
			name: String(d.name),
			pin: String(d.pin),
			active: Boolean(d.active)
		})),
		buses: await busNames()
	};
}));
var adminDriverSave_createServerFn_handler = createServerRpc({
	id: "081e12c016e74006434564d86cea6b02142fe74a2503431e0494f8f22b7840bf",
	name: "adminDriverSave",
	filename: "src/lib/ava/server.ts"
}, (opts) => adminDriverSave.__executeServer(opts));
var adminDriverSave = createServerFn({ method: "POST" }).validator((input) => input).handler(adminDriverSave_createServerFn_handler, async ({ data }) => pack(async () => {
	assertAdmin(data.pin);
	const name = clip(data.name, 80).trim();
	const newPin = clip(data.newPin, 8).trim();
	if (!name) throw new Error("Enter the driver name");
	if (!/^\d{4,8}$/.test(newPin)) throw new Error("PIN must be 4 to 8 digits");
	const sql = await db();
	const all = await sql`select id, name from drivers`;
	if (all.find((d) => keyOf(d.name) === keyOf(name) && keyOf(d.name) !== keyOf(data.oldName))) throw new Error("A driver with that name already exists");
	const row = data.oldName ? all.find((d) => keyOf(d.name) === keyOf(data.oldName)) : void 0;
	if (row) await sql`update drivers set name = ${name}, pin = ${newPin}, active = ${data.active !== false} where id = ${row.id}`;
	else await sql`insert into drivers (name, pin, active) values (${name}, ${newPin}, ${data.active !== false})`;
	return true;
}));
var adminDriverRemove_createServerFn_handler = createServerRpc({
	id: "e8c3abdf9d4e1aa3311d58367a7cbb59d2338a6f2ee416536e4dab7c613ec354",
	name: "adminDriverRemove",
	filename: "src/lib/ava/server.ts"
}, (opts) => adminDriverRemove.__executeServer(opts));
var adminDriverRemove = createServerFn({ method: "POST" }).validator((input) => input).handler(adminDriverRemove_createServerFn_handler, async ({ data }) => pack(async () => {
	assertAdmin(data.pin);
	const sql = await db();
	const d = (await sql`select id, name from drivers`).find((x) => keyOf(x.name) === keyOf(data.name));
	if (!d) throw new Error("Driver not found");
	await sql`delete from drivers where id = ${d.id}`;
	return true;
}));
var adminBusAdd_createServerFn_handler = createServerRpc({
	id: "45383fa6374539b8ba97faf6d9bfc84c82013ea45bbf0d373f4827a75b299161",
	name: "adminBusAdd",
	filename: "src/lib/ava/server.ts"
}, (opts) => adminBusAdd.__executeServer(opts));
var adminBusAdd = createServerFn({ method: "POST" }).validator((input) => input).handler(adminBusAdd_createServerFn_handler, async ({ data }) => pack(async () => {
	assertAdmin(data.pin);
	const bus = clip(data.bus, 40).trim();
	if (!bus) throw new Error("Enter the bus number");
	if ((await busNames()).some((b) => keyOf(b) === keyOf(bus))) throw new Error("Bus already in the list");
	await (await db())`insert into buses (bus) values (${bus})`;
	return true;
}));
var adminBusRemove_createServerFn_handler = createServerRpc({
	id: "491fbb447580446391143a416299ce859a25510130b215237d42b46a92983aa5",
	name: "adminBusRemove",
	filename: "src/lib/ava/server.ts"
}, (opts) => adminBusRemove.__executeServer(opts));
var adminBusRemove = createServerFn({ method: "POST" }).validator((input) => input).handler(adminBusRemove_createServerFn_handler, async ({ data }) => pack(async () => {
	assertAdmin(data.pin);
	const sql = await db();
	const b = (await sql`select id, bus from buses`).find((x) => keyOf(x.bus) === keyOf(data.bus));
	if (!b) throw new Error("Bus not found");
	await sql`delete from buses where id = ${b.id}`;
	return true;
}));
//#endregion
export { adminBusAdd_createServerFn_handler, adminBusRemove_createServerFn_handler, adminDriverRemove_createServerFn_handler, adminDriverSave_createServerFn_handler, adminEntries_createServerFn_handler, adminLists_createServerFn_handler, adminLogin_createServerFn_handler, adminOverview_createServerFn_handler, adminTripAdd_createServerFn_handler, adminTripDelete_createServerFn_handler, adminTrips_createServerFn_handler, boardPulse_createServerFn_handler, driverAdd_createServerFn_handler, driverData_createServerFn_handler, driverNames_createServerFn_handler, driverTrip_createServerFn_handler };
