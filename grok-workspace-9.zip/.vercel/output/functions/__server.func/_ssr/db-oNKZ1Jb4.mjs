//#region node_modules/.nitro/vite/services/ssr/assets/db-oNKZ1Jb4.js
var _0002_ava_default = "create table if not exists drivers (\n  id serial primary key,\n  name text not null,\n  pin text not null,\n  active boolean not null default true\n);\n\ncreate table if not exists buses (\n  id serial primary key,\n  bus text not null unique\n);\n\ncreate table if not exists trips (\n  id text primary key,\n  trip_date date not null,\n  start_time text not null default '',\n  end_time text not null default '',\n  customer text not null,\n  driver text not null,\n  bus text not null default '',\n  start_location text not null default '',\n  end_location text not null default '',\n  status text not null default 'Scheduled',\n  distance_km text not null default ''\n);\n\ncreate table if not exists checkins (\n  rid text primary key,\n  driver text not null,\n  entry_date date not null,\n  entry_time text not null default '',\n  bus text not null default '',\n  odometer numeric,\n  odo_photo text,\n  photo_warn text not null default '',\n  photo_failed boolean not null default false,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists expenses (\n  rid text primary key,\n  driver text not null,\n  entry_date date not null,\n  entry_time text not null default '',\n  bus text not null default '',\n  category text not null default '',\n  amount numeric,\n  odometer numeric,\n  liters numeric,\n  price numeric,\n  notes text not null default '',\n  receipt text,\n  photo_warn text not null default '',\n  photo_failed boolean not null default false,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists extra_trips (\n  rid text primary key,\n  driver text not null,\n  entry_date date not null,\n  entry_time text not null default '',\n  bus text not null default '',\n  description text not null default '',\n  from_place text not null default '',\n  to_place text not null default '',\n  details text not null default '',\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists issues (\n  rid text primary key,\n  driver text not null,\n  entry_date date not null,\n  entry_time text not null default '',\n  bus text not null default '',\n  issue text not null default '',\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists feedback (\n  rid text primary key,\n  driver text not null,\n  entry_date date not null,\n  entry_time text not null default '',\n  message text not null default '',\n  screen text not null default '',\n  device text not null default '',\n  version text not null default '',\n  errors text not null default '',\n  created_at timestamptz not null default now()\n);\n\ncreate index if not exists trips_driver_idx on trips (driver);\ncreate index if not exists checkins_date_idx on checkins (entry_date);\ncreate index if not exists expenses_date_idx on expenses (entry_date);\n\ninsert into drivers (name, pin, active)\nselect 'Rashid Khan', '1234', true\nwhere not exists (select 1 from drivers where name = 'Rashid Khan');\n\ninsert into drivers (name, pin, active)\nselect 'Faisal Noor', '2468', true\nwhere not exists (select 1 from drivers where name = 'Faisal Noor');\n\ninsert into drivers (name, pin, active)\nselect 'Omar Saeed', '1357', true\nwhere not exists (select 1 from drivers where name = 'Omar Saeed');\n\ninsert into drivers (name, pin, active)\nselect 'Hamad Ali', '9753', false\nwhere not exists (select 1 from drivers where name = 'Hamad Ali');\n\ninsert into buses (bus) values ('101') on conflict (bus) do nothing;\ninsert into buses (bus) values ('214') on conflict (bus) do nothing;\ninsert into buses (bus) values ('318') on conflict (bus) do nothing;\ninsert into buses (bus) values ('DXB-07') on conflict (bus) do nothing;\n\ninsert into trips (id, trip_date, start_time, end_time, customer, driver, bus, start_location, end_location, status, distance_km)\nselect 'T-morning-school', current_date, '06:15', '08:40', 'Al Noor School run', 'Rashid Khan', '101', 'Al Nahda depot', 'Al Noor School', 'Completed', '42'\nwhere not exists (select 1 from trips where id = 'T-morning-school');\n\ninsert into trips (id, trip_date, start_time, end_time, customer, driver, bus, start_location, end_location, status, distance_km)\nselect 'T-jebel', current_date, '09:10', '', 'Port staff shuttle', 'Faisal Noor', '214', 'Dubai Mall', 'Jebel Ali', 'In Progress', ''\nwhere not exists (select 1 from trips where id = 'T-jebel');\n\ninsert into trips (id, trip_date, start_time, end_time, customer, driver, bus, start_location, end_location, status, distance_km)\nselect 'T-airport', current_date, '14:00', '', 'Airport crew', 'Omar Saeed', '318', 'Sharjah Industrial', 'DXB Terminal 3', 'Scheduled', ''\nwhere not exists (select 1 from trips where id = 'T-airport');\n\ninsert into trips (id, trip_date, start_time, end_time, customer, driver, bus, start_location, end_location, status, distance_km)\nselect 'T-evening', current_date, '16:30', '', 'Evening school return', 'Rashid Khan', '101', 'Al Noor School', 'Al Nahda depot', 'Scheduled', ''\nwhere not exists (select 1 from trips where id = 'T-evening');\n\ninsert into checkins (rid, driver, entry_date, entry_time, bus, odometer)\nselect 'seed-ci-rashid', 'Rashid Khan', current_date, '05:42', '101', 184320\nwhere not exists (select 1 from checkins where rid = 'seed-ci-rashid');\n\ninsert into checkins (rid, driver, entry_date, entry_time, bus, odometer)\nselect 'seed-ci-faisal', 'Faisal Noor', current_date, '06:05', '214', 96210\nwhere not exists (select 1 from checkins where rid = 'seed-ci-faisal');\n\ninsert into expenses (rid, driver, entry_date, entry_time, bus, category, odometer, liters, price, notes)\nselect 'seed-ex-fuel', 'Faisal Noor', current_date, '07:18', '214', 'Fuel', 96280, 86.4, 2.89, 'ENOC Al Quoz'\nwhere not exists (select 1 from expenses where rid = 'seed-ex-fuel');\n\ninsert into expenses (rid, driver, entry_date, entry_time, bus, category, amount, notes)\nselect 'seed-ex-tyre', 'Rashid Khan', current_date, '08:55', '101', 'Tyre', 180, 'Front right pressure'\nwhere not exists (select 1 from expenses where rid = 'seed-ex-tyre');\n\ninsert into extra_trips (rid, driver, entry_date, entry_time, bus, description, from_place, to_place, details)\nselect 'seed-xt-rashid', 'Rashid Khan', current_date, '09:05', '101', 'Parent pickup after assembly', 'Al Noor School', 'Mirdif villa gate', 'Two students, office approved'\nwhere not exists (select 1 from extra_trips where rid = 'seed-xt-rashid');\n\ninsert into issues (rid, driver, entry_date, entry_time, bus, issue)\nselect 'seed-is-omar', 'Omar Saeed', current_date, '05:10', '318', 'Air conditioning is weak on the rear rows.'\nwhere not exists (select 1 from issues where rid = 'seed-is-omar');\n\ninsert into feedback (rid, driver, entry_date, entry_time, message, screen, device, version)\nselect 'seed-fb', 'Faisal Noor', current_date, '07:40', 'Fuel screen is clear. The odometer hint helped.', 'Report expense', 'seed', 'v2.0'\nwhere not exists (select 1 from feedback where rid = 'seed-fb');\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_ava.sql": _0002_ava_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
//#endregion
export { getSql };
