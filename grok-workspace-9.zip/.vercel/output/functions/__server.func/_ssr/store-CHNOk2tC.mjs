//#region node_modules/.nitro/vite/services/ssr/assets/store-CHNOk2tC.js
var QK = "ava_q";
var LOG = "ava_log";
var CACHE = "ava_cache";
var ERRS = "ava_errs";
var BUS = "ava_bus";
var ADMIN = "ava_admin_pin";
function read(key) {
	if (typeof window === "undefined") return null;
	try {
		return localStorage.getItem(key);
	} catch {
		return null;
	}
}
function write(key, value) {
	try {
		localStorage.setItem(key, value);
		return true;
	} catch {
		return false;
	}
}
function readQueue() {
	try {
		return JSON.parse(read(QK) || "[]");
	} catch {
		return [];
	}
}
function writeQueue(q) {
	return write(QK, JSON.stringify(q));
}
function readLog() {
	try {
		return JSON.parse(read(LOG) || "[]");
	} catch {
		return [];
	}
}
function pushLog(item) {
	write(LOG, JSON.stringify([item, ...readLog()].slice(0, 15)));
}
function readCache() {
	try {
		return JSON.parse(read(CACHE) || "null");
	} catch {
		return null;
	}
}
function writeCache(s) {
	write(CACHE, JSON.stringify(s));
}
function clearCache() {
	try {
		localStorage.removeItem(CACHE);
	} catch {}
}
function noteErr(m) {
	try {
		const a = JSON.parse(read(ERRS) || "[]");
		a.unshift((/* @__PURE__ */ new Date()).toTimeString().slice(0, 5) + " " + String(m).slice(0, 80));
		write(ERRS, JSON.stringify(a.slice(0, 6)));
	} catch {}
}
function readErrs() {
	try {
		return JSON.parse(read(ERRS) || "[]").join(" | ");
	} catch {
		return "";
	}
}
function readBus() {
	return read(BUS) || "";
}
function writeBus(bus) {
	write(BUS, bus);
}
function readAdminPin() {
	return read(ADMIN) || "";
}
function writeAdminPin(pin) {
	write(ADMIN, pin);
}
function clearAdminPin() {
	try {
		localStorage.removeItem(ADMIN);
	} catch {}
}
//#endregion
export { readAdminPin as a, readErrs as c, writeAdminPin as d, writeBus as f, pushLog as i, readLog as l, writeQueue as m, clearCache as n, readBus as o, writeCache as p, noteErr as r, readCache as s, clearAdminPin as t, readQueue as u };
