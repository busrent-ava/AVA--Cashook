import { o as __toESM } from "../_runtime.mjs";
import { J as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/types-D0s6KlEK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Mark({ light = false, large = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex flex-col leading-none", light ? "text-paper" : "text-pine"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("font-display font-bold tracking-widest", large ? "text-5xl" : "text-3xl"),
			children: "AVA"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 h-1 w-full rounded-full bg-gold" })]
	});
}
var tones = {
	gold: "bg-gold text-ink hover:brightness-95",
	pine: "bg-pine text-paper hover:brightness-110",
	ghost: "border border-line bg-card text-ink hover:bg-paper",
	danger: "border border-danger/30 bg-card text-danger hover:bg-danger-soft",
	navy: "border border-paper/20 bg-transparent text-paper hover:bg-paper/10"
};
function Button({ tone = "gold", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl px-4 text-base font-semibold transition duration-200 disabled:opacity-50", tones[tone], className),
		...props
	});
}
var control = "w-full min-h-12 rounded-xl border border-line bg-paper px-3 text-base text-ink outline-none focus:border-pine";
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mb-3 block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-sm font-semibold text-muted",
			children: label
		}), children]
	});
}
function TextInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn(control, props.className)
	});
}
function SelectInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: cn(control, props.className)
	});
}
function AreaInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cn(control, "min-h-28 py-3", props.className)
	});
}
function Tag({ tone, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold", tone === "ok" && "bg-pine-soft text-pine", tone === "go" && "bg-pine-soft text-pine", tone === "warn" && "bg-warn-soft text-warn", tone === "bad" && "bg-danger-soft text-danger", tone === "idle" && "bg-line text-ink"),
		children
	});
}
function Toast({ text, className }) {
	if (!text) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "status",
		className: cn("fixed bottom-24 left-1/2 z-50 max-w-[90vw] -translate-x-1/2 rounded-xl bg-navy px-4 py-3 text-center text-sm font-semibold text-paper", className),
		children: text
	});
}
function useToast() {
	const [text, setText] = (0, import_react.useState)("");
	const timer = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => () => {
		if (timer.current) clearTimeout(timer.current);
	}, []);
	const toast = (m) => {
		setText(m);
		if (timer.current) clearTimeout(timer.current);
		timer.current = setTimeout(() => setText(""), 3200);
	};
	return {
		text,
		toast
	};
}
function TopBar({ title, sub, actions }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-20 flex items-center gap-3 border-b-4 border-gold bg-navy px-4 py-3 pt-[max(0.75rem,env(safe-area-inset-top))] text-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl leading-none tracking-wide",
				children: title
			}), sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 truncate text-sm text-paper/70",
				children: sub
			}) : null]
		}), actions]
	});
}
async function call(p) {
	let r;
	try {
		r = await p;
	} catch {
		throw new Error("Network error");
	}
	if (!r.ok) throw new Error(r.error);
	return r.data;
}
function errText(e) {
	return (e instanceof Error ? e.message : String(e)).replace(/^Error:\s*/, "");
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var boardPulse = createServerFn({ method: "GET" }).handler(createSsrRpc("94805d152c5d23835c2e499d2afc3d6a5ff653c6e2289a971d622f9be32f2e90"));
var driverNames = createServerFn({ method: "GET" }).handler(createSsrRpc("36ca9e44ca5be4e024f99c5239d26894c93a8f5b8b128bc0011eaabd666d81ed"));
var driverData = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("08c58acf2e7d4b932cc3245983436a1c3ee6b19a8d33e1aefe38e18e8709d41b"));
var driverTrip = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("940b8e172e58b18045cf4dfc1a218a3ae6329572f3802283e4b4b318a9c09443"));
var driverAdd = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("2c0abcd69a3f0fb41f5907e0da85c52511f34443c5808d92da5003c010c0ec68"));
var adminLogin = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("73b146e2f412142803e63759c91e4c260f029b516df91da005623466477230e5"));
var adminOverview = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("2bd06c9daa9278b8d94f506f65da4457583132227734773dfdf2a6bc87ba1066"));
var adminEntries = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("030d66a678fbe2904ce97ad3591785f433fde1852ab07ba587c0bc507570a050"));
var adminTrips = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("3938b003abee0ad84f171ee5558ea8e01fd919edd40d9c1c65cd09bee2a6fed6"));
var adminTripAdd = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("7682d3aa945c8524e054e673f38d8a379c7f414fd9e70fe6100292a687c9da43"));
var adminTripDelete = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("99c803a3aa2bebf33271f3df1dd26313f7f7564f46842d3010573a1017490884"));
var adminLists = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("54356dd0079183007512f9bc7e6573878fb5678ae368fa75fb73606e17f934f0"));
var adminDriverSave = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("081e12c016e74006434564d86cea6b02142fe74a2503431e0494f8f22b7840bf"));
var adminDriverRemove = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("e8c3abdf9d4e1aa3311d58367a7cbb59d2338a6f2ee416536e4dab7c613ec354"));
var adminBusAdd = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("45383fa6374539b8ba97faf6d9bfc84c82013ea45bbf0d373f4827a75b299161"));
var adminBusRemove = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("491fbb447580446391143a416299ce859a25510130b215237d42b46a92983aa5"));
var APP_VERSION = "v2.0";
var DEMO_DRIVER = "Rashid Khan";
var DEMO_DRIVER_PIN = "1234";
var DEMO_DESK_PIN = "2829";
//#endregion
export { driverTrip as A, adminTripDelete as C, driverAdd as D, call as E, useToast as M, driverData as O, adminTripAdd as S, boardPulse as T, adminDriverSave as _, DEMO_DRIVER as a, adminLogin as b, Mark as c, TextInput as d, Toast as f, adminDriverRemove as g, adminBusRemove as h, DEMO_DESK_PIN as i, errText as j, driverNames as k, SelectInput as l, adminBusAdd as m, AreaInput as n, DEMO_DRIVER_PIN as o, TopBar as p, Button as r, Field as s, APP_VERSION as t, Tag as u, adminEntries as v, adminTrips as w, adminOverview as x, adminLists as y };
