import { o as __toESM } from "../_runtime.mjs";
import { c as uid, i as nowHM, l as whenLabel, n as keyOf, s as todayISO } from "./format-DwvAESL7.mjs";
import { J as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as driverTrip, D as driverAdd, E as call, M as useToast, O as driverData, a as DEMO_DRIVER, d as TextInput, f as Toast, j as errText, k as driverNames, l as SelectInput, n as AreaInput, o as DEMO_DRIVER_PIN, p as TopBar, r as Button, s as Field, t as APP_VERSION, u as Tag } from "./types-D0s6KlEK.mjs";
import { c as readErrs, f as writeBus, i as pushLog, l as readLog, m as writeQueue, n as clearCache, o as readBus, p as writeCache, r as noteErr, s as readCache, u as readQueue } from "./store-CHNOk2tC.mjs";
import { a as LogOut, d as Camera, i as Plus, l as ClipboardCheck, n as TriangleAlert, r as RefreshCw, s as Fuel, u as CircleAlert } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/drive-C86utEOX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function analyzeGray(g, w, h) {
	const hist = new Array(256).fill(0);
	for (let i = 0; i < g.length; i++) hist[g[i]]++;
	const pct = (p) => {
		let t = g.length * p;
		let s = 0;
		for (let v = 0; v < 256; v++) {
			s += hist[v];
			if (s >= t) return v;
		}
		return 255;
	};
	const p99 = pct(.99);
	const range = p99 - pct(.01);
	const gh = new Array(512).fill(0);
	let n = 0;
	for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
		const i = y * w + x;
		const gx = g[i + 1] - g[i - 1];
		const gy = g[i + w] - g[i - w];
		gh[Math.min(511, Math.round(Math.sqrt(gx * gx + gy * gy)))]++;
		n++;
	}
	let s = 0;
	let g995 = 0;
	for (let v = 0; v < 512; v++) {
		s += gh[v];
		if (s >= n * .995) {
			g995 = v;
			break;
		}
	}
	if (p99 < 100) return {
		short: "too dark",
		text: "too dark. Turn on a light or move to a brighter spot."
	};
	if (range < 40) return {
		short: "washed out",
		text: "washed out. Tilt the phone to avoid glare."
	};
	if (range > 0 && g995 / range < .5) return {
		short: "blurry",
		text: "blurry. Hold the phone steady and tap the screen to focus."
	};
	return null;
}
function checkQuality(canvas) {
	try {
		const w = Math.min(640, canvas.width);
		const h = Math.max(1, Math.round(canvas.height * w / canvas.width));
		const t = document.createElement("canvas");
		t.width = w;
		t.height = h;
		const x = t.getContext("2d");
		if (!x) return null;
		x.drawImage(canvas, 0, 0, w, h);
		const px = x.getImageData(0, 0, w, h).data;
		const g = new Uint8Array(w * h);
		for (let i = 0; i < g.length; i++) g[i] = .299 * px[i * 4] + .587 * px[i * 4 + 1] + .114 * px[i * 4 + 2];
		return analyzeGray(g, w, h);
	} catch {
		return null;
	}
}
function stampPhoto(file) {
	return new Promise((ok, no) => {
		const img = new Image();
		const u = URL.createObjectURL(file);
		img.onload = () => {
			const sc = Math.min(1, 900 / Math.max(img.width, img.height));
			const w = Math.max(1, Math.round(img.width * sc));
			const h = Math.max(1, Math.round(img.height * sc));
			const c = document.createElement("canvas");
			c.width = w;
			c.height = h;
			const x = c.getContext("2d");
			if (!x) {
				URL.revokeObjectURL(u);
				no(/* @__PURE__ */ new Error("photo"));
				return;
			}
			x.drawImage(img, 0, 0, w, h);
			const warn = checkQuality(c);
			const t = /* @__PURE__ */ new Date();
			const label = t.toLocaleDateString("en-GB") + " " + t.toTimeString().slice(0, 8);
			const fs = Math.max(14, Math.round(w / 26));
			const pad = Math.round(fs / 2);
			x.font = "bold " + fs + "px sans-serif";
			x.textBaseline = "middle";
			const width = x.measureText(label).width + pad * 2;
			x.fillStyle = "rgba(0,0,0,0.65)";
			x.fillRect(0, h - fs - pad * 2, width, fs + pad * 2);
			x.fillStyle = "#ffd23f";
			x.fillText(label, pad, h - fs / 2 - pad);
			URL.revokeObjectURL(u);
			ok({
				url: c.toDataURL("image/jpeg", .6),
				label,
				warn,
				ok: false
			});
		};
		img.onerror = () => {
			URL.revokeObjectURL(u);
			no(/* @__PURE__ */ new Error("photo"));
		};
		img.src = u;
	});
}
var CATS = [
	"Fuel",
	"Maintenance",
	"Tyre",
	"Other"
];
var TITLES = {
	CheckIn: "Daily check-in",
	Expense: "Report expense",
	ExtraTrip: "Extra trip",
	Issues: "Report a problem",
	Feedback: "Tell us what is confusing"
};
function applyOverlay(trips) {
	const next = trips.map((t) => ({ ...t }));
	for (const i of readQueue()) {
		if (i.t !== "trip") continue;
		const t = next.find((x) => x.id === i.id);
		if (!t) continue;
		if (i.a === "start") {
			t.status = "In Progress";
			if (!t.startTime) t.startTime = i.at;
		} else {
			t.status = "Completed";
			t.endTime = i.at;
			if (i.km) t.distanceKm = i.km;
		}
	}
	return next;
}
function mergeOdo(base) {
	const last = { ...base };
	for (const i of readQueue()) {
		if (i.t !== "add" || !i.obj.odometer) continue;
		const o = Number(i.obj.odometer);
		if (o > (last[i.obj.bus] || 0)) last[i.obj.bus] = o;
	}
	return last;
}
function busSuggestion(kind, s) {
	const ok = (b) => Boolean(b) && s.buses.includes(b);
	if (kind === "CheckIn" && s.lastCheckIn && ok(s.lastCheckIn.bus)) return [
		s.lastCheckIn.bus,
		"Same bus as your check-in " + whenLabel(s.lastCheckIn.date),
		true
	];
	const run = s.trips.find((x) => x.status === "In Progress" && ok(x.bus));
	if (run) return [
		run.bus,
		"Auto-selected: your trip in progress",
		false
	];
	const next = s.trips.find((x) => x.status === "Scheduled" && ok(x.bus));
	if (next) return [
		next.bus,
		"Auto-selected: your next scheduled trip",
		false
	];
	const last = readBus();
	if (ok(last)) return [
		last,
		"Auto-selected: the bus you used last",
		false
	];
	return [
		s.buses[0] || "",
		"",
		false
	];
}
function emptyDraft(kind, s) {
	const [bus, why, chip] = busSuggestion(kind, s);
	return {
		kind,
		cat: "Fuel",
		bus,
		other: false,
		otherText: "",
		picker: !chip,
		why,
		chip,
		odo: "",
		notes: "",
		liters: "",
		price: "",
		amount: "",
		desc: "",
		date: todayISO(),
		time: nowHM(),
		from: "",
		to: "",
		details: "",
		issue: "",
		message: "",
		photos: {}
	};
}
function chosenBus(d, buses) {
	const raw = d.other ? d.otherText.trim() : d.bus;
	return buses.find((b) => keyOf(b) === keyOf(raw)) || raw;
}
function DrivePage() {
	const { text, toast } = useToast();
	const [ready, setReady] = (0, import_react.useState)(false);
	const [names, setNames] = (0, import_react.useState)([]);
	const [loginName, setLoginName] = (0, import_react.useState)("");
	const [loginPin, setLoginPin] = (0, import_react.useState)("");
	const [loginErr, setLoginErr] = (0, import_react.useState)("");
	const [session, setSession] = (0, import_react.useState)(null);
	const [online, setOnline] = (0, import_react.useState)(true);
	const [tick, setTick] = (0, import_react.useState)(0);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [finId, setFinId] = (0, import_react.useState)(null);
	const [km, setKm] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const sessionRef = (0, import_react.useRef)(null);
	const syncing = (0, import_react.useRef)(false);
	const screenRef = (0, import_react.useRef)("Home");
	const commit = (next) => {
		sessionRef.current = next;
		setSession(next);
		writeCache(next);
	};
	const bump = () => setTick((n) => n + 1);
	const refresh = async (silent) => {
		const s = sessionRef.current;
		if (!s) return;
		if (typeof navigator !== "undefined" && !navigator.onLine) {
			if (!silent) toast("You are offline");
			return;
		}
		try {
			const d = await call(driverData({ data: {
				name: s.name,
				pin: s.pin
			} }));
			const lastOdo = mergeOdo({
				...s.lastOdo,
				...d.lastOdo
			});
			let lastCheckIn = s.lastCheckIn;
			if (!lastCheckIn || d.lastCheckIn && d.lastCheckIn.date >= lastCheckIn.date) lastCheckIn = d.lastCheckIn || lastCheckIn;
			commit({
				...s,
				trips: applyOverlay(d.trips),
				buses: d.buses,
				lastOdo,
				lastCheckIn
			});
		} catch (e) {
			if (/Wrong name or PIN/.test(errText(e))) {
				clearCache();
				sessionRef.current = null;
				setSession(null);
				toast("Your PIN was changed. Ask the office.");
			} else if (!silent) toast(errText(e));
		}
	};
	const sync = async () => {
		const s = sessionRef.current;
		if (syncing.current || !s || typeof navigator !== "undefined" && !navigator.onLine) {
			bump();
			return;
		}
		syncing.current = true;
		bump();
		try {
			let q = readQueue();
			while (q.length) {
				const item = q[0];
				let drop = true;
				try {
					if (item.t === "trip") await call(driverTrip({ data: {
						name: s.name,
						pin: s.pin,
						id: item.id,
						action: item.a,
						km: item.km,
						at: item.at
					} }));
					else await call(driverAdd({ data: {
						name: s.name,
						pin: s.pin,
						kind: item.k,
						rid: item.rid,
						obj: item.obj
					} }));
				} catch (e) {
					const m = errText(e);
					if (!/Network error/.test(m)) noteErr("sync: " + m);
					if (/Wrong name or PIN/.test(m)) {
						toast("Your PIN was changed. Ask the office.");
						drop = false;
						break;
					}
					if (/Photo upload/.test(m) && item.t === "add") {
						item.tries = (item.tries || 0) + 1;
						if (item.tries >= 6) {
							delete item.obj.odoPhoto;
							delete item.obj.receipt;
							item.obj.photoFailed = "1";
							item.tries = 0;
						}
						q[0] = item;
						writeQueue(q);
						drop = false;
						break;
					}
					if (!/not found|Invalid|Unknown|required/i.test(m)) {
						drop = false;
						break;
					}
				}
				if (!drop) break;
				q = readQueue().slice(1);
				writeQueue(q);
				bump();
			}
		} finally {
			syncing.current = false;
			bump();
		}
		if (!readQueue().length) await refresh(true);
	};
	(0, import_react.useEffect)(() => {
		const onErr = (e) => noteErr(e.message);
		const onRej = (e) => noteErr(String(e.reason?.message || e.reason || ""));
		window.addEventListener("error", onErr);
		window.addEventListener("unhandledrejection", onRej);
		const onNet = () => {
			setOnline(navigator.onLine);
			if (navigator.onLine) sync();
		};
		window.addEventListener("online", onNet);
		window.addEventListener("offline", onNet);
		setOnline(navigator.onLine);
		const cached = readCache();
		if (cached) {
			cached.trips = applyOverlay(cached.trips);
			commit(cached);
			setReady(true);
			refresh(true).then(() => sync());
		} else call(driverNames()).then((list) => {
			setNames(list);
			setLoginName(list.includes("Rashid Khan") ? DEMO_DRIVER : list[0] || "");
		}).catch(() => setLoginErr("Connect to the internet to log in the first time. After that the app works offline too.")).finally(() => setReady(true));
		const timer = setInterval(() => {
			setOnline(navigator.onLine);
			if (readQueue().length) sync();
			bump();
		}, 2e4);
		return () => {
			window.removeEventListener("error", onErr);
			window.removeEventListener("unhandledrejection", onRej);
			window.removeEventListener("online", onNet);
			window.removeEventListener("offline", onNet);
			clearInterval(timer);
		};
	}, []);
	const doLogin = async (name, pin) => {
		if (!navigator.onLine) return toast("Connect to the internet to log in");
		setBusy(true);
		setLoginErr("");
		try {
			const d = await call(driverData({ data: {
				name,
				pin
			} }));
			commit(d);
			screenRef.current = "Home";
		} catch (e) {
			setLoginErr(errText(e));
		} finally {
			setBusy(false);
		}
	};
	const logout = () => {
		if (readQueue().length) return toast("Please wait until everything is synced");
		clearCache();
		sessionRef.current = null;
		setSession(null);
		setDraft(null);
		window.location.reload();
	};
	const openForm = (kind) => {
		if (!session) return;
		if (kind !== "Feedback") screenRef.current = TITLES[kind];
		setDraft(emptyDraft(kind, session));
	};
	const tripAct = (id, action) => {
		const s = sessionRef.current;
		if (!s) return;
		const distance = action === "finish" ? km : "";
		const rid = uid();
		const item = {
			t: "trip",
			id,
			a: action,
			km: distance,
			at: nowHM(),
			rid
		};
		const q = readQueue().concat(item);
		if (!writeQueue(q)) return toast("Phone storage is full. Connect and sync first.");
		const trip = s.trips.find((x) => x.id === id);
		pushLog({
			rid,
			label: (action === "start" ? "Trip started · " : "Trip finished · ") + (trip?.customer || ""),
			at: nowHM(),
			day: todayISO()
		});
		commit({
			...s,
			trips: applyOverlay(s.trips)
		});
		setFinId(null);
		setKm("");
		toast(navigator.onLine ? action === "start" ? "Trip started" : "Trip finished" : "Saved on this phone. It will sync when you are online.");
		bump();
		sync();
	};
	const submit = (e) => {
		e.preventDefault();
		const s = sessionRef.current;
		const d = draft;
		if (!s || !d) return;
		if (d.kind === "Feedback") {
			const rid = uid();
			const obj = {
				date: todayISO(),
				time: nowHM(),
				message: d.message.trim(),
				screen: screenRef.current,
				device: navigator.userAgent.slice(0, 150),
				version: APP_VERSION,
				errors: readErrs()
			};
			if (!obj.message) return toast("Tell us what happened");
			if (!writeQueue(readQueue().concat({
				t: "add",
				k: "Feedback",
				obj,
				rid
			}))) return toast("Phone storage is full. Connect and sync first.");
			pushLog({
				rid,
				label: "Feedback sent",
				at: nowHM(),
				day: todayISO()
			});
			toast("Thank you. The office will see it.");
			setDraft(null);
			screenRef.current = "Home";
			bump();
			sync();
			return;
		}
		const bus = chosenBus(d, s.buses);
		const obj = {
			bus,
			date: todayISO(),
			time: nowHM()
		};
		if (d.kind === "CheckIn") {
			if (!d.photos.odo) return toast("Please take the odometer photo");
			obj.odometer = d.odo;
			obj.odoPhoto = d.photos.odo.url;
		} else if (d.kind === "Expense") {
			obj.category = d.cat;
			obj.notes = d.notes;
			if (d.photos.rec) obj.receipt = d.photos.rec.url;
			if (d.cat === "Fuel") {
				obj.odometer = d.odo;
				obj.liters = d.liters;
				obj.price = d.price;
			} else obj.amount = d.amount;
		} else if (d.kind === "ExtraTrip") Object.assign(obj, {
			date: d.date,
			time: d.time,
			description: d.desc.trim(),
			from: d.from.trim(),
			to: d.to.trim(),
			details: d.details.trim()
		});
		else obj.issue = d.issue.trim();
		const used = [];
		for (const key of ["odo", "rec"]) {
			const p = d.photos[key];
			if (!p?.warn) continue;
			if (!p.ok) return toast("The photo looks " + p.warn.short + ". Retake it or tap Use anyway.");
			used.push(p.warn.short);
		}
		if (used.length) obj.photoWarn = used.join(", ");
		if (!bus) return toast("Enter the bus number");
		const fuel = d.kind === "Expense" && d.cat === "Fuel";
		const odo = d.kind === "CheckIn" || fuel ? Number(obj.odometer) : null;
		if (odo !== null) {
			if (!(odo > 0)) return toast("Enter the odometer reading");
			const last = (s.lastOdo || {})[bus] || 0;
			if (odo < last) return toast("Odometer is lower than the last reading (" + last.toLocaleString() + " km). Please check.");
			if (last && odo - last > 1500 && !window.confirm("This is " + (odo - last).toLocaleString() + " km more than the last reading. Is it correct?")) return;
		}
		let label = "Problem reported";
		if (d.kind === "CheckIn") label = "Check-in · " + bus + " · " + Number(odo).toLocaleString() + " km";
		if (d.kind === "ExtraTrip") label = "Extra trip · " + obj.from + " → " + obj.to;
		if (d.kind === "Expense" && !fuel) label = d.cat + " · AED " + Number(obj.amount).toFixed(2);
		if (fuel) {
			const liters = Number(obj.liters);
			const price = Number(obj.price);
			if (!(liters > 0 && liters <= 300)) return toast("Liters must be between 1 and 300");
			if ((price < 1 || price > 10) && !window.confirm("Price per liter AED " + price + " looks unusual. Is it correct?")) return;
			label = "Fuel · " + bus + " · " + liters + " L · AED " + (Math.round(liters * price * 100) / 100).toFixed(2);
		}
		if (d.kind === "ExtraTrip" && (!obj.description || !obj.from || !obj.to)) return toast("Description, from and to are required");
		if (d.kind === "Issues" && !obj.issue) return toast("Describe the problem");
		const rid = uid();
		if (!writeQueue(readQueue().concat({
			t: "add",
			k: d.kind,
			obj,
			rid
		}))) return toast("Phone storage is full. Connect and sync first.");
		pushLog({
			rid,
			label,
			at: nowHM(),
			day: todayISO()
		});
		const lastOdo = { ...s.lastOdo };
		if (odo) lastOdo[bus] = odo;
		const next = {
			...s,
			lastOdo,
			lastCheckIn: d.kind === "CheckIn" ? {
				bus,
				date: obj.date,
				odometer: odo || 0
			} : s.lastCheckIn
		};
		commit(next);
		writeBus(bus);
		toast(navigator.onLine ? "Saved" : "Saved on this phone. It will sync when you are online.");
		setDraft(null);
		screenRef.current = "Home";
		bump();
		sync();
	};
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
			title: "AVA Driver",
			sub: "Opening your board"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-4 py-8 text-muted",
			children: "Loading…"
		})]
	});
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
			title: "AVA Driver",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "inline-flex min-h-11 items-center rounded-lg border border-paper/25 px-3 text-sm font-semibold",
				children: "Home"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto max-w-md px-4 py-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl tracking-wide",
						children: "Log in"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Pick your name. The office sets the PIN."
					}),
					names.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-4",
						onSubmit: (e) => {
							e.preventDefault();
							doLogin(loginName, loginPin);
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Your name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
									value: loginName,
									onChange: (e) => setLoginName(e.target.value),
									children: names.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: n }, n))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "PIN",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									value: loginPin,
									onChange: (e) => setLoginPin(e.target.value),
									type: "password",
									inputMode: "numeric",
									autoComplete: "off",
									maxLength: 8
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: busy,
								children: busy ? "Checking…" : "Log in"
							}),
							names.includes("Rashid Khan") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								tone: "ghost",
								className: "mt-2",
								disabled: busy,
								onClick: () => {
									setLoginName(DEMO_DRIVER);
									setLoginPin(DEMO_DRIVER_PIN);
									doLogin(DEMO_DRIVER, DEMO_DRIVER_PIN);
								},
								children: ["Continue as ", DEMO_DRIVER]
							}) : null,
							loginErr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm font-semibold text-danger",
								children: loginErr
							}) : null
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted",
						children: loginErr || "No drivers have a PIN yet. Ask the office to add one."
					})
				]
			})
		})]
	});
	const q = readQueue();
	const pending = new Set(q.map((i) => i.rid));
	const log = readLog().filter((x) => x.day === todayISO()).slice(0, 8);
	const statusText = !online ? q.length ? "Offline · " + q.length + " saved on this phone, will sync later" : "Offline · you can keep working" : q.length ? "Online · syncing " + q.length + (q.length > 1 ? " items…" : " item…") : "Online · all saved";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: session.name,
				sub: "AVA Driver",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: logout,
					className: "inline-flex min-h-11 items-center gap-1 rounded-lg border border-paper/25 px-3 text-sm font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {
						className: "size-4",
						"aria-hidden": "true"
					}), "Log out"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 py-2 text-center text-sm font-semibold " + (!online ? "bg-danger-soft text-danger" : q.length ? "bg-warn-soft text-warn" : "bg-pine-soft text-pine"),
				children: statusText
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-xl px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "size-7" }),
								label: "Daily check-in",
								onClick: () => openForm("CheckIn")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fuel, { className: "size-7" }),
								label: "Report expense",
								onClick: () => openForm("Expense")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-7" }),
								label: "Extra trip",
								onClick: () => openForm("ExtraTrip")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-7" }),
								label: "Report problem",
								onClick: () => openForm("Issues")
							})
						]
					}),
					log.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-6 mb-2 font-display text-xl tracking-wide text-muted",
						children: "Today's entries"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-line rounded-2xl border border-line bg-card",
						children: log.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: pending.has(x.rid) ? "text-warn" : "text-pine",
								"aria-hidden": "true",
								children: pending.has(x.rid) ? "…" : "✓"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: x.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-muted",
									children: [
										x.at,
										" · ",
										pending.has(x.rid) ? "waiting for signal" : "saved"
									]
								})]
							})]
						}, x.rid))
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-6 mb-2 font-display text-xl tracking-wide text-muted",
						children: "My trips"
					}),
					session.trips.length ? session.trips.map((t) => {
						const tone = t.status === "In Progress" ? "go" : t.status === "Completed" ? "ok" : "warn";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "mb-3 rounded-2xl border border-line bg-card p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
									tone,
									children: t.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 font-display text-2xl leading-none tracking-wide",
									children: t.customer
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										t.date,
										" ",
										t.startTime,
										" · Bus ",
										t.bus
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-lg",
									children: [
										t.startLocation,
										" → ",
										t.endLocation
									]
								}),
								t.endTime ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: [
										"Finished ",
										t.endTime,
										t.distanceKm ? " · " + t.distanceKm + " km" : ""
									]
								}) : null,
								t.status === "Scheduled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "mt-3",
									onClick: () => tripAct(t.id, "start"),
									children: "Start trip"
								}) : null,
								t.status === "In Progress" && finId !== t.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									tone: "pine",
									className: "mt-3",
									onClick: () => {
										setFinId(t.id);
										setKm("");
									},
									children: "Finish trip"
								}) : null,
								t.status === "In Progress" && finId === t.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Distance driven (km)",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
											value: km,
											onChange: (e) => setKm(e.target.value),
											type: "number",
											inputMode: "decimal"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										tone: "pine",
										onClick: () => tripAct(t.id, "finish"),
										children: "Confirm finish"
									})]
								}) : null
							]
						}, t.id);
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-2xl border border-dashed border-line px-4 py-8 text-center text-muted",
						children: "No trips assigned to you right now."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						tone: "ghost",
						className: "mt-2",
						onClick: () => void refresh(false),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Refresh trips"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "ghost",
						className: "mt-2 border-dashed",
						onClick: () => openForm("Feedback"),
						children: "Something confusing or not working? Tell us"
					})
				]
			}),
			draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-30 overflow-y-auto bg-paper",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sticky top-0 flex items-center gap-3 border-b-4 border-gold bg-navy px-4 py-3 pt-[max(0.75rem,env(safe-area-inset-top))] text-paper",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "flex-1 font-display text-2xl font-semibold tracking-wide",
						children: TITLES[draft.kind]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-lg border border-paper/25 px-3 text-sm font-semibold",
						onClick: () => {
							setDraft(null);
							screenRef.current = "Home";
						},
						children: "Close"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "mx-auto max-w-xl px-4 py-4",
					children: [
						draft.kind !== "Feedback" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BusField, {
							draft,
							buses: session.buses,
							onChange: setDraft
						}) : null,
						draft.kind === "CheckIn" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Odometer reading (km)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									type: "number",
									inputMode: "numeric",
									required: true,
									value: draft.odo,
									onChange: (e) => setDraft({
										...draft,
										odo: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OdoHint, { n: (session.lastOdo || {})[chosenBus(draft, session.buses)] || 0 }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoField, {
								label: "Odometer photo",
								photo: draft.photos.odo,
								onPick: async (file) => {
									try {
										const stamped = await stampPhoto(file);
										setDraft({
											...draft,
											photos: {
												...draft.photos,
												odo: stamped
											}
										});
									} catch {
										toast("Could not read the photo, try again");
									}
								},
								onUse: () => {
									const cur = draft.photos.odo;
									if (!cur) return;
									setDraft({
										...draft,
										photos: {
											...draft.photos,
											odo: {
												...cur,
												ok: true
											}
										}
									});
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								children: "Submit check-in"
							})
						] }) : null,
						draft.kind === "Expense" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-1 text-sm font-semibold text-muted",
								children: "Expense type"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-3 grid grid-cols-2 gap-2",
								children: CATS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setDraft({
										...draft,
										cat: c
									}),
									className: "min-h-12 rounded-xl border-2 text-base font-bold " + (draft.cat === c ? "border-gold bg-gold text-ink" : "border-line bg-card text-ink"),
									children: c
								}, c))
							}),
							draft.cat === "Fuel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Odometer at fueling (km)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
										type: "number",
										inputMode: "numeric",
										required: true,
										value: draft.odo,
										onChange: (e) => setDraft({
											...draft,
											odo: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OdoHint, { n: (session.lastOdo || {})[chosenBus(draft, session.buses)] || 0 }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Fuel pumped (liters)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
										type: "number",
										inputMode: "decimal",
										step: "any",
										required: true,
										value: draft.liters,
										onChange: (e) => setDraft({
											...draft,
											liters: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Price per liter (AED)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
										type: "number",
										inputMode: "decimal",
										step: "any",
										required: true,
										value: draft.price,
										onChange: (e) => setDraft({
											...draft,
											price: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Total amount (AED)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
										readOnly: true,
										value: Number(draft.liters) && Number(draft.price) ? (Number(draft.liters) * Number(draft.price)).toFixed(2) : "",
										placeholder: "Calculated automatically"
									})
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Amount (AED)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									type: "number",
									inputMode: "decimal",
									step: "any",
									required: true,
									value: draft.amount,
									onChange: (e) => setDraft({
										...draft,
										amount: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Details",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									maxLength: 200,
									placeholder: "Station name, route, what was done…",
									value: draft.notes,
									onChange: (e) => setDraft({
										...draft,
										notes: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoField, {
								label: "Receipt photo (optional)",
								photo: draft.photos.rec,
								onPick: async (file) => {
									try {
										const stamped = await stampPhoto(file);
										setDraft({
											...draft,
											photos: {
												...draft.photos,
												rec: stamped
											}
										});
									} catch {
										toast("Could not read the photo, try again");
									}
								},
								onUse: () => {
									const cur = draft.photos.rec;
									if (!cur) return;
									setDraft({
										...draft,
										photos: {
											...draft.photos,
											rec: {
												...cur,
												ok: true
											}
										}
									});
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								children: "Save expense"
							})
						] }) : null,
						draft.kind === "ExtraTrip" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Description note",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									required: true,
									maxLength: 200,
									placeholder: "Special run, pickup, diversion…",
									value: draft.desc,
									onChange: (e) => setDraft({
										...draft,
										desc: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Date",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
										type: "date",
										required: true,
										value: draft.date,
										onChange: (e) => setDraft({
											...draft,
											date: e.target.value
										})
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Time",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
										type: "time",
										required: true,
										value: draft.time,
										onChange: (e) => setDraft({
											...draft,
											time: e.target.value
										})
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "From",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									required: true,
									maxLength: 80,
									placeholder: "Sharjah Industrial",
									value: draft.from,
									onChange: (e) => setDraft({
										...draft,
										from: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "To",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									required: true,
									maxLength: 80,
									placeholder: "Jebel Ali",
									value: draft.to,
									onChange: (e) => setDraft({
										...draft,
										to: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Details (optional)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									maxLength: 200,
									value: draft.details,
									onChange: (e) => setDraft({
										...draft,
										details: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								children: "Save trip"
							})
						] }) : null,
						draft.kind === "Issues" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "What is the problem?",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AreaInput, {
								required: true,
								value: draft.issue,
								onChange: (e) => setDraft({
									...draft,
									issue: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Send report"
						})] }) : null,
						draft.kind === "Feedback" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "What was confusing, slow or not working?",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AreaInput, {
								required: true,
								placeholder: "Tell us in your own words. The screen you were on is added automatically.",
								value: draft.message,
								onChange: (e) => setDraft({
									...draft,
									message: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Send"
						})] }) : null
					]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toast, {
				text,
				className: "bottom-6"
			})
		]
	});
}
function Tile({ icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex min-h-28 flex-col items-center justify-center gap-2 rounded-2xl border border-line bg-card px-2 text-center text-base font-bold text-ink active:bg-gold",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-pine",
			children: icon
		}), label]
	});
}
function OdoHint({ n }) {
	if (!n) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "-mt-2 mb-3 text-sm text-muted",
		children: [
			"Last reading: ",
			n.toLocaleString(),
			" km"
		]
	});
}
function BusField({ draft, buses, onChange }) {
	const picker = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
		value: draft.other ? "__other__" : draft.bus,
		onChange: (e) => {
			const other = e.target.value === "__other__";
			onChange({
				...draft,
				other,
				bus: other ? draft.bus : e.target.value,
				picker: true,
				chip: false
			});
		},
		children: [buses.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: b }, b)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: "__other__",
			children: "Other bus (type number)…"
		})]
	}), draft.other ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
		className: "mt-2",
		maxLength: 30,
		placeholder: "Type bus number, e.g. DXB 12345",
		value: draft.otherText,
		onChange: (e) => onChange({
			...draft,
			otherText: e.target.value
		})
	}) : draft.why ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1 text-sm text-muted",
		children: draft.why
	}) : null] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-sm font-semibold text-muted",
			children: "Bus number"
		}), draft.chip && !draft.picker ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 rounded-xl border-2 border-pine bg-card px-3 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
					className: "font-display text-2xl tracking-wide",
					children: draft.bus
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex-1 text-sm text-muted",
					children: draft.why
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-lg border border-line px-3 text-sm font-semibold",
					onClick: () => onChange({
						...draft,
						picker: true
					}),
					children: "Change"
				})
			]
		}) : picker]
	});
}
function PhotoField({ label, photo, onPick, onUse }) {
	const id = "pf-" + label.replace(/\s+/g, "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1 block text-sm font-semibold text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				type: "file",
				accept: "image/*",
				capture: "environment",
				className: "hidden",
				onChange: (e) => {
					const f = e.target.files?.[0];
					if (f) onPick(f);
					e.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				tone: "ghost",
				onClick: () => document.getElementById(id)?.click(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {
					className: "size-5",
					"aria-hidden": "true"
				}), photo ? "Retake photo" : "Take photo"]
			}),
			photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: photo.url,
						alt: "Stamped odometer or receipt",
						className: "w-full rounded-xl"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: ["Stamped ", photo.label]
					}),
					!photo.warn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-pine",
						children: "Photo looks clear"
					}) : null,
					photo.warn && photo.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Using this photo anyway"
					}) : null,
					photo.warn && !photo.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 rounded-xl border border-gold bg-warn-soft p-3 text-sm text-warn",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-start gap-2 font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {
									className: "mt-0.5 size-4 shrink-0",
									"aria-hidden": "true"
								}),
								"This photo looks ",
								photo.warn.text
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								tone: "ghost",
								onClick: () => document.getElementById(id)?.click(),
								children: "Retake"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								tone: "ghost",
								onClick: onUse,
								children: "Use anyway"
							})]
						})]
					}) : null
				]
			}) : null
		]
	});
}
//#endregion
export { DrivePage as component };
