//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CAPPJdQb.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/drive",
			"/office"
		],
		preloads: ["/assets/index-CHBzhSzh.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CHBzhSzh.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-yr4cu-A6.js",
			"/assets/types-BXwYk0_e.js",
			"/assets/layout-dashboard-doCa0XED.js"
		]
	},
	"/drive": {
		filePath: "/workspace/src/routes/drive.tsx",
		children: void 0,
		preloads: [
			"/assets/drive-FDEMa9Z5.js",
			"/assets/types-BXwYk0_e.js",
			"/assets/store-D6Qvk6jl.js"
		]
	},
	"/office": {
		filePath: "/workspace/src/routes/office.tsx",
		children: void 0,
		preloads: [
			"/assets/office-BJOurg5G.js",
			"/assets/types-BXwYk0_e.js",
			"/assets/layout-dashboard-doCa0XED.js",
			"/assets/store-D6Qvk6jl.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
